package holiday_decorations;

public interface Tree {
   public abstract int cost();
   public abstract String description();
}