package holiday_decorations;

public class ColoradoBlue implements Tree {


   @Override
   public int cost() {
      return 50;
   }

   @Override
   public String description() {
      return "Colorado Blue with ";
   }
}