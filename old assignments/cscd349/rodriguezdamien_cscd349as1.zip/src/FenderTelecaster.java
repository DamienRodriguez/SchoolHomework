public class FenderTelecaster implements GuitarBehavior {
    public void guitar() {
        System.out.println("The choosen axe of the evening, is the Fender Telecaster!");
    }

}
