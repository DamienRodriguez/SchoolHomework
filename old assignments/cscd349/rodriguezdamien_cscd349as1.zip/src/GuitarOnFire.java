public class GuitarOnFire implements SoloBehavior{
    public void solo() {
        System.out.println("He is setting his guitar on fire! I hope his hair isn't flammable!");
    }
}
