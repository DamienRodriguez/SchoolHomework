public class GibsonFlyingV implements GuitarBehavior {
    public void guitar() {
        System.out.println("The choosen axe of the evening, is the Gibson Flying V!");
    }

}
