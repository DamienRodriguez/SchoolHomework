public class SmashingGuitar implements SoloBehavior{
    public void solo() {
        System.out.println("His guitar is in pieces! Smashing!");
    }
}
