public class JumpOffStage implements SoloBehavior{
    public void solo() {
        System.out.println("He is magnificently stage diving! What grace!");
    }
}
