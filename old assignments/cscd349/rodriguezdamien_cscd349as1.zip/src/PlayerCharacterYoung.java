public class PlayerCharacterYoung extends PlayerCharacter {
    public PlayerCharacterYoung(GuitarBehavior guitar, SoloBehavior solo) {
        super(guitar, solo);
    }

    public void display() {
        System.out.println("Our Axe Maestro for the evening, is none other than Angus Young!");
    }
}
