public class PlayerCharacterSlash extends PlayerCharacter{
    public PlayerCharacterSlash(GuitarBehavior guitar, SoloBehavior solo) {
        super(guitar, solo);
    }

    public void display() {
        System.out.println("Our Axe Maestro for the evening, is none other than Slash!");
    }
}
