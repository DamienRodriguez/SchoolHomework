public interface SoloBehavior {
    public void solo();
}
