public interface GuitarBehavior {
    public void guitar();
}
