public interface Edge {
    public int getVert1();
    public int getVert2();
}
