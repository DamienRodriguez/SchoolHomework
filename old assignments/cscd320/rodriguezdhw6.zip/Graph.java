public interface Graph {

    public int getNumOfVertices(); // Number of vertices
    public int getNumOfEdges(); // Number of edges
    // Get first edge having v as vertex v1
    public Edge first(int v);
    // Get next edge having w.v1 as the first edge
    public Edge next(Edge w);
    public boolean isEdge(Edge w); // True if edge
    public boolean isEdge(int i, int j); // True if edge
    public int v1(Edge w); // Where from
    public int v2(Edge w); // Where to
    public void setEdge(int i, int j, int weight);
    public void setEdge(Edge w, int weight);
    public void delEdge(Edge w); // Delete edge w
    public void delEdge(int i, int j); // Delete (i, j)
    public int weight(int i, int j); // Return weight
    public int weight(Edge w); // Return weight
}
