public class Tester {
    public static void main(String [] args) {

        Graphm g = new Graphm(8);

        g.setEdge(0,1,4);
        g.setEdge(0,2,6);
        g.setEdge(0,3,16);

        g.setEdge(1,7,24);

        g.setEdge(2,7,23);
        g.setEdge(2,5,5);
        g.setEdge(2,3,8);


        g.setEdge(3,5,10);
        g.setEdge(3,4,21);

        g.setEdge(4,5,14);
        g.setEdge(4,6,7);

        g.setEdge(5,6,11);
        g.setEdge(5,7,18);

        g.setEdge(6,7,9);

        g.BFS(g,0);


    }
}
