import java.util.*;

public class Graphm implements Graph {

    private int [][] matrix;
    private int numVertices;
    private int numEdge;
    private int[] Mark;


    public Graphm(final int numberOf) {
        setMark(new int[numberOf]);
        setMatrix(new int[numberOf][numberOf]);
        setNumEdge(numberOf);
        setNumVertices();

    }


    public int getNumVertices() {
        return numVertices;
    }


    public void setNumVertices() {
        this.numVertices = this.Mark.length;
    }


    public int[][] getMatrix() {
        return this.matrix;
    }


    public void setMatrix(int[][] matrix) {
        this.matrix = matrix;
    }


    public int getNumEdge() {
        return this.numEdge;
    }


    public void setNumEdge(int numEdge) {
        this.numEdge = numEdge;
    }


    public int[] getMark() {
        return this.Mark;
    }


    public void setMark(int[] mark) {
        this.Mark = mark;
    }


    public int getNumOfVertices() {
        return this.Mark.length;
    } // Number of vertices


    public int getNumOfEdges() {
        return getNumEdge();
    }


    public Edgem first(int v) {
        for(int i = 0; i < this.numVertices; i++)
            if(this.matrix[v][i] != 0)
                return new Edgem(v,i);
        return null;
    }


    public Edgem next(Edge w) {
        assert w != null: "Edge passed in was null.";

        for(int i = w.getVert2() + 1; i < this.numVertices; i++)
            if(this.matrix[w.getVert1()][i] != 0)
                return new Edgem(w.getVert1(), i);
        return null;
    }


    public boolean isEdge(Edge w) {
        if(w == null)
            return false;

        return this.matrix[w.getVert1()][w.getVert2()] != 0;

    }


    public boolean isEdge(int i, int j) {
        return this.matrix[i][j] != 0;
    }


    public int v1(Edge w) {
        return w.getVert1();
    }


    public int v2(Edge w) {
        return w.getVert2();
    }


    public void setEdge(int i, int j, int weight) {
        assert weight != 0: "Weight passed in was zero.";

        if(this.matrix[i][j] == 0 && this.matrix[j][i] == 0)
            this.numEdge++;

        this.matrix[i][j] = weight;
        this.matrix[j][i] = weight;
    }


    public void setEdge(Edge w, int weight) {
        assert w != null: "Edge passed in was null";
        setEdge(w.getVert1(),w.getVert2(), weight);
    }


    public void delEdge(Edge w) {
        assert w != null: "Edge passed in was null";

        if(isEdge(w))
            delEdge(w.getVert1(), w.getVert2());
    }


    public void delEdge(int i, int j) {
        if(isEdge(i, j)) {
            this.matrix[i][j] = 0;
            this.matrix[i][j] = 0;
            this.numEdge--;
        }
    }


    public int weight(int i, int j) {
        if(isEdge(i,j))
            return this.matrix[i][j];
        return Integer.MAX_VALUE;
    }


    public int weight(Edge w) {
        assert w != null: "Edge passed in was null.";
        return weight(w.getVert1(), w.getVert2());
    }


    public void setWeight(final int vert, final int weight) {
        this.Mark[vert] = weight;
    }


    public int getWeight(final int vert) {
        return this.Mark[vert];
    }


    public static void BFS(Graphm g, int start) {
        Queue q = new LinkedList<Integer>();
        q.add(Integer.valueOf(start));
        g.setWeight(start, 1);

        while(!q.isEmpty()) {
            int temp = ((Integer)q.remove()).intValue();
            System.out.print(temp + "->");
            for(Edgem w = g.first(temp); g.isEdge(w); w = g.next(w)) {
                if(g.getWeight(w.getVert2()) == 0) {
                    q.add(g.v2(w));
                    g.setWeight(g.v2(w), 1);
                }
            }
        }
    }
}
