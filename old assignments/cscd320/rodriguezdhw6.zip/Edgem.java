public class Edgem implements Edge {

    private int vert1;
    private int vert2;

    public Edgem(final int vert1, final int vert2) {
        setVert1(vert1);
        setVert2(vert2);
    }


    public int getVert1() {
        return vert1;
    }


    public void setVert1(int vert1) {
        this.vert1 = vert1;
    }


    public int getVert2() {
        return vert2;
    }


    public void setVert2(int vert2) {
        this.vert2 = vert2;
    }


}
