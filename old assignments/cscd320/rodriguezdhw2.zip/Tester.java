public class Tester {
    public static void main(String[] args) {
        BST myBST = new BST();

        myBST.inorderTraversal();

        //step 5
        myBST.insert(8);
        myBST.insert(3);
        myBST.insert(10);
        myBST.insert(1);
        myBST.insert(6);
        myBST.insert(14);
        myBST.insert(4);
        myBST.insert(7);
        myBST.insert(13);

        //step 6
        myBST.inorderTraversal();

        //step 7
        myBST.postorderTraversal();

        //step 8
        boolean removed = myBST.delete(8);

        //step 9
        if(removed) {
            myBST.inorderTraversal();
            myBST.postorderTraversal();
        }
        else
            System.out.println("Remove unsuccessful.");

        //step 10
        removed = myBST.delete(10);

        //step 11
        if(removed) {
            myBST.inorderTraversal();
            myBST.postorderTraversal();
        }
        else
            System.out.println("Remove unsuccessful.");
    }
}
/*
 * Starting with 7 as the root
 * Go left: 7 -> 3
 *      Check if 3 has left neighbor
 *      7 -> 3 -> 1
 *          Check if 1 has left neighbor
 *              1 does not have left neighbor
 *          Check if 1 has right neighbor
 *              1 does not have right neighbor
 *          Print 1
 *
 *      Check if 3 has right neighbor
 *      7 -> 3 -> 6
 *          Check if 6 has a left neighbor
 *          7 -> 3 -> 6 -> 4
 *              Check if 4 has left neighbor
 *                  4 does not have left neighbor
 *              Check if 4 has right neighbor
 *                  4 does not have right neighbor
 *              Print 4
 *          Check if 6 has a right neighbor
 *          6 has no right neighbor
 *          Print 6
 *      Print 3
 * Go right: 7 -> 14
 *      Check if 14 has a left neighbor
 *          7 -> 14 -> 13
 *              Check if 13 has left neighbor
 *                  13 does not have left neighbor
 *              Check if 13 has right neighbor
 *                  13 does not have right neighbor
 *              Print 13
 *      Check if 14 has a right neighbor
 *          14 has no right neighbor
 *      Print 14
 * Print 7
 */
