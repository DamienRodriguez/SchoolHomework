public class BST {

    private class Node {
        private Node left, right;


        private Comparable data;

        public Node(final Comparable data) {
            setData(data);

        }

        public Comparable getData() {
            return data;
        }

        public void setData(final Comparable data) {
            this.data = data;
        }
    }//end of nested Node class

    private Node root;
    public BST() {
        initRoot();
    }

    private void initRoot() {
        this.root = null;
    }

    //step one
    public void insert(final Comparable data) {
        this.root = insert(this.root, data);
    }
    private Node insert(Node node, final Comparable data) {
        if(node == null)
            node = new Node(data);
        else {
            if(data.compareTo(node.getData()) < 0)
                node.left = insert(node.left, data);
            else
                node.right = insert(node.right,data);
        }
        return node;
    }


    //step 2
    public void postorderTraversal() {
        postorderTraversal(this.root);
        System.out.println();
    }
    private void postorderTraversal(Node node) {
        if(node != null) {
            postorderTraversal(node.left);
            postorderTraversal(node.right);
            System.out.print(node.getData() + " ");
        }
    }


    //step 2
    public void inorderTraversal() {
        inorderTraversal(this.root);
        System.out.println();
    }
    private void inorderTraversal(Node node) {
        if(node != null) {
            inorderTraversal(node.left);
            System.out.print(node.getData() + " ");
            inorderTraversal(node.right);
        }
    }


    //step 4
    public boolean delete(final Comparable toRemove) {
        return delete(this.root, toRemove);
    }

    private boolean delete(Node node, Comparable toRemove) {
        node = removeItem(node, toRemove);

        if(node == null)
            return false;

        return true;
    }

    //step 4 helper methods
    private Node removeItem(Node node, Comparable toRemove) {
        if(root != null) {

            if(toRemove.compareTo(node.getData()) == 0)
                node = removeFromRoot(node);

            else if(toRemove.compareTo(node.getData()) < 0)
                node.left = removeItem(node.left, toRemove);

            else
                node.right = removeItem(node.right, toRemove);

            return node;
        }
        return null;
    }
    private Node removeFromRoot(Node node) {

        if(node.right == null)
            node = node.left;

        else if(node.left == null)
            node = node.right;
        else {
            Node largest = findLargest(node.left);
            node.setData(largest.getData());
            node = deleteLargest(node.left);
        }

        return node;
    }
    private Node findLargest(Node node) {
        if(node.right != null)
            node = findLargest(node.right);
        return node;
    }
    private Node deleteLargest(Node node) {
        if(node.right != null) {
            Node cur = deleteLargest(node.right);
            node.right = cur;
        }
        else
            node = node.left;

        return node;
    }
}
