import javax.sound.midi.Soundbank;
import java.sql.SQLOutput;
import java.util.Arrays;

public class BinaryTree {

    private class Node {
        private Node right,left;
        private Object data;

        public Node(final Object data) {
            setData(data);
            initSides();
        }
        public Object getData() { return this.data; }
        public void setData(final Object data) { this.data = data; }
        public void initSides() { this.right = null; this.left = null; }
    }

    private Node root;

    public BinaryTree() { this.root = null; }
    public BinaryTree buildTree(Object[] inOrderSeq, Object[] postOrderSeq) {
        this.root = recursiveBuildTree(inOrderSeq, postOrderSeq);
        return this;
    }


    private Node recursiveBuildTree(Object[] inOrderSeq, Object[] postOrderSeq) {

        if(inOrderSeq.length == 0 || postOrderSeq.length == 0) {
            return null;
        }

        if(inOrderSeq.length == 1 || postOrderSeq.length == 1)
            return new Node(postOrderSeq[0]);
        //base case

        int root = findRootInOrderSeq(postOrderSeq[postOrderSeq.length - 1], inOrderSeq);
        System.out.println("In Order index: " + root);
        System.out.println("In Order value: " + inOrderSeq[root]);
        Node nn = new Node(inOrderSeq[root]);

        Object[] leftInOrder = Arrays.copyOfRange(inOrderSeq, 0, root); //left sub tree
        Object[] rightInOrder = Arrays.copyOfRange(inOrderSeq, root+1, inOrderSeq.length); //right sub tree

        Object[] leftPostOrder = Arrays.copyOfRange(postOrderSeq, 0, postOrderSeq.length - (rightInOrder.length + 1));
        Object[] rightPostOrder = Arrays.copyOfRange(postOrderSeq, leftInOrder.length, postOrderSeq.length-1);

        nn.left = recursiveBuildTree(leftInOrder, leftPostOrder);
        nn.right = recursiveBuildTree(rightInOrder, rightPostOrder);

        return nn;
    }
    private static int findRootInOrderSeq(Object rootData, Object[] inOrderSeq) {
        return Arrays.asList(inOrderSeq).indexOf(rootData);
    }


    public void postOrderTraversal() {
        postOrderTraversal(this.root);
    }
    private void postOrderTraversal(Node node) {
        if(node != null) {
            postOrderTraversal(node.left);
            postOrderTraversal(node.right);
            System.out.print(node.getData() + " ");
        }
    }


    public void inOrderTraversal() {
        inOrderTraversal(this.root);
    }
    private void inOrderTraversal(Node node) {
        if (node != null) {
            inOrderTraversal(node.left);
            System.out.print(node.getData() + " ");
            inOrderTraversal(node.right);
        }
    }
}
