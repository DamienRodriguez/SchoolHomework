import java.util.Arrays;

public class Tester {

    public static void main(String[] args) {

        Object[] inOrderSeq = {9,5,1,7,2,12,8,4,3,11};
        Object[] postOrderSeq = {9,1,2,12,7,5,3,11,4,8};

        BinaryTree myTree = new BinaryTree();
        myTree.buildTree(inOrderSeq, postOrderSeq);

        System.out.println(Arrays.toString(inOrderSeq));
        myTree.inOrderTraversal();
        System.out.println();
        System.out.println();
        System.out.println(Arrays.toString(postOrderSeq));
        myTree.postOrderTraversal();
        System.out.println();
        System.out.println();
    }
}
