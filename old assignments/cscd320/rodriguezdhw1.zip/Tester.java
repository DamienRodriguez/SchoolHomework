import java.util.Arrays;
public class Tester {
   public static void main(String[] args) {
   
      int[] a = {19,14,16,5,7,3,1,9};
      System.out.println("Program Start");
      System.out.println("=======================================");
      System.out.println();
      System.out.println("Initial Array: " + Arrays.toString(a));
      System.out.println("SORTING ARRAY");
      System.out.println();
      sortArray(a, 0, a.length - 1);
      
      System.out.println("Sorted Array: " + Arrays.toString(a));
      System.out.println("=======================================");
      
      System.out.println();
      System.out.println("STARTING TEST CASES");
      
      System.out.println("=======================================");
      System.out.println("performing quickSearch(a,8), it will return 4, the index of number 9");
      System.out.println("Value used: 8    Result: " + quickSearch(a,8));
      System.out.println();
      
      System.out.println("performing quickSearch(a,19), it will return 7, the index of number 19");
      System.out.println("Value used: 19    Result: " + quickSearch(a,19));
      System.out.println();
      
      System.out.println("performing quickSearch(a,20), it will return -1, as there is no value greater than or equal to 20");
      System.out.println("Value used: 20    Result: " + quickSearch(a,20));
      System.out.println();
      
      System.out.println("performing quickSearch(a,6), it will return 3, the index of number 7");
      System.out.println("Value used: 6    Result: " + quickSearch(a,6));
      System.out.println();
      
      System.out.println("performing quickSearch(a,-1), it will return 0, the index of number 1");
      System.out.println("Value used: -1    Result: " + quickSearch(a,-1));
      System.out.println(); 
   }

   //recursive insertion sort provided by Dr. Yun Tian of Eastern Washington University
   public static void sortArray(int a[], int j, int m) {
      int i, temp;
      if(j < m) {
         for(i = j; i <= m; i++) {
            if(a[i] < a[j]) {
               temp = a[i];
               a[i] = a[j];
               a[j] = temp;
            }
         }
         j++;
         sortArray(a,j,m);
      }
   }
   
   public static int quickSearch(int array[], int value) {
      if(array == null || array.length < 1)
         throw new IllegalArgumentException("Array argument in quickSearch was passed in as null, or with no elements in array.");
      
      int x, y;
      x = 0;
      y = array.length - 1;
      
      while(x <= y) {
         int z = (x + y) / 2;
         
         if(array[z] == value)
            return z;
         else if(z == y && array[z] > value) //check being asked for in write-up
            return z;
         
         if(array[z] < value)
            x = z + 1;
         else
            y = z;     
      }
      return -1;
   }
}