import java.util.Comparator;

public class Edge {
    private int source;
    private int destination;
    private int weight;

    public Edge(final int source, final int destination) {
        setSource(source);
        setDestination(destination);
    }


    public Edge(final int source, final int destination, final int weight) {
        setSource(source);
        setDestination(destination);
        setWeight(weight);
    }


    public int getSource() {
        return source;
    }


    public void setSource(int source) {
        this.source = source;
    }


    public int getDestination() {
        return destination;
    }


    public void setDestination(int destination) {
        this.destination = destination;
    }


    public int getWeight() {
        return weight;
    }


    public void setWeight(int weight) {
        this.weight = weight;
    }


    //Comparator Object
    public final static Comparator<Edge> BYWEIGHT = new ByWeightComparator();
    private static class ByWeightComparator implements Comparator<Edge> {
        public int compare(Edge e, Edge f) {
            return e.weight - f.weight;
        }
    }// end ByWeightComparator class


    public int compareTo(Edge that) {
        return this.weight - that.weight;
    }

    @Override
    public String toString() {
        int[] vertexIndecies = WeightedGraph.getVertexIndecies();
        String str = vertexIndecies[this.source] + "->" + vertexIndecies[this.destination];
        return str;
    }

}
