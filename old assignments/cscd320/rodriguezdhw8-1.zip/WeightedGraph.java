import java.util.*;

// Weighted Undirected Graph
public class WeightedGraph {


    private int V;
    private Set<Edge>[] adj; //adj[i] stores all edges connecting to vertex i
    private static int[] vertexIndecies;


    public WeightedGraph(int V) {
        this.V = V;
        adj = (Set<Edge>[]) new Set[V];
        vertexIndecies = new int[V];
        for (int v = 0; v < V; v++) {
            adj[v] = new HashSet<Edge>();
            vertexIndecies[v] = v+1;
        }

    }


    public void addEdge(Edge e) {
        adj[e.getSource()].add(e);
    }


    public Iterable<Edge> adj(int v) {
        return adj[v];
    }


    public static int[] getVertexIndecies() {
        return vertexIndecies;
    }


    public static void setVertexIndecies(int[] vertexIndecies) {
        WeightedGraph.vertexIndecies = vertexIndecies;
    }


    public int getV() {
        return V;
    }


    public void setV(int v) {
        V = v;
    }


    public Set<Edge>[] getAdj() {
        return adj;
    }


    public void setAdj(Set<Edge>[] adj) {
        this.adj = adj;
    }
}