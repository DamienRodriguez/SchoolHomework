import java.util.HashSet;
import java.util.Set;

public class Dijkstras {

    private int[] distance;
    private String path[];
    private Set<Integer> Q;


    public Dijkstras(WeightedGraph g) {
        distance = new int[g.getV()];
        path = new String[g.getV()];
        Q = new HashSet<>();


        //initializing arrays
        for(int i = 0; i < distance.length; i++) {
            path[i] = "";

            Q.add(i); //all vertices are added to Q in this loop

            if (i == 0) //really basic loop unrolling
                distance[i] = 0;
            else
                distance[i] = Integer.MAX_VALUE;
        }

        while(!Q.isEmpty()) {
            int u = minDistance(this.Q, this.distance);

            //for each neighbor associated with u
            for(Edge e: g.adj(u)) {
               if(this.distance[e.getDestination()] > this.distance[u] + e.getWeight()) {
                   this.distance[e.getDestination()] = this.distance[u] + e.getWeight();
                   path[e.getDestination()] = path[u] + e.toString() + ",";
               }
            } //end for loop
        } //end while loop
    }



    //remove and return the index with the smallest distance value associated with it
    public int minDistance(Set<Integer> Q, int[] distance) {

        int minIndex = -1;
        int counter = 0;

        for(Integer i: Q) {
            if(counter == 0)
                minIndex = i;
            if(distance[minIndex] > distance[i]){
                minIndex = i;
            } //end if
            counter++;
        } //end for

        Q.remove(minIndex);
        return minIndex;
    }



    public void printResults() {
        for(int x = 0; x < this.distance.length; x++) {
            System.out.println("Path " + (x+1) + "): vertex 1 to vertex " + (x+1) + ", path is " + path[x] + ", length is " + this.distance[x]);
        }
    }
}
