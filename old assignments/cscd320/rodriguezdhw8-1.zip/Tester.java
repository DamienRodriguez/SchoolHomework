public class Tester {


    public static void main(String[] args) {
        WeightedGraph G = new WeightedGraph(8);

        G.addEdge(new Edge(0,1,9));
        G.addEdge(new Edge(0,5,14));
        G.addEdge(new Edge(0,6,15));
        G.addEdge(new Edge(1,2,24));
        G.addEdge(new Edge(5,2,18));
        G.addEdge(new Edge(5,4,30));
        G.addEdge(new Edge(5,6,5));
        G.addEdge(new Edge(6,7,44));
        G.addEdge(new Edge(2,4,2));
        G.addEdge(new Edge(2,3,6));
        G.addEdge(new Edge(2,7,19));
        G.addEdge(new Edge(4,3,11));
        G.addEdge(new Edge(4,7,16));
        G.addEdge(new Edge(3,2,6));
        G.addEdge(new Edge(3,7,6));

        Dijkstras d = new Dijkstras(G);

        d.printResults();

        System.out.println("I was having a lot of difficulty in understanding why my math wasn't adding up.");
        System.out.println("Any comments that could give me the answer would be appreciated.");
        System.out.println("If you can't do that, I would appreciate a point in the right direction.");
    }
}
