import java.util.Comparator;
public class Edge implements Comparable<Edge> {

    private final double WEIGHT;
    private int v;
    private int w;

    public Edge(final int v, final int w, final double weight) {
        this.WEIGHT = weight;
        setV(v);
        setW(w);
    }

    public int either() {
        return getV();
    }

    public int other(final int vertex) {
        if(vertex == v)
            return getW();
        else
            return getV();
    }

    public double getWeight() {
        return WEIGHT;
    }


    public int getV() {
        return v;
    }


    public void setV(final int v) {
        this.v = v;
    }


    public int getW() {
        return w;
    }


    public void setW(final int w) {
        this.w = w;
    }


    private static class ByWeightComparator implements Comparator<Edge> {
        public int compare(final Edge e, final Edge f) {
            if(e.getWeight() < f.getWeight())
                return -1;

            if(e.getWeight() > f.getWeight())
                return +1;

            return 0;
        }
    }


    public final static Comparator<Edge> BY_WEIGHT = new ByWeightComparator();


    @Override
    public int compareTo(final Edge that) {
        if(this.WEIGHT < that.getWeight())
            return -1;

        else if(this.WEIGHT > that.getWeight())
            return +1;

        else
            return 0;
    }

    @Override
    public String toString() {
        return getV() + "->" + getW();
    }
}
