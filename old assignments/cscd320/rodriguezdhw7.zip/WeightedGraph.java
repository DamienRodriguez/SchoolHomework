import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;


public class WeightedGraph {
    private int V;
    private Set<Edge>[] adj;


    public int getV() {
        return this.V;
    }

    public void setV(int v) {
        this.V = v;
    }


    public void setAdj(final int v) {
        this.adj = (Set<Edge>[]) new Set[v];
        for(int i = 0; i < v; i++)
            adj[i] = new HashSet<Edge>();
    }

    public WeightedGraph(final int V) {
        setV(V);
        setAdj(V);
    }


    public void addEdge(final Edge e) {
        int v = e.getV();
        int w = e.getW();
        adj[v].add(e);
        adj[w].add(e);
    }


    public Iterable<Edge> adj(final int v) {
        return adj[v];
    }

    public Edge[] edges() {
        ArrayList<Edge> edges = new ArrayList<Edge>();

        for(int i = 0; i < this.V; i++) {
            for(Edge e: this.adj(i))
                edges.add(e);
        }

        edges.trimToSize();

        Edge[] returnedEdges = new Edge[edges.size()];
        for(int j = 0; j < edges.size(); j++)
            returnedEdges[j] = (Edge)edges.get(j);

        return returnedEdges;
    }


}
