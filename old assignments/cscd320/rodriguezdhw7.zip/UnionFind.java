import java.util.HashSet;

public class UnionFind {

    HashSet<Integer> components[];

    public UnionFind(int V) {
        components = new HashSet[V]; //initialization of our sets therefore []
        for (int v = 0; v < V; v++)
        {
            components[v] = new HashSet<Integer>();
            components[v].add(v);
        }
    }

    public boolean find(int v, int w) {
        for (int i = 0; i < components.length; i++) { //iterates through our array

            if(components[i].contains(v) && components[i].contains(w))
                return true;
        }
        return false;
    }

    public void unite(int v, int w) {

        HashSet<Integer> temp = new HashSet<Integer>();
        int indexV = -1, indexW = -1;

        for (int i = 0; i < components.length; i++) {
            if(components[i].contains(v))
                indexV = i;
            else if(components[i].contains(w)) {
                indexW = i;
                temp = components[i];
            }
        }

        components[indexV].addAll(temp);
        components[indexW].clear();

    }
}
