import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

public class Kruskal {
    private Set<Edge> mst = new HashSet<Edge>();


    public Kruskal(final WeightedGraph g) {
        Edge[] edges = g.edges();
        removeDuplicates(edges);

        Arrays.sort(edges, Edge.BY_WEIGHT);
        UnionFind uf = new UnionFind(g.getV());

        setMST(edges, uf);
    }


    public void setMST(final Edge[] edges, final UnionFind uf) {
        for(Edge e: edges) {
            if(!uf.find(e.either(), e.other(e.either()))) {
                uf.unite(e.either(),e.other(e.either()));
                mst.add(e);
            }
        }
    }


    private void removeDuplicates(Edge[] edges) {
        Set<Edge> set = new HashSet<Edge>();

        for(int i = 0; i < edges.length; i++)
            set.add(edges[i]);

        Object[] temp1 = set.toArray();
        Edge[] temp2 = new Edge[temp1.length];

        for(int i = 0; i < temp1.length; i++)
            temp2[i] = (Edge)temp1[i];

        edges = temp2;
    }


    public Iterable<Edge> getMST() {
        return this.mst;
    }

}
