package homework5;
import java.util.Scanner;

public class Tester
{
   public static void main(String args[])
   {     
      Evaluator e = new Evaluator();
      String input = new String();
      Scanner kb = new Scanner(System.in);
      
      input = kb.nextLine();
      
      input = removeWhiteSpace(input);
      input = e.infixToPostfix(input);
      
      System.out.println(input);
      System.out.println(e.evaluatePostfix(input));
   }
   
   private static String removeWhiteSpace(final String str)
   {
      String res = "";
      char i;
      for(int x = 0; x < str.length(); x++)
      {
         i = str.charAt(x);
         if(i != ' ')
            res = res + i;
      }
      
      return res;
   }//Used to get rid of white space within user input
}