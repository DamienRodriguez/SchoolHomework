package homework5;

public class LinkedStack
{
   private static class Node
   {
      Object data;
      Node next;
      
      public Node(final Object o)
      {
         this.data = o;
         next = null;
      }
      
   }//end of Node class
   
   private Node head;
   private int size;
   
   public LinkedStack()
   {
      this.head = null;
      this.size = 0;
   }
   
   public int size() 
   {
		return this.size;
	}

	public boolean isEmpty() 
   {
		return size == 0;
	}
   
   public Object pop()
   {
      Node cur = this.head;
		this.head = cur.next;
		this.size --;
		
		return cur.data;
   }
   
   public void push(final Object o)
   { 
      Node nn = new Node(o);
      
      if(this.size == 0)
		{
			this.head = nn;
			this.size ++;
		}
		
		else
		{
			nn.next = this.head;	//Connects to the first node
			this.head = nn;		//slips into slot 0 to be first
			this.size ++;
		}
   }
   
   public Object peak()
   {
	   return this.head.data;
   }//used for checking precedence and conversion check
}