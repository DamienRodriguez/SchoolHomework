package homework5;

public class Evaluator
{
	public String infixToPostfix(final String expression)
	{
		LinkedStack stack = new LinkedStack();
		
		String postFix = ""; //returned expression
		
		char cur; //current character in infix expression
		char temp = ' '; //throw away variable used for calls to pop method
		
		for(int x = 0; x < expression.length(); x++)
		{
         cur = expression.charAt(x);
			
			if(isOperand(cur))
			{
				postFix = postFix + cur;
			}
			
			else if(cur == '(')
			{
				stack.push(cur);
			}
			
			else if(cur == ')')
			{
            while(((char)stack.peak()) != '(')
				{
					postFix += stack.pop();
            }
            
            temp = (char)stack.pop(); //throwaway the '('
			}
			
			else
			{
				while(stack.size() != 0 && checkPrecedence(cur,(char)stack.peak()) < 0)
				{
					temp = (char)stack.pop();
					postFix = postFix + temp;
				}
				stack.push(cur);
			}
			
			//cur = expression.charAt(x);
		}
		
		while(stack.size() != 0)
		{
			temp = (char)stack.pop();
			postFix = postFix + temp;
		}
		return postFix;
	}
	
	public int evaluatePostfix(final String str)
	{
      LinkedStack stack = new LinkedStack();
      char cur;
      int right, left, res = 0;
            
      for(int x = 0; x < str.length(); x++)
      {
         cur = str.charAt(x);
         
         if(isOperand(cur))
            stack.push(Character.getNumericValue(cur));
         
         else
         {
            right = (int)stack.pop();
            left = (int)stack.pop();
            
            if(cur == '+')
               res = left + right;
            
            else if(cur == '-')
               res = left - right;
            
            else if(cur == '%')
               res = left % right;
            
            else if(cur == '^')
               res = (int)Math.pow(left,right);
            
            else if(cur == '*')
               res = left * right;
            
            else if(cur == '/')
               res = left / right;
            
            stack.push(res);  
         } 
      }
      if(stack.size() == 1)
         return (int)stack.pop();
      
      
      System.out.println("ERROR ERROR"); //can only get here if we have a problem with stack
		return 0;
	}
   
   
   
   
	private int checkPrecedence(char cur, char head)
	{
		int curPres = 0, stackPres = 0;
		
		switch (cur)
		{
			case 1: cur = '(';
				curPres = 100;
				break;
			case 2: cur = ')';
				curPres = 0;
				break;
			case 3: cur = '^';
				curPres = 6;
				break;
			case 4: cur = '*';
				curPres = 3;
				break;
			case 5: cur = '/';
				curPres = 3;
				break;
			case 6: cur = '%';
				curPres = 3;
				break;
			case 7: cur = '+';
				curPres = 1;
				break;
			case 8: cur = '-';
				curPres = 1;
				break;
		}//end of cur eval


		switch (head)
		{
			case 1: head = '(';
				stackPres = 0;
				break;
			case 2: head = '^';
				stackPres = 5;
				break;
			case 3: head = '*';
				stackPres = 4;
				break;
			case 4: head = '/';
				stackPres = 4;
				break;
			case 5: head = '%';
				stackPres = 4;
				break;
			case 6: head = '+';
				stackPres = 2;
				break;
			case 7: head = '-';
				stackPres = 2;
				break;
		}//end of stack eval	
		
		return curPres - stackPres;
	}//end of checkPrecedence
	
	private boolean isOperand(final char cur)
	{
		if(cur == '(')
			return false;
		if(cur == ')')
			return false;
		if(cur == '^')
			return false;
		if(cur == '*')
			return false;
		if(cur == '/')
			return false;
		if(cur == '%')
			return false;
		if(cur == '+')
			return false;
		if(cur == '-')
			return false;
		
		return true; //can only be reached if character is a number
	}//end of isOperand
}