package homework8;

public class Queue 
{
	private class Node
	{
		private Object data;
		private Node next;

		public Node(Object data, Node next)
		{
			this.data = data;
			this.next = next;

		}//EVC 
      public Node(Object data)
      {
         this.data = data;
         this.next = null;
      }
	
	}//End of nested class
	
	private Node head, tail;
	private int size;
	
	public Queue()
	{
		this.head = null;
		this.tail = null;
		this.size = 0;
	}//DVC
	
	public int size()
	{
		return this.size;
	}
	
	public boolean isEmpty()
	{
		return this.size == 0;
	}
	
	public void enqueue(Object o)
	{
		if(this.size == 0)
		{
			Node nn = new Node(o);
			this.head = nn;
			this.tail = nn;
			this.size++;
		}

		else
		{
			Node nn = new Node(o);
			this.tail.next = nn;
			this.tail = nn;
			this.size++;
		}

	}
	
	public Object dequeue()
	{
		Node cur = this.head;
		this.head = this.head.next;
		this.size --;
		
		return cur.data;
	}
	
	
}
