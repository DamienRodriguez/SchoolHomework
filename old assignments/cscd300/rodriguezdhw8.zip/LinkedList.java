package homework8;

public class LinkedList 
{
    private class Node
    {
        private Object data;
        private Node prev,next;
        private Node(final Object data, final Node prev, final Node next)
        {
            this.data = data;
            this.prev = prev;
            this.next = next;
        }
    }

    private Node head;
    private int size;

    public LinkedList()
    {
        this.head = null;
        this.size = 0;
    }

    public int getSize(){ return this.size; }
    public boolean isEmpty() { return this.size == 0;}

    public void addLast(final Object o)
    {
        Node nn;
        if(this.size == 0)
        {
            nn = new Node(o,null,null);
            this.head = nn;
            this.head.next = this.head;
            this.head.prev = this.head;
            this.size++;
        }
        else
        {
            Node cur = this.head.prev;
            nn = new Node(o,cur,cur.next);
            cur.next.prev = nn;
            cur.next = nn;
            this.size++;
        }
    }

    public Object removeFirst()
    {
        Node cur = this.head;
        this.head.next.prev = this.head.prev;
        this.head.prev.next = this.head.next;
        this.size--;

        return cur.data;
    }
    
    public void InsertionSort() 
   {
      
      Node lastSorted, walker;
      Comparable FUD;
      
      for(lastSorted = this.head.next; lastSorted != this.head.prev; lastSorted = lastSorted.next)
      {
         FUD = (Comparable) lastSorted.next.data;
         for(walker = lastSorted; walker != this.head && ((Comparable)walker.data).compareTo(FUD) > 0; walker = walker.prev)
         {
            walker.next.data = walker.data;
         }
         
         walker.next.data = FUD;
      }
	}//working

    public void MergeSort()
    {
        Queue q = new Queue();
        for(int x = 0; x < this.getSize() && this.getSize() != 0; x++)
        {
            LinkedList temp = new LinkedList();
            temp.addLast(this.removeFirst());
            q.enqueue(temp);
        }

        while(q.size() > 1)
        {
            LinkedList subList1 = (LinkedList)q.dequeue();
            LinkedList subList2 = (LinkedList)q.dequeue();

            LinkedList newList = merge(subList1,subList2);
            q.enqueue(newList);
        }

    }

    public LinkedList merge(final LinkedList a, final LinkedList b)
    {
        LinkedList c = new LinkedList();


        while(!a.isEmpty() && !b.isEmpty())
        {
            if (((Comparable)a.head.data).compareTo(((Comparable)b.head.data)) > 0)
            {
                c.addLast(a.removeFirst());
            }
            else
            {
                c.addLast(b.removeFirst());
            }
        }

        while(!a.isEmpty())
        {
            c.addLast(a.removeFirst());
        }

        while(!b.isEmpty())
        {
            c.addLast(b.removeFirst());
        }

        return c;
    }

    public boolean isSorted()
    {
        Node cur = this.head, start = this.head;
        boolean sorted = true;

        while(cur.next != this.head)
        {
            if(((Comparable)cur.data).compareTo(((Comparable)cur.next.data)) > 0)
               return false;
            cur = cur.next;
        }

        return true;
    }

}

