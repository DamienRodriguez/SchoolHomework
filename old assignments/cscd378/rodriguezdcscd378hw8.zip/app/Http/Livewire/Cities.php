<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Cities extends Component
{
    public $sortBy = 'id';
    public $direction = "asc";

    public $search="";
    protected $queryString = [
        'search'=>['except'=>''],
        'sortBy'=>['except'=>'id'],
        'direction'=>['except'=>'asc']
    ];

    public function render()
    {
        $cities = \App\Models\City::where('name', 'like', "%$this->search%")
        ->orWhere('state', 'like', "%$this->search%")
        ->orderBy($this->sortBy, $this->direction);
        return view('livewire.cities', ['cities'=>$cities->get()]);
    }

    public function doSort($field, $dir) {
        $this->sortBy = $field;
        $this->direction = $dir;
    }
}
