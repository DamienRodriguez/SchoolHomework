<?php
namespace App\Domain;
require "App\Models\City.php";

class CensusAPI {
    public static function fillTable() {
        $parsed_data = new CityParser(PullAPI::fetchCities()); //have object with tangible data

        foreach ($parsed_data->get_city_array() as $city) {
            $entry = new App\Models\City;
            $entry->name = $city.get_name();
            $entry->state = $city.get_state();
            $entry->population_2000 = $city.get_population_2000();
            $entry->population_2010 = $city.get_population_2010();
            $entry->population_2020 = $city.get_population_2020();
            $entry->save();
        }

    }
}


$parsed_data = new CityParser(PullAPI::fetchCities()); //have object with tangible data

foreach ($parsed_data->get_city_array() as $city) {
    $entry = new App\Models\City;
    $entry->name = $city.get_name();
    $entry->state = $city.get_state();
    $entry->population_2000 = $city.get_population_2000();
    $entry->population_2010 = $city.get_population_2010();
    $entry->population_2020 = $city.get_population_2020();
    $entry->save();
}

echo True;

class City
{
    private $name;
    private $state;
    private $population_2000;
    private $population_2010;
    private $population_2020;
    

    public function __construct($name, $state, $population_2000, $population_2010, $population_2020)
    {
        $this->set_name($name);
        $this->set_state($state);
        $this->set_population_2000($population_2000);
        $this->set_population_2010($population_2010);
        $this->set_population_2020($population_2020);
    }


    //Setters
    private function set_name($name)
    {
        $this->name = $name;
    }

    private function set_population_2000($population)
    {
        $this->population_2000 = (int) $population;
    }

    private function set_population_2010($population)
    {
        $this->population_2010 = (int) $population;
    }

    private function set_population_2020($population)
    {
        $this->population_2020 = (int) $population;
    }

    private function set_state($state) {
        $this->state = $state;
    }


    //Getters
    public function get_name()
    {
        return $this->name;
    }

    public function get_population_2000()
    {
        return $this->population_2000;
    }

    public function get_population_2010()
    {
        return $this->population_2010;
    }

    public function get_population_2020()
    {
        return $this->population_2020;
    }

    public function get_state() {
        return $this->state;
    }


    public function ___toString()
    {
        $return = $this->name . " (";
        $return = $return . (string) $this->population;
        $return = $return . ")\r\n";
        return $return;
    }
}

class CityParser
{
    private $city_array = array();
    private $size;
    public function __construct($jsonpayload)
    {
        $this->set_array($jsonpayload);
        $this->set_size(count($this->city_array));
    }

    private function set_size($size) {
        $this->size = $size;
    }

    private function set_array($array)
    {
        for ($i = 0; $i < count($array); $i++) {
            $temp = new City($array[$i]['jurisdiction'], "Washington", $array[$i]['pop_2000'], $array[$i]['pop_2010'], $array[$i]['pop_2020']);
            if ($this->checkForCity($temp)) {
                array_push($this->city_array, $temp);
            }
        }
    }

    public function get_size() { return $this->size; }
    public function get_city_array() { return $this->city_array; }

    private function checkForCity($city)
    {
        if (strpos($city->get_name(), "Total") >= 1) {
            return false;
        }

        if (strpos($city->get_name(), "corporated") >= 1) {
            return false;
        }

        if (strpos($city->get_name(), "County") >= 1) {
            return false;
        }

        if (strpos($city->get_name(), "(part)") >= 1) {
            return false;
        }

        return true;
    }
}


class PullAPI
{
    public static function fetchCities()
    {
        $res = file_get_contents('https://data.wa.gov/resource/2hia-rqet.json');
        $result = json_decode($res, true);
        //echo var_dump($result);
        return $result;
    }
}
