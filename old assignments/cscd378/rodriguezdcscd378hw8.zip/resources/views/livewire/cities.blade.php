@section('title')
Cities in Washington State
@endsection

<div class="Cities listed">
    <input wire:model="search" type="text" placeholder="Search by Name or State" size = 50 />
	<table class="table table-striped table-hover">
		<tr>
			<th>
				<a href="#" wire:click="doSort('name', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					City Name
				<a href="#" wire:click="doSort('name', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
			
			<th>
				<a href="#" wire:click="doSort('state', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					State
				<a href="#" wire:click="doSort('state', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
			
			<th>
				<a href="#" wire:click="doSort('population_2010', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					Population in 2010
				<a href="#" wire:click="doSort('population_2010', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
			
			<th>
				<a href="#" wire:click="doSort('population_rank', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					Population Rank
				<a href="#" wire:click="doSort('population_rank', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
		</tr>
	
		@foreach ($cities as $city)
			<tr>
				<td>{{$city->name}}</td>
				<td>{{$city->state}}</td>
				<td>{{$city->population_2010}}</td>
                <td>{{$city->population_rank}}</td>
			</tr>
		@endforeach
	</table>
<div>