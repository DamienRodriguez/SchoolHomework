<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| /cities
| Description: This is a website that is used to show that I understand how
| to utilize livewire to show searchables, and sorting in all fields.
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
Route::get('/cities', function() {
    $cities = App\Models\City::all();
    return view('cities', ['cities'=>$cities]);
});
 */

/*
Route::get('/cities', function() {
	return view('layouts.app');
});
*/

Route::get('/cities', App\Http\Livewire\Cities::class);
