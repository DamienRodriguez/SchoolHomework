<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
    <title>Cities List</title>
</head>
<body>
    <div class="hero bg-gray">
        <div class="hero-body">
          <h1>List of Arbitrary Cities</h1>
          <p>Posted by Damien Rodriguez</p>
        </div>
      </div>
    </div>

    <div class="Cities listed">
	<table class="table table-striped table-hover">
		<tr>
			<th>City Name</th>
			<th>State</th>
			<th>Population in 2010</th>
			<th>Population Rank</th>
		</tr>
	
		<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($city->name); ?></td>
				<td><?php echo e($city->state); ?></td>
				<td><?php echo e($city->population_2010); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\dis\Documents\School\Web Apps\assignment6\CityNameDbApp\resources\views/cities.blade.php ENDPATH**/ ?>