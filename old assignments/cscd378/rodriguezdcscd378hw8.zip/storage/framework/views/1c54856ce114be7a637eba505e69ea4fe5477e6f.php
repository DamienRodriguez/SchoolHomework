<?php $__env->startSection('title'); ?>
Cities in Washington State
<?php $__env->stopSection(); ?>

<div class="Cities listed">
    <input wire:model="search" type="text" placeholder="Search by Name or State" size = 50 />
	<table class="table table-striped table-hover">
		<tr>
			<th>
				<a href="#" wire:click="doSort('name', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					City Name
				<a href="#" wire:click="doSort('name', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
			
			<th>
				<a href="#" wire:click="doSort('state', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					State
				<a href="#" wire:click="doSort('state', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
			
			<th>
				<a href="#" wire:click="doSort('population_2010', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					Population in 2010
				<a href="#" wire:click="doSort('population_2010', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
			
			<th>
				<a href="#" wire:click="doSort('population_rank', 'asc')"><i class= "icon icon-arrow-up"></i></a>
					Population Rank
				<a href="#" wire:click="doSort('population_rank', 'desc')"><i class= "icon icon-arrow-down"></i></a>
			</th>
		</tr>
	
		<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($city->name); ?></td>
				<td><?php echo e($city->state); ?></td>
				<td><?php echo e($city->population_2010); ?></td>
                <td><?php echo e($city->population_rank); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<div><?php /**PATH C:\Users\dis\Documents\School\Web Apps\assignment6\CityNameDbApp\resources\views/livewire/cities.blade.php ENDPATH**/ ?>