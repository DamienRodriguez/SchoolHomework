<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
    
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div>
        <div class="container m-2">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
            <div class="mt=1">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\Users\dis\Documents\School\Web Apps\assignment6\CityNameDbApp\resources\views/layouts/app.blade.php ENDPATH**/ ?>