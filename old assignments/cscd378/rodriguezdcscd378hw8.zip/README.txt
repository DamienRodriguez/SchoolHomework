==========================
How to restore Vendor file
==========================
While in the root directory of the project, please type 'composer update' into the command line and press enters


==========================
How to view the page
==========================
To view the page the url is ~/cities

~ <- means relative url to how you have set up your php server. In the case of default, it would be
localhost:8000/cities
