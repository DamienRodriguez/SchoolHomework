<?php return array (
  'cities' => 'App\\Http\\Livewire\\Cities',
);