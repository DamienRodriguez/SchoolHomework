<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Baseballplayer;

class baseballplayerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
	Baseballplayer::factory()->count(100)->create();
    }
}
