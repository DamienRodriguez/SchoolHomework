<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBaseballplayersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('baseballplayers', function (Blueprint $table) {
		$table->id();
		$table->string('first_name');
		$table->string('last_name');
		$table->string('team');
		$table->char('jersey_num', 2);
		$table->char('position',2);
		$table->integer('age');
            	$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('baseballplayers');
    }
}
