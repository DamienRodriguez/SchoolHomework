<?php

namespace Database\Factories;

use App\Models\Baseballplayer;
use Illuminate\Database\Eloquent\Factories\Factory;

class baseballplayerFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Baseballplayer::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
	    //Yes, I know there is a better way to do both of the generations.
	    //No. I don't care.
	    $positions = [
		    'P','C','1B',
		    '2B','3B','SS',
		    'LF','CF','RF'
	    ];
	    shuffle($positions);



	    $faker = \Faker\Factory::create();
	    $faker->addProvider(new \Bezhanov\Faker\Provider\Team($faker));
	    return [
	    'first_name'=>$faker->firstname(),
	    'last_name'=>$faker->lastname(),
	    'team'=>$faker->team,
	    'jersey_num'=>$this->jersey_num_gen(),
	    'position'=>$positions[0],
	    'age'=>$faker->numberbetween(20,45),
	    ];
    }

    private function jersey_num_gen() {
    	$nums = [];
	for($i = 0; $i < 100; $i++){
		array_push($nums, (string)$i);	
	}

	array_push($nums, '00');

	for($j = 0; $j < 5; $j++) {
		shuffle($nums);
	}

	return $nums[0];
    }

}
