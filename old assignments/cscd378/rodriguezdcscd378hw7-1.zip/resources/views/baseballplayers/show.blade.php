@extends ('layout')


@section ('content')
<div class="card">
	<div class="card-header">
		<div class="card-title h5">{{$baseballplayer->first_name}} {{$baseballplayer->last_name}}</div>
		<div class="card-subtitle text-gray">{{$baseballplayer->team}}</div>
	</div>
	<div class="card-body">
		<p> Plays for the {{$baseballplayer->team}} as {{$baseballplayer->position}} </p>
		<p>Age: {{$baseballplayer->age}}
	</div>
	<div class="card-footer">
		<p> <a href="{{route('baseballplayers.index')}}"> Back to Main Page  </a> </p>                
	</div>
</div>
@endsection
