@extends('layout')
@section('content')
	<h1> Baseball Players </h1>
	{{$baseballplayers->links()}}

	<a class="btn btn-primary" href="{{route('baseballplayers.create')}}"> Add Baseball Player </a>
	<table class="table table-striped table-hover">
		<tr>
			<th>@sortablelink ('first_name', 'First Name')</th>
			<th>@sortablelink ('last_name', 'Last Name')</th>
			<th>@sortablelink ('team', 'Team')</th>
			<th>Jersey Number</th>
			<th>@sortablelink ('position', 'Position')</th>
			<th>Age</th>
			<th></th>
			<th></th>
			<th></th>
		</tr>
	@foreach ($baseballplayers as $baseballplayer)
		<tr>
			<td>{{$baseballplayer->first_name}}</td>
			<td>{{$baseballplayer->last_name}}</td>
			<td>{{$baseballplayer->team}}</td>
			<td>{{$baseballplayer->jersey_num}}</td>
			<td>{{$baseballplayer->position}}</td>
			<td>{{$baseballplayer->age}}</td>
			<td><a href="{{route('baseballplayers.show',$baseballplayer->id)}}">Show Details</a></td>
			<td>
				<form action="{{route('baseballplayers.destroy', $baseballplayer->id)}}" method="POST" onSubmit="return confirm('Are you sure that {{$baseballplayer->first_name}} {{$baseballplayer->last_name}} is retired?');">
					@csrf
					@method("DELETE")
					<button class="btn btn-error" type="submit">Delete</button>
				</form>
			</td>
			<td>
				<a class="btn btn-primary" href="{{route('baseballplayers.edit', $baseballplayer->id)}}">Update</a>
			</td>
		</tr>
	@endforeach
	</table>
	{!! $baseballplayers->appends(\Request::except('page'))->render() !!}
@endsection
