@extends('layout')

@section('content')
	<div class="column col-5">
		<h3>Update {{$baseballplayer->first_name}} {{$baseballplayer->last_name}} info</h3>
		@if ($errors->any())
			<div class="toast toast-error">
				@foreach ($errors->all() as $error)
					<span>{{$error}}</span> <br />	
				@endforeach
			
			</div>
		@endif
		<form method="POST" action="{{route('baseballplayers.update', $baseballplayer->id)}}">
		@csrf
		@method('PUT')
			<div class="form-group">
				<label class="form-label" for "first_name">
					First Name
				</label>
				<input class="form-input" type="text" name="first_name" id="first_name" value = "{{$baseballplayer->first_name}}">


				<label class="form-label" for "last_name">
					Last Name
				</label>
				<input class="form-input" type="text" name="last_name" id="last_name" value = "{{$baseballplayer->first_name}}">
				

				<label class="form-label" for "team">
					Team	
				</label>
				<input class="form-input" type="text" name="team" id="team" value = "{{$baseballplayer->team}}">


				<label class="form-label" for "jersey_num">
					Jersey Number	
				</label>

				<select class="form-label" for "jersey_num" id "jersey_num" name="jersey_num">
					<option value="00">00</option>
					<option value="01">01</option>
					<option value="02">02</option>
					<option value="03">03</option>
					<option value="04">04</option>
					<option value="05">05</option>
					<option value="06">06</option>
					<option value="07">07</option>
					<option value="08">08</option>
					<option value="09">09</option>
					
					@foreach (range(0,99) as $num)
						<option value="{{$num}}">{{$num}}</option>
					@endforeach
				</select>


				<label class="form-label" for "position">
					Position	
				</label>
				<select class="form-label" for "position" id "position" name="position">
					<option value="C">C</option>
					<option value="P">P</option>
					<option value="1B">1B</option>
					<option value="2B">2B</option>
					<option value="3B">3B</option>
					<option value="SS">SS</option>
					<option value="LF">LF</option>
					<option value="CF">CF</option>
					<option value="RF">RF</option>
				</select>

				<label class="form-label" for "age">
					Age	
				</label>
				<select class="form-label" for "age" id "age" name="age">
					@foreach (range(16,50) as $age)
						<option value="{{$age}}">{{$age}}</option>
					@endforeach
				</select>


				<button type="submit" class="btn btn-secondary">Finalize Edits</button>
				<a href="{{route('baseballplayers.index')}}">Cancel</a>				
			</div>
		</form>
	</div>

@endsection('content')
