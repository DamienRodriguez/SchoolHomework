<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Baseballplayer;

class BaseballplayerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	$baseballplayers = Baseballplayer::sortable()->paginate(20);
	
       	return view('baseballplayers.index',compact('baseballplayers')); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('baseballplayers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $validatedData = $request->validate([
            'first_name'=>['required','alpha'],
            'last_name'=>['required', 'alpha'],
	    'team'=>['required'],
	    'jersey_num'=>['required'],
	    'position'=>['required'],
	    'age'=>['required']
        ]);

        \App\Models\Baseballplayer::create($validatedData);

        return redirect()->route('baseballplayers.index')->with('success', "Baseball player was added successfuly");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $baseballplayer = \App\Models\Baseballplayer::find($id);
        return view('baseballplayers.show', ['baseballplayer'=>$baseballplayer]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	$baseballplayer = \App\Models\Baseballplayer::find($id);
	return view('baseballplayers.edit', ['baseballplayer'=>$baseballplayer]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $validatedData = $request->validate([
            'first_name'=>['required','alpha'],
            'last_name'=>['required', 'alpha'],
	    'team'=>['required'],
	    'jersey_num'=>['required'],
	    'position'=>['required'],
	    'age'=>['required']
        ]);

        \App\Models\Baseballplayer::find($id)->update($validatedData);

        return redirect()->route('baseballplayers.index')->with('success', "Baseball players info were updated.");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
	$retired = \App\Models\Baseballplayer::find($id);
	$retired->delete();
	    
	    
        return redirect()->route('baseballplayers.index')->with('success', "$retired->first_name $retired->last_name has retired");

    }
}
