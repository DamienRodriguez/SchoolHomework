<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Baseballplayer extends Model
{
	use HasFactory;
	use Sortable;


	protected $fillable = [
		'first_name',
		'last_name',
		'team',
		'jersey_num',
		'position',
		'age'
	];


	public $sortable= [
		'first_name',
		'last_name',
		'team',
		'position'
	];
}
