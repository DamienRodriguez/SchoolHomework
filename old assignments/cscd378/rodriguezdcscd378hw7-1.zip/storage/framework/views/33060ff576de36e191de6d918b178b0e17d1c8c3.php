


<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header">
		<div class="card-title h5"><?php echo e($baseballplayer->first_name); ?> <?php echo e($baseballplayer->last_name); ?></div>
		<div class="card-subtitle text-gray"><?php echo e($baseballplayer->team); ?></div>
	</div>
	<div class="card-body">
		<p> Plays for the <?php echo e($baseballplayer->team); ?> as <?php echo e($baseballplayer->position); ?> </p>
		<p>Age: <?php echo e($baseballplayer->age); ?>

	</div>
	<div class="card-footer">
		<p> <a href="<?php echo e(route('baseballplayers.index')); ?>"> Back to Main Page  </a> </p>                
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dis\Documents\School\Web Apps\assignment7\baseballplayers\resources\views/baseballplayers/show.blade.php ENDPATH**/ ?>