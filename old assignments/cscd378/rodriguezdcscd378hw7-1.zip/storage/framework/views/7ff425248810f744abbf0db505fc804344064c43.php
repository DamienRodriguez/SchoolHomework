

<?php $__env->startSection('content'); ?>
	<div class="column col-5">
		<h3>Update <?php echo e($baseballplayer->first_name); ?> <?php echo e($baseballplayer->last_name); ?> info</h3>
		<?php if($errors->any()): ?>
			<div class="toast toast-error">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<span><?php echo e($error); ?></span> <br />	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			</div>
		<?php endif; ?>
		<form method="POST" action="<?php echo e(route('baseballplayers.update', $baseballplayer->id)); ?>">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
			<div class="form-group">
				<label class="form-label" for "first_name">
					First Name
				</label>
				<input class="form-input" type="text" name="first_name" id="first_name" value = "<?php echo e($baseballplayer->first_name); ?>">


				<label class="form-label" for "last_name">
					Last Name
				</label>
				<input class="form-input" type="text" name="last_name" id="last_name" value = "<?php echo e($baseballplayer->first_name); ?>">
				

				<label class="form-label" for "team">
					Team	
				</label>
				<input class="form-input" type="text" name="team" id="team" value = "<?php echo e($baseballplayer->team); ?>">


				<label class="form-label" for "jersey_num">
					Jersey Number	
				</label>

				<select class="form-label" for "jersey_num" id "jersey_num" name="jersey_num">
					<option value="00">00</option>
					<option value="01">01</option>
					<option value="02">02</option>
					<option value="03">03</option>
					<option value="04">04</option>
					<option value="05">05</option>
					<option value="06">06</option>
					<option value="07">07</option>
					<option value="08">08</option>
					<option value="09">09</option>
					
					<?php $__currentLoopData = range(0,99); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($num); ?>"><?php echo e($num); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>


				<label class="form-label" for "position">
					Position	
				</label>
				<select class="form-label" for "position" id "position" name="position">
					<option value="C">C</option>
					<option value="P">P</option>
					<option value="1B">1B</option>
					<option value="2B">2B</option>
					<option value="3B">3B</option>
					<option value="SS">SS</option>
					<option value="LF">LF</option>
					<option value="CF">CF</option>
					<option value="RF">RF</option>
				</select>

				<label class="form-label" for "age">
					Age	
				</label>
				<select class="form-label" for "age" id "age" name="age">
					<?php $__currentLoopData = range(16,50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($age); ?>"><?php echo e($age); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>


				<button type="submit" class="btn btn-secondary">Finalize Edits</button>
				<a href="<?php echo e(route('baseballplayers.index')); ?>">Cancel</a>				
			</div>
		</form>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dis\Documents\School\Web Apps\assignment7\baseballplayers\resources\views/baseballplayers/edit.blade.php ENDPATH**/ ?>