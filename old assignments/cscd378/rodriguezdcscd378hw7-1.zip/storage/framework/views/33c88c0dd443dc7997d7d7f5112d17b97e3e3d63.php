
<?php $__env->startSection('content'); ?>
	<h1> Baseball Players </h1>
	<?php echo e($baseballplayers->links()); ?>


	<a class="btn btn-primary" href="<?php echo e(route('baseballplayers.create')); ?>"> Add Baseball Player </a>
	<table class="table table-striped table-hover">
		<tr>
			<th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('first_name', 'First Name'));?></th>
			<th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('last_name', 'Last Name'));?></th>
			<th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('team', 'Team'));?></th>
			<th>Jersey Number</th>
			<th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('position', 'Position'));?></th>
			<th>Age</th>
			<th></th>
			<th></th>
			<th></th>
		</tr>
	<?php $__currentLoopData = $baseballplayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baseballplayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($baseballplayer->first_name); ?></td>
			<td><?php echo e($baseballplayer->last_name); ?></td>
			<td><?php echo e($baseballplayer->team); ?></td>
			<td><?php echo e($baseballplayer->jersey_num); ?></td>
			<td><?php echo e($baseballplayer->position); ?></td>
			<td><?php echo e($baseballplayer->age); ?></td>
			<td><a href="<?php echo e(route('baseballplayers.show',$baseballplayer->id)); ?>">Show Details</a></td>
			<td>
				<form action="<?php echo e(route('baseballplayers.destroy', $baseballplayer->id)); ?>" method="POST" onSubmit="return confirm('Are you sure that <?php echo e($baseballplayer->first_name); ?> <?php echo e($baseballplayer->last_name); ?> is retired?');">
					<?php echo csrf_field(); ?>
					<?php echo method_field("DELETE"); ?>
					<button class="btn btn-error" type="submit">Delete</button>
				</form>
			</td>
			<td>
				<a class="btn btn-primary" href="<?php echo e(route('baseballplayers.edit', $baseballplayer->id)); ?>">Update</a>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo $baseballplayers->appends(\Request::except('page'))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dis\Documents\School\Web Apps\assignment7\baseballplayers\resources\views/baseballplayers/index.blade.php ENDPATH**/ ?>