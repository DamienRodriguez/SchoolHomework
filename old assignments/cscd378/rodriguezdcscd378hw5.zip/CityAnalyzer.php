<?php
// Damien Rodriguez
// This is our back-end programming interface.
// This will create an array of city objects based
// on the decrypted JSON file pulled from the CensusAPI.
// This code has functions that will display the top
// 10 population cities, the bottom 10 population cities,
// and to display one random city.
    
    
    
    
require 'City.php';

class CityAnalyzer
{
    private $city_array = array();
    public function __construct($jsonpayload)
    {
        $this->set_array($jsonpayload);
    }

    private function set_array($array)
    {
        for ($i = 0; $i < count($array); $i++) {
            $temp = new City($array[$i]['jurisdiction'], $array[$i]['pop_2020']);
            if ($this->checkForCity($temp)) {
                array_push($this->city_array, $temp);
            }
        }
    }

    public function printHighestPopulatedCities()
    {
        echo "10 highest populated cities:\r\n";
        echo "——————————————————————————-\r\n";
        usort($this->city_array, function ($city1, $city2) {
            if ($city1->get_population() == $city2->get_population()) {
                return 0;
            }
            return ($city1->get_population() > $city2->get_population()) ? -1 : 1;
        });

        $this->printTen();
        echo "\r\n";
    }

    private function printTen()
    {
        for ($i = 0; $i < 10; $i++) {
            $temp = $this->city_array[$i];
            echo $temp->toString();
            echo "\r\n";
        }
    }

    public function printLowestPopulatedCities()
    {
        echo "10 lowest populated cities:\r\n";
        echo "——————————————————————————-\r\n";
        usort($this->city_array, function ($city1, $city2) {
            if ($city1->get_population() == $city2->get_population()) {
                return 0;
            }
            return ($city1->get_population() < $city2->get_population()) ? -1 : 1;
        });

        $this->printTen();
        echo "\r\n";
    }

    private function checkForCity($city)
    {
        if (strpos($city->get_name(), "Total") >= 1) {
            return false;
        }

        if (strpos($city->get_name(), "corporated") >= 1) {
            return false;
        }

        if (strpos($city->get_name(), "County") >= 1) {
            return false;
        }

        if (strpos($city->get_name(), "(part)") >= 1) {
            return false;
        }

        return true;
    }

    public function randomCity()
    {
        $temp = $this->city_array[random_int(0, count($this->city_array) - 1)];
        $temp = $temp->toString();
        echo "Random City: $temp";
    }
}
