<?php
//Damien Rodriguez
//This is the API calling code that will fetch the cities JSON file that is located at the below address
//Guzzler was not used on the account that it was throwing an SSL error that seemed to take too long to fix
//because it required an SSL certificate to a dedicated web server.


class CensusAPI
{
    public static function fetchCities()
    {
        $res = file_get_contents('https://data.wa.gov/resource/2hia-rqet.json');
        $result = json_decode($res, true);
        //echo var_dump($result);
        return $result;
    }
}
