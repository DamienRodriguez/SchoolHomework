
<?php
//Damien Rodriguez
//This code is the data class for cities found within the JSON file pulled from
//the CensusAPI call

class City
{
    private $name;
    private $population;

    public function __construct($name, $population)
    {
        $this->set_name($name);
        $this->set_population($population);
    }

    private function set_name($name)
    {
        $this->name = $name;
    }

    private function set_population($population)
    {
        $this->population = (int) $population;
    }

    public function get_population()
    {
        return $this->population;
    }

    public function get_name()
    {
        return $this->name;
    }

    public function toString()
    {
        $return = $this->name . " (";
        $return = $return . (string) $this->population;
        $return = $return . ")\r\n";
        return $return;
    }
}
