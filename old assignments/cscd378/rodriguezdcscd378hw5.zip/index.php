<?php
//Damien Rodriguez
//This is the driver code for our PHP and External Data assignment.



require_once "CityAnalyzer.php";
require_once "CensusAPI.php";

echo "Population report for 2020\r\n==========================\r\n";
$analyzer = new CityAnalyzer(CensusAPI::fetchCities());
$analyzer->printHighestPopulatedCities();
$analyzer->printLowestPopulatedCities();
$analyzer->randomCity();