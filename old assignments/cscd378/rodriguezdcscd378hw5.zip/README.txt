Hello Valient Grader!

In order to run this piece of computer magic, you will need to run the 'index.php' program.

There aren't any external libraries being used in this programming example.
