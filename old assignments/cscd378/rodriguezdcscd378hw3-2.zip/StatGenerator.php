<?php
/*
Name: Damien Rodriguez
Description: This program takes an external PHP file, includes it, where it holds data to be parsed and displayed based
on a set of critieria, such as not using HTML. In this case, it displays it to the command line, as well as a page if loaded through localhost:8000
The data in question is regarding a baseball player, and 5 games where his stats were recorded.
EXTRA CREDIT WAS ATTEMPTED
 */
include_once 'BaseballPlayer.php';

$name = Player::get_stats()["name"]; //name of player
$total_stats = generate_stats(Player::get_stats()["games"]);
$total_games = count(Player::get_stats()["games"]);

echo str_pad("Name",24);
echo str_pad("G", 10);
echo str_pad("AB", 10);
echo str_pad("R", 10);
echo str_pad("H", 10);
echo str_pad("BB", 10);
echo str_pad("RBI", 10);
echo str_pad("BA", 10);
echo "\r\n";
//echo "G\tAB\tR\tH\tBB\tRBI\t BA\r\n";

echo str_pad($name, 24);
echo str_pad($total_games, 10);   //total games
echo str_pad($total_stats[0], 10);    //at bat
echo str_pad($total_stats[1], 10);    //runs
echo str_pad($total_stats[2], 10);    //hits
echo str_pad($total_stats[3], 10);    //Runs batted in
echo str_pad($total_stats[4], 10);    //batting aver
echo str_pad($total_stats[5], 10);

//echo "$total_games\t$total_stats[0]\t$total_stats[1]\t$total_stats[2]\t$total_stats[3]\t$total_stats[4]\t$total_stats[5]";

function generate_stats($games)
{
    $total_AB = 0;
    $total_R = 0;
    $total_H = 0;
    $total_BB = 0;
    $total_RBI = 0;

    foreach ($games as $i_game) {
        $total_AB += $i_game['AB'];
        $total_R += $i_game["R"];
        $total_H += $i_game["H"];
        $total_BB += $i_game["BB"];
        $total_RBI += $i_game["RBI"];
    }

    $batting_average = number_format($total_H / $total_AB, 3);
    $batting_average = ltrim($batting_average, "0");


    return array($total_AB, $total_R, $total_H, $total_BB, $total_RBI, $batting_average);
}