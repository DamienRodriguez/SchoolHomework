Hello Oh Merciful Grader,

My assignment uses a library that is turned off by default when running php.

In order to turn this library on, you will need to the following:

1. Go to where you have installed PHP. In my case it is C:\php
2. Go to where your php.ini file is located
3. Crtl + F and type "intl" (be sure the setting for direction if you are using notepad like I am is selected to Down)
4. Click the "Find Next" button 
	4.1 You will be looking for a command that looks like ";extension=intl"
5. After you have found the command stated above, remove the ; from the beginning of the command
6. Restart your PHP server to ensure it takes effect

Now you are ready to enter the "index.html" and begin your meticulous grading process!

Have a wonderful day :)