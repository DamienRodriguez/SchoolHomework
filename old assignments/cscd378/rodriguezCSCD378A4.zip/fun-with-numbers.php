<!-- This is the results page that displays the various requirements of this assignment -->
<!-- At the bottom of the page is a button that allows the user to return to the first page -->
<!-- to continue any other testing -->

<!-- Created by: Damien A Rodriguez -->

<!DOCTYPE html>
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="php">
        
    <!-- I'm sorry Harley. -->
    <?php

        //These will determine what results we need to print to the screen.
        $integer = $_REQUEST['number'];
        $names = $_REQUEST['names']; //returns a string that says either "on" or "off"
        $pfactors = $_REQUEST['pfactors'];
        $divisors = $_REQUEST['divisors'];
        $bequivalents = $_REQUEST['bequivalents'];
        $sqAndRts = $_REQUEST['sqAndRts'];
        $ffacts = $_REQUEST['ffacts'];

        print_results($integer, $names, $pfactors, $divisors, $bequivalents, $sqAndRts, $ffacts);

        function print_results($integer, $names, $pfactors, $divisors, $bequivalents, $sqAndRts, $ffacts) {

            if(strcmp($names, "on") == 0) {
                $text = Numbers::integerToEnglish($integer);
                $roman = Numbers::integerToRoman($integer);
                echo "<h3>Names</h3>";
                echo "Your number: <b>$integer</b><br>";
                echo "Your number written in English: $text<br>";
                echo "Your number written in Roman Numerals: $roman<br><hr>";
            }

            if(strcmp($pfactors, "on") == 0) {
                echo "<h3> Prime Factors of <b>$integer</b></h3>";
                echo "Prime Factors: ";
                
                $display = Numbers::primefactor($integer);
                sort($display);
                
                $stop = sizeof($display);
                for($i = 0; $i < $stop; $i++) {
                    echo "$display[$i] ";
                }
                echo"<br>";
                echo "<hr>";
            }

            if(strcmp($divisors, "on") == 0) {
                echo "<h3> Divisors of <b>$integer</b></h3>";
                echo "List of Divisors: ";
                Numbers::arrayOfDivisors($integer);
                echo "<br>";
                echo "<hr>";
            }


            if(strcmp($bequivalents, "on") == 0) {
                echo "<h3> Base Equivalents of <b>$integer</b></h3>";
                echo "Binary : ";
                echo Numbers::decToBin($integer);
                echo "<br>";

                echo "Octal: ";
                echo Numbers::decToOct($integer);
                echo "<br>";

                echo "Hexidecimal: ";
                echo Numbers::decToHex($integer);
                echo "<br>";
                echo "<hr>";
            }

            if(strcmp($sqAndRts, "on") == 0) {
                echo "<h3> Squares and Roots of <b>$integer</b></h3>";
                echo "<b>$integer</b> squared: ";
                echo Numbers::numSquared($integer);
                echo "<br>";

                echo "<b>$integer</b> cubed: ";
                echo Numbers::numCubed($integer);
                echo "<br>";

                echo "Square root of <b>$integer</b> : ";
                echo number_format(Numbers::numSqrt($integer), 7);
                echo "<br>";

                echo "Cube root of <b>$integer</b> : ";
                echo  number_format(Numbers::numCubeRoot($integer), 7);
                echo "<br>";
                echo "<hr>";
            }

            if(strcmp($ffacts, "on") == 0) {
                echo "<h3> Fun Facts! </h3>";
                echo "Number of Digits in your number : ";
                echo Numbers::numOfDigits($integer);
                echo "<br>";

                echo "Sum of Digits in your number: ";
                Numbers::sumOfDigits($integer);
                echo "<br>";

                echo "Your number printed backwards: ";
                echo Numbers::reverseNum($integer);
                echo "<br>";
                echo "<hr>";
            }
        }

        class Numbers {

            //Names
            //URL of Code: https://www.hashbangcode.com/article/php-function-turn-integer-roman-numerals
            //Date of retrival: 04/26/2021
            public static function integerToRoman($integer) {
                // Convert the integer into an integer (just to make sure)
                $integer = intval($integer);
                $result = '';
                
                // Create a lookup array that contains all of the Roman numerals.
                $lookup = array('M' => 1000,
                'CM' => 900,
                'D' => 500,
                'CD' => 400,
                'C' => 100,
                'XC' => 90,
                'L' => 50,
                'XL' => 40,
                'X' => 10,
                'IX' => 9,
                'V' => 5,
                'IV' => 4,
                'I' => 1);
                
                foreach($lookup as $roman => $value) {
                // Determine the number of matches
                $matches = intval($integer/$value);
                
                // Add the same number of characters to the string
                $result .= str_repeat($roman,$matches);
                
                // Set the integer to be the remainder of the integer and the value
                $integer = $integer % $value;
                }
                
                // The Roman numeral should be built, return it
                return $result;
            }

            public static function integerToEnglish($integer) {
                $formatter = numfmt_create("en", NumberFormatter::SPELLOUT);
                return $formatter->format($integer); 
            }
            
            //Prime Factors
            //URL: https://www.fusionswift.com/2010/06/php-prime-factors/
            //Date Accessed: 04/26/2021
            public static function primefactor($num) {
                $sqrt = sqrt($num);
                for ($i = 2; $i <= $sqrt; $i++) {
                    if ($num % $i == 0) {
                        return array_merge(Numbers::primefactor($num/$i), array($i));
                    }
                }
                return array($num);
            }


            //Divisors
            public static function arrayOfDivisors($integer) {
                for($i = 1; $i <= $integer; $i++) {
                    if($integer % $i == 0)
                        echo "$i ";
                }
            }


            //Base Equivalents
            public static function decToBin($integer) {
                return decbin($integer);
            }

            public static function decToOct($integer) {
                return decoct($integer);
            }

            public static function decToHex($integer) {
                return dechex($integer);
            }


            //Squares and Roots
            public static function numSquared($integer) {
                return $integer * $integer;
            }

            public static function numCubed($integer) {
                return $integer * $integer * $integer;
            }

            public static function numSqrt($integer) {
                return sqrt($integer);
            }

            public static function numCubeRoot($integer) {
                return pow($integer, (1.0/3.0));
            }

            
            //Fun Facts
            public static function numOfDigits($integer) {
                return strlen($integer);
            }

            public static function sumOfDigits($integer) {
                $total = 0;
                
                while($integer != 0) {
                    $temp = $integer % 10; //gives us a digit to work with
                    $total += $temp;
                    $integer = intdiv($integer, 10);
                }

                echo $total;
            }

            public static function reverseNum($integer) {
                return strrev($integer);
            }
        }
    ?>
    </div>
    <form action="index.html">
        <button type="btn-lg">Back to the landing page! </button>
    </form>

</body>
</html>

