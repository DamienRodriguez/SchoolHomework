<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| /cities
| Description: This will take the user to a website that has a list
| of arbitrary, fake cities. This is for an assignment that is meant
| show that students are able to create migrations, models, and interact
| with sqlite from a *.blade.php model
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/cities', function() {
    $cities = App\Models\City::all();
    return view('cities', ['cities'=>$cities]);
});
