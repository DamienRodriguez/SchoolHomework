package cscd210Methods;

import java.util.Scanner;

public class CSCD210Lab6Methods
{
   
   public static void lightOrHeavy(int theNum, java.util.Scanner kb)
   {
      if(theNum < 1)
         throw new IllegalArgumentException("PEBCAK at light or heavy");
      if(kb == null)
         throw new IllegalArgumentException("Get a new programmer");
      
      
      int t1 = 0, t2 = 0, remainder = 0, num2, count = 0;
      
      do
      {
         System.out.println("Please enter a second non negative integer: ");
         num2 = kb.nextInt();
      } while(num2 <= 0);
       
      count = 0;
      while(theNum != 0)
      {
         remainder = theNum % 10;
               
         t1+=remainder;
         theNum = theNum / 10;
         count++;
      }
            
      t1 = t1 / count;
          
      count = 0;
            
      while(num2 != 0)
      {
      remainder = num2 % 10;
               
      t2+=remainder;
      num2 = num2 / 10;
      count++;
      }
            
      t2 = t2 / count;

            
      if(t1 > t2)
         System.out.println("Your number is heavy.");
      else
         System.out.println("Your number is light.");
   }
   
   
   
   
   
   public static int menu(java.util.Scanner kb)
   {
      int choice;
      
      if(kb == null)
         throw new IllegalArgumentException("Scanner Broke in menu, get a new programmer, this one sucks xD");
      
   
      do
      {      
         System.out.println("Please choose from the following menu: ");
         System.out.println("\t 1. Enter a new number");
         System.out.println("\t 2. Print the number of odd digits, even digits, and zeroes in the integer");
         System.out.println("\t 3. Print if the number is light or heavy");
         System.out.println("\t 4. Print the prime numbers between 2 and the integer (inclusive)");
         System.out.println("\t 5. Quit");
         
         System.out.println("Enter your choice ---> ");
         choice = kb.nextInt();
      }while(choice < 1 || choice > 5);
      
      return choice;
         
   }
   
   public static void oddEvenZero(int theNum)
   {
      if(theNum < 1)
         throw new IllegalArgumentException("PEBCAK in odd even zero method");
      
      int evens = 0, odds = 0, zeroes = 0, remainder = 0;
      
      evens = 0;
      odds = 0;
      zeroes = 0;
            
      while(theNum != 0)
      {
         remainder = theNum % 10;
               
         if(remainder == 0)
               zeroes++;
         else if(remainder % 2 == 0)
               evens++;
         else
               odds++;
               
         theNum = theNum / 10;
      }
            
      System.out.println("There are " + zeroes + " zeroes, " + odds + " odds, and " + evens + " evens in your number.");
      
   }
   public static void printPrimes(int theNum)
   {
      if(theNum < 1)
         throw new IllegalArgumentException("PEBCAK at printPrimes");
      
      int myFlag = 0;
         
      System.out.println("The prime numbers between 2 and " + theNum + " are: ");
      System.out.println(2);                             
            
            
      for(int i = 2; i <= theNum; i++)                      
      {

         for(int j = 2; j < i; j++)                      
         {              
            if(i == 2)
               myFlag = 1;
                     
            else if(i % j == 0)
            {
               myFlag = 0;
               break;
            }
                  
            else
               myFlag = 1;      
         }
               
         if(myFlag == 1)
         {
            System.out.println(i);
         }      
      }
   
   }
   public static int readPosNum(java.util.Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Scanner broken, also programmer.");
    
    
      int num;
      do
      {
         System.out.println("Please enter a non negative integer: ");
         num = kb.nextInt();
      }while(num <= 0);
      
      return num;
   }
}