package cscd210Classes;

import java.util.Scanner;
import java.io.*;

public class Book implements Comparable<Book>
{
   private String[] authors;
   private String isbn;
   private int pages;
   private String title;
   
   public Book(final String title, final String isbn, final int pages, final String[] authors)
   {
      if(title == null || isbn == null || title.isEmpty() || isbn.isEmpty() || pages < 1 || authors == null || authors.length < 0)
         throw new IllegalArgumentException("Bad bananas in Book EVC");
      
      this.title = title;
      this.isbn = isbn;
      this.pages = pages;
      this.authors = new String[authors.length];
      
      for(int x = 0; x < this.authors.length; x++)
      {
         this.authors[x] = authors[x];
         
      }
   }
   
   public String getISBN() {return this.isbn;}
   
   @Override
   public String toString()
   {
      String str = "Title: " + this.title + " CR Author(s): ";
      
      for(int x = 0; x < this.authors.length - 1; x++)
      {
         str = str.concat(this.authors[x] + ", ");
      }
      
      str = str + this.authors[this.authors.length - 1] + " CR ISBN: " + this.isbn;
      
      return str;
   }
   
   @Override
   public boolean equals(Object obj)
   {
      if(obj == null)
         throw new IllegalArgumentException("bad bananas in equals method");
      
      if(obj == null)
         return false;
      if(obj == this)
         return true;
      if(!(obj instanceof Book))
         return false;
      
      Book b = (Book)obj;
      
      if(this.title == b.title && this.isbn == b.isbn && this.pages == b.pages && this.authors == b.authors)
         return true;
      
      return false;
   }
   
   
   @Override
   public int hashCode()
   {
      int res = this.title.hashCode() + this.isbn.hashCode() + this.pages;
      return res;
   }
   
   @Override
   public int compareTo(Book another)
   {
      if(another == null)
         throw new IllegalArgumentException("I don't know any.");
      
      int res = this.title.compareTo(another.title);
      if(res != 0)
         return res;
      
      res = this.pages - another.pages;
      
      if(res != 0)
         return res;
      
      return this.isbn.compareTo(another.isbn);
   }

}
