package cscd210Comparators;
import java.util.Comparator;
import cscd210Classes.Book;

public class BookISBNComparator implements Comparator<Book>
{
   public int compare(final Book b1, final Book b2)
   {
      String str1 = b1.getISBN();
      String str2 = b2.getISBN();
      return str1.compareTo(str2);
   }
}