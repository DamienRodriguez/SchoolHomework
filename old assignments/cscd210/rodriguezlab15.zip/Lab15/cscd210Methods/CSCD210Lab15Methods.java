package cscd210Methods;

import java.util.Scanner;
import java.io.*;
import cscd210Classes.Book;


public class CSCD210Lab15Methods
{

   public static Book[] fillArray(Scanner fileIn, int total)
   {
      if(fileIn == null || total < 1)
         throw new IllegalArgumentException("bad baboons in fillArray");
      
      Book[] array = new Book[total];
      
      
      for(int x = 0; x < array.length; x++)
      {
         String str = fileIn.nextLine();
         String[] temp = str.split(",");
         String[] authors = new String[temp.length-3];
         
         if(temp.length < 4)
            throw new RuntimeException("Invalid data in file");
         
         //working as intended
         for(int y = 0; y < authors.length; y++)
         {
            authors[y] = temp[y+3];
            System.out.println(authors[y]);

         }
         array[x] = new Book(temp[0], temp[1], Integer.parseInt(temp[2].trim()), authors);       
      }
      
      return array;
   }
   
   
   public static Book[] addBook(Book[] array, Book aBook)
   {
      if(array == null || array.length < 1 || aBook == null)
         throw new IllegalArgumentException("bad params in addBook");
      
      Book [] newArray = new Book[array.length + 1];
      
      for(int x = 0; x < array.length; x++)
      {
         newArray[x] = array[x];
      }
      
      newArray[newArray.length -1] = aBook;
      
      return newArray;
   }
   
   public static Book createBook(Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad bah bombs in createBook");
         
      String tempTitle, tempISBN, tempAuthor;
      int tempPages, numOf;
      
      
      do
      {
         tempTitle = readString("Title", kb);
      }while(tempTitle.isEmpty());
      
      do
      {
         tempISBN = readString("ISBN", kb);
      }while(tempISBN.isEmpty());
      
      do
      {
         tempPages = Integer.parseInt(readString("Pages",kb));
      }while(tempPages < 1);
      
      do
      {
         System.out.println("Please enter the amount of authors ----->");
         numOf = kb.nextInt();
         kb.nextLine();
         
      }while(numOf < 1);
      
      String[] tempAuthors = new String[numOf];
      
      for(int x = 0; x < tempAuthors.length; x++)
      {
         tempAuthor = readString("Author " + x+1, kb);
         tempAuthors[x] = tempAuthor;
      }
      
      Book newBook = new Book(tempTitle, tempISBN, tempPages, tempAuthors);
      
      return newBook;
      
   }
   
   public static int menu(Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad params in menu");
      
      int choice = 0;
      
      do
      {   
         System.out.println("Please select from the following menu: ");
         System.out.println("1)Print the books to the screen");
         System.out.println("2)Print the books to a file");
         System.out.println("3) Sort the books based on natural order");
         System.out.println("4) Sort the books based on total order");
         System.out.println("5) Add a new book to the bookshelf");
         System.out.println("6) Search the bookshelf for a book");
         System.out.println("7) Quit");
         System.out.println("Enter your choice ----->");
         
         choice = kb.nextInt();
         kb.nextLine();
      }while(choice < 0 || choice > 7);
  
      return choice;
   }
   
   public static void printBooks(Book[] array, PrintStream output)
   {
      if(array == null || array.length < 1 || output == null)
         throw new IllegalArgumentException("bad blah blah in printBooks");
      
      
      for(Book s: array)
          output.println(s);
   }
   
   
   public static String readOutputFilename(Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("problems in readOutputFilename my dude");
      
      String str = readString("output file name", kb);
      
      return str;
   }
   
   
   private static String readString(String type, Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad pineapples readString");
      
      String str;
      
      System.out.println("Please enter the " + type + " ----->");
      str = kb.nextLine();
      
      return str;
   }
   
}