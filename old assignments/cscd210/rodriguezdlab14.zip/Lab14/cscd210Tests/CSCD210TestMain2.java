package cscd210Tests;

import java.util.Scanner;
import cscd210Utils.SortUtils;
import cscd210Classes.Rational;

public class CSCD210TestMain2
{
   public static void main(String [] args)
   {
      Rational test1 = new Rational();
      Rational test2 = new Rational(7,8);
      
      //Rational dummy = new Rational(1,0);
      
      //Rational dummyAdd = test1.add(null);
      //int dummyResult = test1.compareTo(null);
      
      //uncommenting out these will pre conditions from the top down in Rational.java
   }
}