package cscd210Tests;

import java.util.Scanner;
import cscd210Utils.SortUtils;
import cscd210Classes.Rational;

public class CSCD210TestMain1
{
   public static void main(String [] args)
   {
      Rational [] array = {new Rational(), new Rational(2015,456456), new Rational(-1,3), new Rational(314, 42), new Rational(5, 678453), new Rational(98, -65), new Rational(1331, 3113), new Rational(254, 4352), new Rational(61,61)};
      
      for(Rational r: array)
         System.out.println("The Rational Number is " + r);
      
      System.out.println();
      System.out.println("Testing add method");
      System.out.println();
      
      for(int y = 0; y < array.length; y++)
      {
         for(int x = 1; x < array.length; x++)
         {
            Rational addRational = array[y].add(array[x]);
            System.out.println("Adding together " + array[y] + " and " + array[x] + " is ");
            System.out.println(addRational);
            System.out.println();
         }
      }
      
      System.out.println();
      
      System.out.println("Tested adding the different rationals together");
      
      System.out.println("Now testing reciprocal of every element in the array");
      System.out.println();
      
      for(int x = 0; x < array.length; x++)
      {
         Rational rec = array[x].reciprocal();
         System.out.println(rec);
      }
      
      System.out.println();
      System.out.println("Tested Reciprocals");
      System.out.println("Now testing equals method");
      
      for(int y = 0; y < array.length; y++)
      {
         for(int x = 1; x < array.length; x++)
         {
            if(array[y].equals(array[x]))
               System.out.println(array[y] + " and " + array[x] + " are equal.");
            else
               System.out.println(array[y] + " and " + array[x] + " are not equal.");
         }
      }
      
      System.out.println();
      System.out.println("Tested the equals method");
      System.out.println("Testing hash code method");
      System.out.println();
      
      int i_temp = 0;
      
      for(int x = 0; x < array.length; x++)
      {
         i_temp = array[x].hashCode();
         System.out.println(i_temp);
      }
      
      System.out.println();
      System.out.println("Hash code tested.");
      System.out.println("Now testing toString method");
      System.out.println();
      
      String s_temp = "";
      
      
      for(int x = 0; x < array.length; x++)
      {
         s_temp = array[x].toString();
         System.out.println(s_temp);
      }
      
      System.out.println();
      System.out.println("to String has been tested.");
      System.out.println("Testing compareTo method");
      System.out.println();
      
      i_temp = 0;
      for(int y = 0; y < array.length; y++)
      {
         for(int x = 1; x < array.length; x++)
         {
            i_temp = array[y].compareTo(array[x]);
            if(i_temp < 0)
               System.out.println(array[y] + " is less than " + array[x]);
            else if (i_temp > 0)
               System.out.println(array[y] + " is greater than " + array[x]);
            else
               System.out.println(array[y] + " is the same as " + array[x]);
         }
      }
   }
}