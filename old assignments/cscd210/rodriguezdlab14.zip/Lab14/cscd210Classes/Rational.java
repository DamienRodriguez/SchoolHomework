package cscd210Classes;

import java.util.Scanner;
import java.io.*;
import java.math.BigInteger;

public class Rational implements Comparable<Rational>
{
   private int i_den;
   private int i_num;
   
   
   public Rational()
   {
      this.i_num = 1;
      this.i_den = 1;
   }
   
   public Rational(final int num, final int den)
   {
      if(den == 0)
         throw new IllegalArgumentException("Can't have a 0 in the demoninator silly.");
 
      this.i_num = num;
      this.i_den = den;
      
      
      sign();
      reduce();
   }
   
   private void reduce()
   {
      BigInteger bi_val1 = BigInteger.valueOf(this.i_num);     //probably a better way to do this
      BigInteger bi_val2 = BigInteger.valueOf(this.i_den);
      
      BigInteger bi_gcd = bi_val1.gcd(bi_val2);
      
      this.i_num = this.i_num / bi_gcd.intValue();
      this.i_den = this.i_den / bi_gcd.intValue();
   }
   
   private void sign()
   {
      if(this.i_den < 0 && this.i_num < 0)         //First checks to see if they are both negative
      {
         this.i_den = Math.abs(this.i_den);
         this.i_num = Math.abs(this.i_num);
      }
      
      else if(this.i_den < 0)                   //Then checks to see if just den is negative
      {
         this.i_den = Math.abs(this.i_den);
         this.i_num = this.i_num * -1;
      }
      
      //If they are both positive then nothing else needs to happen
      
   }
   
   public Rational add(final Rational another)
   {
      if(another == null)
         throw new IllegalArgumentException("bad params in add");
      
      int i_temp1 = (this.i_num * another.i_den) + (another.i_num * this.i_den);  //num
      int i_temp2 = this.i_den * another.i_num;                                  //den
      
      Rational r_temp = new Rational(i_temp1, i_temp2);                            //creates new object so it can be reduced and such
      
      return r_temp;  
   }
   
   public Rational reciprocal()
   {
      Rational r_temp = new Rational(this.i_den, this.i_num);
      
      return r_temp;
   }
   
   @Override
   public String toString()
   {
      String s_temp1 = this.i_num + "";
      String s_temp2 = this.i_den + "";
      
      return s_temp1 + "/" + s_temp2;
   }
   
   @Override
   public boolean equals(final Object obj)
   {
      
      if(obj == null)
         return false;
      if(obj == this)
         return true;
      if(!(obj instanceof Rational))
         return false;
      
      Rational another = (Rational)obj;
      
      if(this.i_num == another.i_num && this.i_den == another.i_den)
         return true;
      
      return false;
   }
   
   @Override
   public int hashCode()
   {
      Integer i_temp1 = this.i_num;
      Integer i_temp2 = this.i_den;
      
      int res = i_temp1.hashCode() + i_temp2.hashCode();
      
      return res;
   }
   
   @Override
   public int compareTo(final Rational another)
   {
      if(another == null)
         throw new IllegalArgumentException("bad params in compareTo");
      
      Double d_temp1 = (double)this.i_num / this.i_den;
      Double d_temp2 = (double)another.i_num / another.i_den;
      
      int res = d_temp1.compareTo(d_temp2);
      
      return res; 
   }
}