package cscd210Classes;

import java.util.Scanner;
import java.io.*;

public class CheckingAccount
{
   private int acctNum;
   private double bal;
   
   
   
   public CheckingAccount(final int acctNum)
   {
      this(acctNum, 100);
   }
   
   public CheckingAccount(final int acctNum, final double bal)
   {
      if(acctNum <= 0 || bal < 100)
         throw new IllegalArgumentException("bad contructor");
      
      this.acctNum = acctNum;
      this.bal = bal;
   }
   
   
   public int getAcctNumber()
   {
      return this.acctNum;
   }
   
   public double getBalance()
   {
      return this.bal;
   }
   
   public void setAccountNumber(final int acctNum)
   {
      if(acctNum <= 0)
         throw new IllegalArgumentException("bad setAccountNum");
         
      this.acctNum = acctNum;
   }
   
   private void setBalance(final double bal)
   {
      if(bal < 0)
         throw new IllegalArgumentException("bad setBalance");
         
      this.bal = bal;
   }
   
   public void deposit(final double amt)
   {
      if(amt <= 0)
         throw new IllegalArgumentException("bad deposit");
      
      this.setBalance(bal + amt);
   }
   
   public void withdrawal(final double amt)
   {
      if(amt <= 0)
         throw new IllegalArgumentException("bad withdrawal");
      
      if(amt <= bal)
         this.setBalance(bal - amt);
   }
   
   @Override
   public String toString()
   {
      String a = this.acctNum + "";
      String b = this.bal + "";
      
      
      return "Account Number: " + a +"\nAccount Number: $" + b + "\n";
   }
   
   @Override
   public boolean equals(final Object obj)
   {
      Student another = (Student)obj;
      
      if(another == null)
         return false;
      
      if(another == this)
         return true;
      
      if(!(obj instanceof CheckingAccount))
         return false;
      
      if(this.acctNum == another.acctNum && this.bal == another.bal)
         return true;
      
      return false; 
   }
   
   
   @Override
   public int hashCode()
   {
      String x = this.acctNum + "";
      
      return x.hashCode();
   }
   
   
   
}