import java.util.Scanner;

public class CSCD210Lab4b
{
   public static void main(String[] args)
   {
      String f1, f2, f3, first, second, third;
      
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Please enter the first fruit: ");         //asking user 3 times to get fruit names
      f1 = keyboard.nextLine();
      System.out.print("Please enter the second fruit: ");
      f2 = keyboard.nextLine();
      System.out.print("Please enter the third fruit: ");
      f3 = keyboard.nextLine();
      
      //Debugging statement
      System.out.println("The fruit inputted were: " + f1 + " " + f2 + " and " + f3);
      
      first = f1;
      second = f1;
      third = f1;
      
      if(f1.compareToIgnoreCase(f2) < 0 && f1.compareToIgnoreCase(f3) < 0) //checks to see if first fruit comes first alphabetically
      {
         //Debugging statement
         System.out.println("First if was entered");
         if(f2.compareToIgnoreCase(f3) < 0)
         {
            //Debugging statement
            System.out.println("Two comes before Three");
            second = f2;
            third = f3;
         }
         else
         {
            //Debugging statement
            System.out.println("Three comes before Two");
            second = f3;
            third = f2;
         }
      }
      
      else if(f2.compareToIgnoreCase(f1) < 0 && f2.compareToIgnoreCase(f3) < 0) //checks to see if second fruit comes first alphabetically
      {
         //Debugging statement
         System.out.println("Second else if was entered");
      
         first = f2;
         if(f1.compareToIgnoreCase(f3) < 0)
         {
            second = f1;
            third = f3;
         }
         
         else
         {
            second = f3;
            third = f1;
         }
      }
      
      else if(f3.compareToIgnoreCase(f1) < 0 && f3.compareToIgnoreCase(f2) < 0)     //checks to see if third fruit comes first alphabetically
      {
         //Debugging statement
         System.out.println("Third else if was entered");
         
         first = f3;
         if(f1.compareToIgnoreCase(f2) < 0)
         {
            second = f1;
            third = f2;
         }
         
         else
         {
            second = f2;
            third = f1;
         }
      }
      
      System.out.println("The fruit in alphabetical order: " + first + ", " + second + ", and " + third);
      
   }
   
}