import java.util.Scanner;

public class CSCD210Lab4a
{
   public static void main(String[] args)
   {      
      int num1, num2, num3, largest, smallest, middle;
      
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter first integer: ");
      num1 = keyboard.nextInt();
      
      System.out.print("Enter second integer: ");
      num2 = keyboard.nextInt();
      
      System.out.print("Enter third integer: ");
      num3 = keyboard.nextInt();
      
      largest = num1;
      middle = num1;
      smallest = num1;
      
      if (num2 < smallest && num2 < num3)       //Checks all numbers for smallest
         smallest = num2;
      else if (num3 < smallest)
         smallest = num3;
      
      if (num2 > largest && num2 > num3)        //Checks all numbers for largest
         largest = num2;
      else if (num3 > largest)
         largest = num3;
      
      if(num2 > smallest && num2 < largest)     //Checks all numbers for the middle of the three
         middle = num2;
      else if (num3 > smallest && num3 < largest)
         middle = num3;
         
      
      System.out.print("The numbers in ascending order " + smallest + ", " + middle + ", and " + largest);
   }
   
}

