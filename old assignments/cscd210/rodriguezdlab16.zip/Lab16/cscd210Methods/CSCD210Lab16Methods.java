package cscd210Methods;

import java.util.Scanner;
import java.io.*;
import cscd210Enums.*;


public class CSCD210Lab16Methods
{
   public static Month[] fillArray(final Scanner fileIn, final int total)
   {
      if(fileIn == null || total < 1)
         throw new IllegalArgumentException("Issue with fillArray params");
      
      Month[] array = new Month[total];
      
      for(int x = 0; x < total; x++)
      {
         String str = fileIn.nextLine();
         array[x] = Month.valueOf(str.substring(0,3).toUpperCase());
      }
      
      return array;
      
   }
   
   public static Month getMonth(final String str)
   {
      if(str == null || str.isEmpty())
         throw new IllegalArgumentException("Issues with getMonth");
      
      return Month.valueOf(str);
       
   }
   
   public static int menu(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad menu, fire damien");
      
      int choice = 0;
      do
      {
         System.out.println("Please choose from the following menu: ");
         System.out.println("1)Print the array to the screen");
         System.out.println("2) Sort the array by Natural Order");
         System.out.println("3)Sort the array by Total Order based on days");
         System.out.println("4)Quit");
         System.out.println("Enter your choice -----> ");
         choice = kb.nextInt();
         kb.nextLine();
         
      }while(choice < 1 || choice > 4);
      
      return choice;
   }
   
   public static void printArray(final Month[] array)
   {
      if(array.length < 1 || array == null)
         throw new IllegalArgumentException("bad bananas in printArray");
      
      for(int x = 0; x < array.length -1; x++)
      {
         System.out.print(array[x] + ", ");
      }
      
      System.out.print(array[array.length - 1] + "\n");
   }
}