package cscd210Enums;
import java.util.Scanner;
import java.io.*;

public enum Month
{
   APR("april",30),AUG("august",31),DEC("december",31),FEB("february",28),JAN("january", 31),JUL("july",31),JUN("june", 30),MAR("march", 31),MAY("may", 31),NOV("november",30),OCT("october",31),SEP("september",30);
   
   private int days;
   private String month;
   
   
   private Month(final String month, final int days)
   {
      if(month == null || month.isEmpty() || days < 28)
         throw new IllegalArgumentException("issues with month enum constructor");
      
      this.month = month;
      this.days = days;
     
   }
   
   
   public int getDays(){return this.days;}
   
   @Override
   public String toString(){return this.month.substring(0,1).toUpperCase() + this.month.substring(1);}
}
