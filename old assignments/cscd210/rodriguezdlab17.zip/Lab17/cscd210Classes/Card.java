package cscd210Classes;

import cscd210Enums.*;

public class Card extends Object
{
   private Suit suit;
   private Value value;
   
   
   public Card(Suit suit, Value value)
   {
      if(suit == null || value == null)
         throw new IllegalArgumentException("bad constructor params in Card");
         
      this.suit = suit;
      this.value = value;
   }
   
   public int getValue()
   {
      return this.value.ordinal();
   }
   
   @Override
   public String toString()
   {
      return this.value.toString()+ " of " + this.suit.toString();
   }
   
   
}