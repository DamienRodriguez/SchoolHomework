package cscd210Methods;

import java.util.Random;
import java.util.Scanner;
import cscd210Enums.*;
import cscd210Classes.*;


public class CSCD210Lab17Methods extends Object
{
   public static void fillDeck(final Card[] deck)
   {
      if (deck == null || deck.length < 1)
         throw new IllegalArgumentException("bad bananas in fillDeck");
      
      Suit[] tempSuit = Suit.values();
      Value[] tempValue = Value.values();
      
      
      int count = 0;
      for(int x = 0; x < Suit.values().length; x++)
      {
         for(int y = 0; y < Value.values().length; y++)
         {
            deck[count] = new Card(tempSuit[x], tempValue[y]);
            count++;
         }
      }
   }
   
   public static void shuffle(final Card[] deck)
   {
      if(deck == null || deck.length < 1)
         throw new IllegalArgumentException("issues in shuffle");
      
      int numShuffle = 0;
      Scanner kb = new Scanner(System.in);
      Random rand = new Random();
      
      do
      {
         System.out.println("Please enter the amount of times you would like the deck to be shuffled -----> ");
         numShuffle = kb.nextInt();
         kb.nextLine();
         
      }while(numShuffle < 1);
      
      
      
      for(int x = 0; x <= numShuffle; x++)
      {
         for(int y = 0; y < deck.length; y++)
         {
            Card temp = deck[y];          
            int tempInt = rand.nextInt(51);
      
            deck[y] = deck[tempInt];
            deck[tempInt] = temp;
            
         }
      }
   }
   
   public static Card dealCards(final Card[] deck, final int index)
   {
      if(deck == null || deck.length < 1 || index < 0 || index >= deck.length)
         throw new IllegalArgumentException("issues in dealCards");
      
      return deck[index];
   }
   
   
   public static int calcHandScore(final Card[] hand)
   {
      if(hand == null || hand.length < 1)
         throw new IllegalArgumentException("Issues with the calcHandScore");
      
      int total = 0;
      
      for(int x = 0; x < hand.length; x++)
      {
         total = total + hand[x].getValue();
      }
      
      return total;
   }
  
   public static void displayWinningHand(final int handOneValue, final int handTwoValue)
   {
      if(handOneValue < 1 || handTwoValue < 1)
         throw new IllegalArgumentException("bad bananas in displayWinningHand method");
      
      if(handOneValue > handTwoValue)
         System.out.println("Player 1 has a better hand");
      
      else if(handOneValue < handTwoValue)
         System.out.println("Player 2 has a better hand");
      
      else
         System.out.println("It's a draw!");
   }
   
   
   public static Value getValue(final int index)
   {
      Value[] array = Value.values();
      if(index < 1 || index >= array.length)
         throw new IllegalArgumentException("issues in getValue");
      
      return array[index];
   }
   
   public static Suit getSuit(final int index)
   {
      Suit[] array = Suit.values();
      if(index < 1 || index >= array.length)
         throw new IllegalArgumentException("issues in getValue");
      
      return array[index];
   }
   
   public static void displayHand(final Card[] hand, final String player)
   {
      if(hand == null || hand.length < 1 || player == null || player.isEmpty())
         throw new IllegalArgumentException("bad params in displayHand");
      
      String str = player + "'s hand: ";
      
      for(int x = 0; x < hand.length - 1; x++)
      {
         str = str + hand[x] + ", ";
      }
      
      str = str + hand[hand.length - 1];
      
      System.out.println(str);
   }
   
   public static void printDeck(Card[] deck)
   {
      if(deck == null || deck.length < 1)
         throw new IllegalArgumentException("issues with printDeck");
      
      for(int x = 0; x < deck.length - 1; x++)
      {
         System.out.print(deck[x].toString() + ", ");
      }
      
      System.out.println(deck[deck.length - 1]);
   }
}