package cscd210Methods;

import java.util.Scanner;
import java.io.*;
import cscd210Classes.Fish;




public class CSCD210Lab13Methods
{
   public static Fish[] fillArray(final Scanner fileIn, final int total, final int linesPer)
   {
      if(fileIn == null || total <= 0 || linesPer <= 0)
         throw new IllegalArgumentException ("fillArray got bad params");
      
      Fish[] array = new Fish[total];
      
      for(int x = 0; x < total; x++)   //used total because array.length is part of the Array class
      {
         
         String temp = fileIn.nextLine();
         String[] tempArray = temp.split(",");
         
         tempArray[1] = tempArray[1].trim();
         double a = Double.parseDouble(tempArray[1]);
         
         array[x] = new Fish(tempArray[0], a);
      }
      
      return array;
   }
   
   
   public static void printArray(final Fish[] myFish, final PrintStream output)
   {
      if(myFish == null || myFish.length <= 0 || output == null)
         throw new IllegalArgumentException ("Bad params in printArray");
      
      for(Fish s: myFish)            //Took from lab 10 b/c same method basically
         output.println(s);
   }
   
   public static int readIndex(final int startIndex, final int endIndex, final Scanner kb)
   {
      if(startIndex < 0 || endIndex < 0 || endIndex < startIndex || kb == null)
         throw new IllegalArgumentException("Bad params in readIndex");
      
      int choice;
      
      do
      {
         
         System.out.println("Please enter an index between " + startIndex + " and " + endIndex + " ---->");
         choice = kb.nextInt();
         kb.nextLine();
         
      }while(choice < startIndex || choice > endIndex);
      
      return choice; 
      
   }
   
   public static int menu(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad scanner in menu");
      
      int choice = 0;
      
      do
      {
         System.out.println("Please choose from the following menu:");
         System.out.println("1) Print the array to the Screen");
         System.out.println("2) Print the array to an output file");
         System.out.println("3) Read an index and check for equality");
         System.out.println("4) Quit");
         
         System.out.println("Enter choice -----> ");
         choice = kb.nextInt();
         
      }while(choice < 1 || choice > 4);
      
      kb.nextLine();
      
      return choice;
   }
   
   public static String readOutputFileName(Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad scanner in menu");
      
      String fileName;
      
      do
      {
         System.out.println("Please enter an output file name ---->");
         fileName = kb.nextLine();
         
         
      }while (fileName == null || fileName == "");
      
      return fileName;
   }
}