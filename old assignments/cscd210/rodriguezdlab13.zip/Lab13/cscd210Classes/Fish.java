package cscd210Classes;

import java.util.Scanner;


public class Fish implements Comparable<Fish>
{
   private String type;
   private double weight;
   
   public Fish(String type, double weight)
   {
      if(type == null || type.isEmpty() || weight <= 0)
         throw new IllegalArgumentException("Bad params in constructor");
      
      this.type = type;
      this.weight = weight;
   }
   
   @Override
   public int compareTo (Fish another)
   {
      if(another == null)
         throw new IllegalArgumentException("bad params in compareTo");
      
      int result;
      result = this.type.compareTo(another.type);
      
      if(result != 0)
         return result;
      
      result = (int)this.weight * 100 - (int)another.weight * 100;
      
      return result;
   }
   
   public double getWeight()
   {
      return this.weight;
   }
   
   public String getType()
   {
      return this.type;
   }
   
   
   public void setWeight(double weight)
   {
      if(weight <= 0)
         throw new IllegalArgumentException("bad params setWeight");
      
      this.weight = weight;      //after pre conditions we know that the weight is greater than 0
   }
   
   public void setType(String type)
   {
      if(type == null || type.isEmpty())
         throw new IllegalArgumentException("bad params setType");
      
      this.type = type; //after pre-conditions we know that the type is not null or empty
   }
   
   
   @Override
   public boolean equals(Object obj)
   {
      Fish another = (Fish)(obj);
      
      if(another == null)
         return false;
      if(this == another)
         return true;
      if(!(another instanceof Fish))
         return false;
         
      int a = (int) another.weight * 100;
      int b = (int) this.weight * 100;
      
      if(this.type == another.type && a == b)
         return true;
      
      return false;
   }
   
   
   @Override
   public int hashCode()
   {
      String s_hash = this.type;
      Double d_hash = this.weight;
      
      return s_hash.hashCode() + d_hash.hashCode();
   }
   
   public String toString()
   {
      String str = this.type + " - " + Double.toString(this.weight);
      return str;
   }
   
}