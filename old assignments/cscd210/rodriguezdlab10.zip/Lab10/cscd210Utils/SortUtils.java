package cscd210Utils;

public class SortUtils
{
   public static void selectionSort(final int [] myArray)
   {
      if(myArray == null || myArray.length < 1)
         throw new IllegalArgumentException("Bad params selectionSort");
         
      int search, start, min;
      int temp;
      
      for(start = 0; start < myArray.length - 1; start++)
      {
         min = start;
         
         for(search = start + 1; search < myArray.length; search++)
         {
            if(myArray[search] < min)
               min = search;
         }
         
         temp = myArray[start];
         myArray[start] = myArray[min];
         myArray[min] = temp;   
      
      }
   }
   
   public static void selectionSort(final Comparable[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("selection sort comparable went dead.");
      
      int search, start, min;
      Comparable temp;
      
      for(start = 0; start < myArray.length - 1; start++)
      {
         min = start;
         
         for(search = start + 1; search < myArray.length; search++)
         {
            if(myArray[search].compareTo(myArray[min]) < 0)
               min = search;
         }
         
         temp = myArray[start];
         myArray[start] = myArray[min];
         myArray[min] = temp;   
      
      }
   }
}