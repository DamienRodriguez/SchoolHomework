package cscd210Utils;

import java.io.*;
import java.util.Scanner;

public class FileUtils
{
   public static int countRecords(Scanner fin, int linesPer)
   {
      if(fin == null ||linesPer <= 0)
         throw new IllegalArgumentException("There was a problem with the conditions in countRecords");
      
      int count = 0;
      
      while(fin.hasNextLine())
      {
         fin.nextLine();
         count++;
      }
      
      if(count == 0 || count % linesPer != 0)
         throw new RuntimeException("There was no info in the file in countRecords");
         
      return count;
   }
   
   public static File openInputFile(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Scanner broken in openInputFile1");
      
      String fileName = "";
      
      File inFile = null;
      
      do
      {
         System.out.print("Please enter a file name -----> ");
         fileName = kb.nextLine();
         inFile = new File(fileName);
      }while(inFile.exists() == false && inFile.canRead() == false);
      
      return inFile;
   }
   
   public static File openInputFile(final String fileName)
   {
      if(fileName == null || fileName == "")
         throw new IllegalArgumentException("Invalid String in openInputFile2");
         
      File inFile = null;
      inFile = new File(fileName);
      
      if(inFile.canRead() == false)
         throw new RuntimeException ("File couldn't be opened.");
      
      return inFile;
   }
   
   
   
}