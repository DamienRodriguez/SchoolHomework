package cscd210Methods;

import java.util.Scanner;
import java.io.*;

public class CSCD210Lab10Methods extends java.lang.Object
{
   //this is wrong here
   public static java.lang.String[] fillArray(Scanner fin, int total)
   {
      if(fin == null || total <= 0)
         throw new IllegalArgumentException ("Something went wrong in fillArray");
         
      String array[] = new String[total];
      
      for(int x = 0; x < total; x++)
      {
         array[x] = fin.nextLine();
      }
      
      return array;
   }
   

   public static void printArray(String[] words, java.io.PrintStream fout)
   {
      if(words == null || words.length <= 0 || fout == null)
         throw new IllegalArgumentException("Something went wrong in printArray.");
         
      for(String s: words)
         fout.println(s);
   }
}