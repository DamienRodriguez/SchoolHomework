package cscd210Methods;

import java.util.Scanner;

public class CSCD210Lab7Methods
{


   public static double calcBMI(final double height, final double weight)
   
   {
      if(height <= 0 || weight <= 0)
         throw new IllegalArgumentException("You can't be 0 inches tall or 0 units in weight");
         
      return weight / (height * height) * 703;                           //Returning just the calc rather than variable so i dont need to make a new variable   
   }
   
   
   
   
   public static void displayResults(final java.lang.String name, final double height, final double weight, final double bmi)
   {
   
      if(name == null || name == " " || height <= 0 || weight <= 0 || bmi <= 0)
         throw new IllegalArgumentException("There was an issue with numbers here");
      
      String result;
      
      if(bmi < 18.5)
         result = "underweight";
      else if(bmi >=18.5 && bmi < 25)
         result = "normal";
      else if(bmi >=25 && bmi < 30)
         result = "overweight";
      else
         result = "obese";
      
      System.out.println(name + ", " + weight + ", " + height + ", your BMI is: " + bmi + ", you are " + result);
      
   }
   public static boolean goAgain(final java.util.Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Scanner Object is broken in goAgain");
      
      
      String answer;
      boolean answerBool;
   
      do
      {
         System.out.println("Would you like to input new results? ");
         answer = kb.nextLine();
       
      }while((!answer.equalsIgnoreCase("yes")) && (!answer.equalsIgnoreCase("no")));
         
      if(answer.equalsIgnoreCase("yes"))
         answerBool = true;
      else
         answerBool = false;
      
      return answerBool;
   }
   
   
   
   public static double readInfo(final java.util.Scanner kb, final java.lang.String type)
   {
      if(kb == null || type == null || type == "")
         throw new IllegalArgumentException("There was either null or empty type in readInfo constructor 1");
      
      double input = 0.0;
      do
      {
         System.out.println("Please enter your " + type + " -----> ");
         input = kb.nextDouble();
      
      }while(input <= 0.0); 
         
      kb.nextLine();
      
      return input;

   }
   
   
   
   public static double readInfo(final java.lang.String type, final java.util.Scanner kb)
   {
      return readInfo(kb, type);
   }
   
   
   public static java.lang.String readName(final java.util.Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Scanner was passed as null in readName method");
      
      
      String name;
      do
      {
        System.out.println("Please enter your name ------> ");
        name = kb.nextLine();
         
      }while(name.isEmpty());
      
      return name;
   }
}