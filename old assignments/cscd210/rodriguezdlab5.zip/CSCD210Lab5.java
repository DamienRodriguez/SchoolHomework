import java.util.Scanner;

public class CSCD210Lab5
{
   public static void main(String[] args)
   {
      int choice, num, num2, temp, remainder, evens, odds, zeroes, myFlag = 0, t1 = 0, t2 = 0, count;
      
      Scanner keyboard = new Scanner(System.in);
      
      do
      {
         System.out.println("Please enter a non negative integer: ");
         num = keyboard.nextInt();
      }while(num <= 0);
      
      
      do
      {
         //Debug statement
         //System.out.println("entered first loop");
         
         
         System.out.println("Please choose from the following menu: ");
         System.out.println("\t 1. Enter a new number");
         System.out.println("\t 2. Print the number of odd digits, even digits, and zeroes in the integer");
         System.out.println("\t 3. Print if the number is light or heavy");
         System.out.println("\t 4. Print the prime numbers between 2 and the integer (inclusive)");
         System.out.println("\t 5. Quit");
         
         choice = keyboard.nextInt();
         
         if(choice == 1)
         {
            do
            {
               System.out.println("Please enter a non negative integer: ");
               num = keyboard.nextInt();
            }while(num <= 0);
         }
         
         
         
         
         else if(choice == 2)
         {
            evens = 0;
            odds = 0;
            zeroes = 0;
            temp = num;
            
            while(temp != 0)
            {
               remainder = temp % 10;
               
               if(remainder == 0)
                  zeroes++;
               else if(remainder % 2 == 0)
                  evens++;
               else
                  odds++;
               
               temp = temp / 10;
            }
            
            System.out.println("There are " + zeroes + " zeroes, " + odds + " odds, and " + evens + " evens in your number.");
            
            
            System.out.println();   //formating statment
         }
         
         
         
         
         else if(choice == 3)
         {
            temp = num;
            do
            {
               System.out.println("Please enter a second non negative integer: ");
               num2 = keyboard.nextInt();
            }while(num2 <= 0);
            
            temp = num;
            
            count = 0;
            while(temp != 0)
            {
               remainder = temp % 10;
               
               t1+=remainder;
               temp = temp / 10;
               count++;
            }
            //Debug statement
            //System.out.println(t1);
            
            t1 = t1 / count;
            
            //Debug statement
            //System.out.println(t1);
            
            temp = num2;
            
            count = 0;
            
            while(temp != 0)
            {
               remainder = temp % 10;
               
               t2+=remainder;
               temp = temp / 10;
               count++;
            }
            
            //Debug statement
            //System.out.println(t2);
            
            t2 = t2 / count;
            
            //Debug statement
            //System.out.println(t2);
            
            if(t1 > t2)
               System.out.println("Your number is heavy.");
            else
               System.out.println("Your number is light.");
            
            System.out.println();
           
            
         }
         
         else if(choice == 4)
         {
            System.out.println("The prime numbers between 2 and " + num + " are: ");
            System.out.println(2);                             //Yes, i understand I am cheating. But this ensures it will include 2 until i figure out the problem with the loop
            
            
            for(int i = 2; i <= num; i++)                      //Starts by looking at 2 and moving forward until we reach our number to see which ones between them are prime
            {
               
               
               for(int j = 2; j < i; j++)                      //Uses modulus starting at 2 and works its way forward to see if the number has a remainder or not
               {
                  
                  
                  if(i == 2)
                     myFlag = 1;
                     
                  else if(i % j == 0)
                  {
                     myFlag = 0;
                     break;
                  }
                  
                  else
                  {
                     myFlag = 1;
                  }
                  
               }
               
               
               
               if(myFlag == 1)
               {
                  System.out.println(i);
               }
            }
            
            System.out.println();   //formating statment
         }
         
         
            
      }while(choice != 5);
      
      
      //Debug statement
      //System.out.println("exited first loop");
   }
}