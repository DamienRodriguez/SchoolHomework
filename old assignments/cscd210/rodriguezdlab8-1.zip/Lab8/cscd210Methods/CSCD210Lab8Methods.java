package cscd210Methods;

import java.util.Scanner;

public class CSCD210Lab8Methods
{
   public static int menu(java.util.Scanner kb)
   {
      int choice;
      
      if(kb == null)
         throw new IllegalArgumentException("Scanner object assigned null");
      
      do
      {      
         System.out.println("Please choose from the following menu: ");
         System.out.println("\t 1. Add a value to the array");
         System.out.println("\t 2. Delete value from array (By value)");
         System.out.println("\t 3. Delete value from array (By location)");
         System.out.println("\t 4. Display the array");
         System.out.println("\t 5. Compute mean of array");
         System.out.println("\t 6. Compute the median of the array");
         System.out.println("\t 7. Compute the midpoint of the array");
         System.out.println("\t 8. Compute the standard deviation of the array");
         System.out.println("\t 9. Quit");
         
         System.out.print("Enter your choice ---> ");
         choice = kb.nextInt();
      }while(choice < 1 || choice > 9);
      
      return choice;      
   }
   
   
   public static int readNum(final java.util.Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Scanner object assigned null");
      
      int myNum;
      
      do
      {
         System.out.println("Please enter a non-zero, positive integer -----> ");
         myNum = kb.nextInt();
      }while(myNum < 0);
      
      kb.nextLine();             //Clearing buffer
      
      return myNum;
   }

}