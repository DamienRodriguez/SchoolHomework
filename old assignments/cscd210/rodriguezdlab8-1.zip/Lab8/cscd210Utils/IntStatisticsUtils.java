package cscd210Utils;

import java.util.Scanner;
import cscd210Utils.SortUtils;

public class IntStatisticsUtils
{

   public static double	computeMean(final int[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something is wrong with the array");
      
      double total = 0.0;
      
      for(int x = 0; x < myArray.length; x++)
         total += myArray[x];
      
      total = total / myArray.length;
      
      
      
      return total;
   } 


   public static double	computeMedian(final int[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something is wrong with the array");
      
      double median, num1, num2;
      
      if(myArray.length % 2 == 0)
         median = (double) myArray[(myArray.length / 2)];
      
      else
      {
         num1 = (double) myArray[(myArray.length / 2)];
         num2 = (double) myArray[((myArray.length) / 2) - 1];
         
         median = (num1 + num2) / 2;
      }
      
      return median;   

   }


   public static double	computeMidpoint(final int[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something is wrong with the array");
      
      double midPoint;
      
      SortUtils.selectionSort(myArray);
      
      midPoint = (double) (myArray[0] + myArray[myArray.length - 1]) / 2;

      return midPoint;   
   
   }
   
   public static double	computeStdDev(final int[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something is wrong with the array");
      
      double stdDev, mean, total = 0.0;
      double newArray[] = new double[myArray.length];
      
      mean = computeMean(myArray);
      
      for(int x = 0; x < myArray.length; x++)
         newArray[x] = mean - myArray[x];
      
      for(int x = 0; x < newArray.length; x++)
         newArray[x] = Math.pow((double) newArray[x], 2.0);
      
      for(int x = 0; x < newArray.length; x++)
         total += newArray[x];
      
      total = total / newArray.length - 1;
      
      stdDev = Math.sqrt(total);
         
      return stdDev; 
   
   }
   


// Instructions on Method
// The printResults methods prints the results of the statistical calculation String type is once again 
// a literal string that will be printed to the screen

   public static void	printResults(final java.lang.String type, final double result)
   {
      if(type == null || type == "")
         throw new IllegalArgumentException("Something was wrong with type");
      
      System.out.println(type + " " + result); 
   }

}