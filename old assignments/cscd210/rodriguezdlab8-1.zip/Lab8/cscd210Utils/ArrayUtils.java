package cscd210Utils;

import java.util.Scanner;

public class ArrayUtils
{
   public static int[]addNum(final int[] myArray, final java.util.Scanner kb)
   {
      if(kb == null || myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something when wrong in addNum");
      
      int newArray[] = new int[myArray.length + 1];
      int myNum;
      
      for (int x = 0; x < myArray.length; x++)
         newArray[x] = myArray[x];
      
      System.out.println("Please enter value ---> ");
      myNum = kb.nextInt();
      
      newArray[newArray.length - 1] = myNum;
      
      return newArray;

   }   
   
   public static int[]createAndFillArray(int num, java.util.Scanner kb)
   {
      if(kb == null || num == 0)
         throw new IllegalArgumentException("Problem occured in create and fill array method");
      
      int myArray[];
      int userNum;
     
      myArray = new int[num];
      
      for(int x = 0; x < num; x++)     //Asking the user an X amount of times to put 
                                             //different numbers in the array
      {
         System.out.println("Please enter a number to put into your array ----->");
         userNum = kb.nextInt();
         myArray[x] = userNum;
         kb.nextLine();    //Clearing buffer
      }
      
      return myArray;
   }

   
   
   
   
   //by george it works
   
   public static int[]deleteValue(final int[] myArray, final java.util.Scanner kb)
   {
      if(kb == null || myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something went wrong in delete value method");
      
      int deleteVal, indexNum = 0, inc;
      int array[] = new int[myArray.length - 1];
      
      boolean found = false;
      
      System.out.println("Please enter the number you wish to delete -----> ");
      deleteVal = kb.nextInt();
      
      kb.nextLine();       //Clearing buffer
      
      for(int x = 0; x < myArray.length && found == false; x++)
      {
         if(myArray[x] == deleteVal)
            found = true;
            indexNum = x;
      }
      
      
      if(found == false)                  //If it wasn't found I make array into the old array for return
      {
         System.out.println("Value NOT found");
         return myArray;
      }
      
      
      for(inc = 0; inc < indexNum; inc++)
         array[inc] = myArray[inc];
      
      for(inc = inc; inc < array.length; inc++)
         array[inc] = myArray[inc + 1];
 
      return array;
      
    }


   //still not working -.-
   public static int[]deleteValueByIndex(final int[] myArray, final java.util.Scanner kb)
   {
      if(kb == null || myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("There was an issue in the delete by index method");
      
      
      int deleteIndex, count, x;
      int newArray[];
      
      count = myArray.length - 1;
      newArray = new int[count];
      
      do
      {
         System.out.println("Please enter a value between 0 and " + count + " ----->");
         deleteIndex = kb.nextInt();
         kb.nextLine();
          
      }while(deleteIndex < 0 || deleteIndex > myArray.length);
      
      
      for(x = 0; x < deleteIndex; x++)
      {
         newArray[x] = myArray[x];
      }
      
      for(x = x; x < newArray.length; x++)
      {
         newArray[x] = myArray[x + 1];
      } 
      
      
      return newArray;
     
   }

   
   
   
   public static void printArray(final int[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something went wrong in print array method");
      
      System.out.print("[");
      
      for(int x = 0; x < myArray.length - 1; x++)
         System.out.print(myArray[x] + ", ");
      
      System.out.print(myArray[myArray.length - 1] + "]");
      
      System.out.println("");
   }
}