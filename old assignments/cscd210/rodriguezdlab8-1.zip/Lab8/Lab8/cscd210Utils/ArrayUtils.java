package cscd210Utils;

import java.util.Scanner;

public class ArrayUtils
{
   public static int[]addNum(final int[] myArray, final java.util.Scanner kb)
   {
      if(kb == null || myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something when wrong in addNum");
      
      int newArray[] = new int[myArray.length + 1];
      int myNum;
      
      for (int x = 0; x < myArray.length; x++)
         newArray[x] = myArray[x];
      
      System.out.println("Please enter value ---> ");
      myNum = kb.nextInt();
      
      newArray[newArray.length - 1] = myNum;
      
      return newArray;

   }   
   
   public static int[]createAndFillArray(int num, java.util.Scanner kb)
   {
      if(kb == null || num == 0)
         throw new IllegalArgumentException("Problem occured in create and fill array method");
      
      int myArray[];
      int userNum, arraySize;
      
      System.out.println("Please enter a size for your array -----> ");
      arraySize = kb.nextInt();
      
      kb.nextLine();       //Clearing buffer
     
      myArray = new int[arraySize];
      
      for(int x = 0; x < arraySize; x++)     //Asking the user an X amount of times to put 
                                             //different numbers in the array
      {
         System.out.println("Please enter a number to put into your array ----->");
         userNum = kb.nextInt();
         myArray[x] = userNum;
         kb.nextLine();    //Clearing buffer
      }
      
      return myArray;
   }

   
   
   
   
   //THIS METHOD DOES NOT WORK AT THIS CURRENT MOMENT
   public static int[]deleteValue(final int[] myArray, final java.util.Scanner kb)
   {
      if(kb == null || myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something went wrong in delete value method");
      
      int deleteVal;
      int array[];
      
      boolean found = false;
      
      System.out.println("Please enter the number you wish to delete -----> ");
      deleteVal = kb.nextInt();
      
      kb.nextLine();       //Clearing buffer
      
      for(int x = 0; x < myArray.length; x++)
      {
         if(myArray[x] == deleteVal)
            found = true;
      }
      
      if(found == false)                  //If it wasn't found I make array into the old array for return
      {
         array = new int[myArray.length];
         for (int x = 0; x < myArray.length; x++)
            array[x] = myArray[x];
         
         System.out.println("Value NOT found");
         
      }
      
      else                                //If it was found, then I create a smaller array size and use a for loop to input values
      {
         array = new int[myArray.length - 1];
         for(int x = 0; x < myArray.length; x++)
         {
            if(myArray[x] != deleteVal)      //This statement allows for the non delete value numbers to be put into the array
               array[x] = myArray[x];
         }
      }
      
      return array;
      
    }


   //THIS METHOD DOES NOT WORK AT THIS TIME 
   public static int[]deleteValueByIndex(final int[] myArray, final java.util.Scanner kb)
   {
      if(kb == null || myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("There was an issue in the delete by index method");
      
      int deleteIndex, count;
      int newArray[];
      
      count = myArray.length - 1;
      newArray = new int[count];
      
      do
      {
         System.out.println("Please enter a value between 0 and " + count + " ----->");
         deleteIndex = kb.nextInt();
         kb.nextLine();
          
      }while(deleteIndex < 0);
      
      for(int x = 0; x < myArray.length; x++)
      {
         if(x != deleteIndex)
            newArray[x] = myArray[x];
      }
      
      return newArray;
     
   }

   public static void printArray(final int[] myArray)
   {
      if(myArray == null || myArray.length <= 0)
         throw new IllegalArgumentException("Something went wrong in print array method");
      
      System.out.print("[");
      
      for(int x = 0; x < myArray.length - 1; x++)
         System.out.print(myArray[x] + ", ");
      
      System.out.print(myArray[myArray.length - 1] + "]");
      
      System.out.println("");
   }
}