// 2/6/2018 - No compile errors found, haven't tested fully yet

package cscd210Methods;

import java.util.Scanner;


public class CSCD210Lab9Methods
{

   public static char[] convertWordToArray(final java.lang.String theWord)
   {
      char myArray[] = new char[theWord.length()];
      
      for(int x = 0; x < theWord.length(); x++)
      {
         myArray[x] = theWord.charAt(x);
      }
      
      return myArray;
   }
   
   public static boolean goAgain(final java.util.Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Scanner Object is broken in goAgain");
      
      
      String answer;
      boolean answerBool;
   
      do
      {
         System.out.println("Would you like to go again? ");
         answer = kb.nextLine();
       
      }while((!answer.equalsIgnoreCase("yes")) && (!answer.equalsIgnoreCase("no")));
         
      if(answer.equalsIgnoreCase("yes"))
         answerBool = true;
      else
         answerBool = false;
      
      return answerBool;
   }  
   
   public static java.lang.String readName(final java.util.Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("PEBCAK");
      
      String name;
      
      do
      {
         System.out.print("Please enter your name -----> ");
         name = kb.nextLine();

      }while(name.isEmpty());
      
      return name;
   
   }
   
   public static java.lang.String readWord(final java.util.Scanner kb, java.lang.String name)
   {
      if(kb == null || name == null || name == "")
         throw new IllegalArgumentException("This method is not working, same as your programmer");
      
      String word;
      
      do
      {
         System.out.println("Please enter a word at least 5 characters in length");
         word = kb.nextLine();
         
      }while(word.length() < 5);
      
      return word;
   }
}