package cscd210Methods.gameMethods;

import java.util.Scanner;

public class GuessTheWordGameMethods
{
   public static final int TOTAL = 7;

   public static int checkGuess(final char guess, final char[] wordToGuess, final int incorrectGuesses)
   {
      if(guess < 'a' || guess > 'z' || wordToGuess == null || wordToGuess.length < 1 || incorrectGuesses < 0 || incorrectGuesses > TOTAL)
         throw new IllegalArgumentException("We have a problem huston");
         
   
      for(int x = 0; x < wordToGuess.length; x++)
      {
         if(guess == wordToGuess[x])
            return incorrectGuesses;
      }
      return incorrectGuesses + 1;
   }
   
   public static boolean display(final char guess, final char[] wordToGuess, final char[] guessedLetters, final char[] displayGuessedLettersWordToGuess, final int incorrectGuesses)
   {
      if(guess < 'a' || guess > 'z' || wordToGuess == null || wordToGuess.length < 1 || guessedLetters == null || guessedLetters.length < 1 || displayGuessedLettersWordToGuess == null || displayGuessedLettersWordToGuess.length < 1 || incorrectGuesses < 0 || incorrectGuesses > TOTAL)
         throw new IllegalArgumentException("The gremlins did it again.");
      
      int index;
      
      if(incorrectGuesses < TOTAL)
      {
         for(int x = 0; x < wordToGuess.length; x++)
         {
            if(guess == wordToGuess[x])
            {
               displayGuessedLettersWordToGuess[x] = guess;
            }
         }        
      }
      
      index = (int)(guess - 'a');
      guessedLetters[index] = guess;
      
      System.out.println("Your word so far");   
      System.out.println(displayGuessedLettersWordToGuess);
      
      System.out.println("Letters guessed so far");
      System.out.println(guessedLetters);
      
      System.out.println("You have " + (TOTAL - incorrectGuesses) + " guesses left.");
      
      for(int x = 0; x < displayGuessedLettersWordToGuess.length; x++)
      {
         if(displayGuessedLettersWordToGuess[x] == '-')
         {
            return false;
         }
      }
      
      System.out.println("Congratz.");
      return true;
      
   }
   
   
   public static char[] initializeDisplay(final char[] wordToGuess)
   {
      if(wordToGuess == null || wordToGuess.length < 1)
         throw new IllegalArgumentException ("PEBCAK OR DAMIEN IS A MORON, EITHER WORKS IN THIS SITUATION.");
   
      char charArray[] = new char[(wordToGuess.length)];
      
      for(int x = 0; x < charArray.length; x++)
         charArray[x] = '-';
      
      return charArray;
   }
   
   
   public static char[] initializeDisplay(final int total)
   {
      char charArray[] = new char[total];
      
      for(int x = 0; x < charArray.length; x++)
         charArray[x] = '-';
      
      return charArray;
   }
   
   public static char readGuess(final java.util.Scanner kb, final java.lang.String player)
   {
      if(kb == null || player == null || player == "")
         throw new IllegalArgumentException ("DAMIEN NEEDS TO STOP DOING THIS SO CLOSE TO DEADLINE GOOD GOD");
      
      char guess;
      
      do
      {
         System.out.print(player + " please enter a guess -----> ");
         guess = kb.next().charAt(0);
      }while(guess < 'a' || guess > 'z');
      
      kb.nextLine();
      
      return guess;
   }
}