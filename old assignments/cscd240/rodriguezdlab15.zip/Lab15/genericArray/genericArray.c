#include "genericArray.h"
#include "../utils/utils.h"


GenericArray * fillArray(FILE * in, int length, void * (*buildType)(FILE * input))
{
	int x;

	GenericArray * array = calloc(length, sizeof(GenericArray));

	for(x = 0; x < length; x++)
		array[x].data = buildType(in);

	return array;
}


void printArray(GenericArray * array, int length, void (*printType)(void *))
{
	int x;
	printf("\n");
	for(x = 0; x < length; x++)
		printType(array[x].data);

	printf("\n");
}


void cleanArray(GenericArray * array, int length, void (*cleanType)(void *))
{
	int x;
	for(x = 0; x < length; x++)
		cleanType(array[x].data);

	free(array);
	array = NULL;

}


void sortArray(GenericArray * array, int length, int (*compar)(const void * v1, const void * v2))
{
	int start, search, min;
	GenericArray temp;

	for(start = 0; start < length - 1; start++)
	{
		min = start;

		for(search = start + 1; search < length; search ++)
			if(compar(array[search].data, array[min].data) < 0)
				min = search;

		temp = array[min];
		array[min] = array[start];
		array[start] = temp;

	}// for start

}// end sortArray


GenericArray * addItem(GenericArray * array, int *length, void * (*buildType_Prompt)())
{
	GenericArray *temp = (GenericArray *)calloc(*length + 1,sizeof(GenericArray));

	int x;
	for(x = 0; x < *length; x++)
	{
		temp[x] = array[x];
	}
	
	*length++;
	
	temp[x].data = buildType_Prompt();
	free(array);

	return temp;

}


GenericArray * removeItemByValue(GenericArray * array, int *length, void * (*buildType_prompt)(), void (*cleanType)(void * ptr), int (*compare)(const void * v1, const void * v2))

{
	if(length == 0)
	{
		printf("There are no items in the array. No Changes\n");
		return array;
	}

	char * word = buildType_prompt();

	int x, index = 0, result = 0;;
	for(x = 0; x < *length; x++)
	{
		result = compare(word,array[x].data); 
		if(result == 0)
		{
			index = x;
			break;
		}
	}


	if(result != 0)
	{
		printf("Item Not Found! No Changes\n");
		return array;
	}
	
	//at this point we know what index this is at
	
	GenericArray *temp = (GenericArray *)calloc(*length - 1, sizeof(GenericArray));

	for(x = 0; x < *length; x++)
	{
		if(x < index)
			temp[x] = array[x];
		else if(x > index)
			temp[x-1] = array[x];
		else
			cleanType(array[index].data);
	}

	free(array);
	*length--;
	return temp;	

}
	

GenericArray * removeItemByIndex(GenericArray * array, int *length, void (*cleanType)(void * ptr))
{
	int index = readIndex(*length);
	
	return removeItemByIndexPassedIn(array,length,cleanType,index);	
}


GenericArray * removeItemByIndexPassedIn(GenericArray * array, int *length, void (*cleanType)(void * ptr), int index)
{

	GenericArray *temp = (GenericArray *)calloc(*length - 1, sizeof(GenericArray));

	int x;
	for(x = 0; x < *length; x++)
	{
		if(x < index)
			temp[x] = array[x];
		else if(x > index)
			temp[x-1] = array[x];
	}

	cleanType(array[index].data);
	free(array);
	*length--;

	return temp;
}







