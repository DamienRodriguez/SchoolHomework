#include "word.h"
#include "../utils/utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void cleanTypeWord(void *word)
{
	free(word);
	word = NULL;
}


void *buildTypeWord(FILE *fin)
{
	if(fin == NULL)
		exit(-99);


	char temp[100];
	fgets(temp,100,fin);
	strip(temp);
	//word is read in

	Word *word = (Word *)calloc(1,sizeof(Word));
	
	word->ltrs = (char *)calloc(strlen(temp) + 1, sizeof(char));
	strcpy(word->ltrs,temp);
	
	word->len = strlen(temp);

	return word;

}//end of build word

void printTypeWord(void *passedIn)
{
	Word *word = (Word *)passedIn;

	printf("%s \n",word->ltrs);
}

void *buildTypeWord_Prompt()
{
	char temp[100];

	printf("Please enter a word: ");
	fgets(temp,100,stdin);
	strip(temp);
	
	Word *word = (Word *)calloc(1,sizeof(Word));
	
	word->ltrs = (char *)calloc(strlen(temp) + 1, sizeof(char));
	strcpy(word->ltrs,temp);
	
	word->len = strlen(word->ltrs);
	return word;
}//end of build word via user input


int compareWords(const void *p1, const void *p2)
{
	Word *word1 = (Word *)p1;
	Word *word2 = (Word *)p2;

	return strcmp(word1->ltrs,word2->ltrs);
}//end of compare words








