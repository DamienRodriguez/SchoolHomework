#include "linkedList.h"
#include "requiredIncludes.h"

LinkedList *linkedList()
{
	LinkedList *temp = (LinkedList*)calloc(1,sizeof(LinkedList));
	
	temp->head = NULL;
	temp->size = 0;
	
	return temp;
}

void addFirst(LinkedList *this, Node *nn)
{
	Node *cur = this->head;
	nn->next = cur;
	this->head = nn;
	this->size++;
}

void addLast(LinkedList *this, Node *nn)
{
	Node *cur = this->head;
	if(this->size == 0)
	{
		addFirst(this,nn);
	}
	else
	{
		while(cur->next != NULL)
		{
			cur = cur->next;
		}

		cur->next = nn;
		nn->next = NULL;
		this->size++;
	}
}

void removeLast(LinkedList *this, void (*removeData)(void *ptr))
{
	Node *cur = this->head;
	Node *prev =  NULL;
	while(cur->next != NULL)
	{
		prev = cur;
		cur = cur->next;
	}

	prev->next = cur->next; //LAST NODE
	removeData(cur->data);
	free(cur);
 }//working

void removeItem(LinkedList *this, Node *nn, void (*removeData)(void *ptr), int (*compare)(const void *first, const void *second))
{
	Node *cur = this->head;
	Node *prev = NULL;
	int found = 0; //boolean style variable that is tripped on first encounter
	while(cur != NULL && found != 1)
	{
		if(compare(cur->data,nn->data) == 0)
		{

			if (prev == NULL) //edge case where the item is at the front of the list
			{
				this->head = cur->next;
				removeData(cur->data);
				free(cur);
				cur = NULL;
				this->size--;
				found = 1;
				break;
			}
			else
			{
				prev->next = cur->next;
				removeData(cur->data);
				free(cur);
				cur = NULL;
				this->size--;
				found = 1;
				break;
			}
		}
		prev = cur;
		cur = cur->next;
	}
	removeData(nn->data);
	free(nn);

	nn = NULL;
}

void clearList(LinkedList *this, void (*removeData)(void *ptr))
{
	Node *cur = this->head, *temp;

	while(cur != NULL)
	{
		temp = cur;
		cur = cur->next;

		removeData(temp->data);
		temp->next = NULL;
		free(temp);
		temp = NULL;
	}
	this->head = NULL;
	this->size = 0;
}

void printList(const LinkedList *this, void (*convertData)(void *))
{
	Node *cur = this->head;

	while (cur != NULL)
	{
		convertData(cur->data);
		cur = cur->next;
	}
}

LinkedList *cleanList(LinkedList *this, void (*removeData)(void *ptr))
{
	clearList(this,removeData);

	free(this);
	this = NULL;

	return this;
}
