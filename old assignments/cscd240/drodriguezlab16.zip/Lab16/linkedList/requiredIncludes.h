#ifndef REQUIRED_INCLUDES_H
#define REQUIRED_INCLUDES_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../words/word.h"



#endif
