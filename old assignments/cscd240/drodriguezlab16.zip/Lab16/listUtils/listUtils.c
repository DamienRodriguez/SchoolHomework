#include "listUtils.h"

#include "../linkedList/requiredIncludes.h"

Node *buildNode(FILE *input, void *(*buildData)(FILE *input))
{
	Node *nn = (Node *)calloc(1,sizeof(Node));

	nn->data = buildData(input);
	nn->next = NULL;

	return nn;
}

void sort(LinkedList *this, int (*compare)(const void *first, const void *second))
{
	Node *search, *sorted, *min;
	void *temp = NULL;

	for(sorted = this->head; sorted->next != NULL; sorted = sorted->next)
	{
		min = sorted;
		for(search = sorted->next; search != NULL; search = search->next)
		{
			if(compare(min->data,search->data) > 0)
			{
				min = search;
			}
		}

		temp = min->data;
		min->data = sorted->data;
		sorted->data = temp;

	}

}

void buildList(LinkedList *this, FILE *fin, int total, void *(*buildData)(FILE *input))
{
	Node *cur = NULL;
	int x;
	for(x = 0; x < total; x++)
	{
		cur = buildNode(fin,buildData);
		addLast(this,cur);
	}
}

