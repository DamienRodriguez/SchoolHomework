#include "lab6.h"
#include "fileUtils.h"

int menu()
{
	int choice = 0;
	
	printf("\n");
	printf("Welcome to the Weather Program\n");
	printf("\n");
	
	
	do
	{
		printf("Please choose from the following menu \n");
		printf("1) Find and display max temperature \n");
		printf("2) Find and display min temperature \n");
		printf("3) Find and display the mean(average) temperature for the month \n");
		printf("4) Find and display the median temperature \n");
		printf("5) Find and display the mode temperature for the month - if all the same then display lowest\n");
		printf("6) Allow the user to load a new file\n");
		printf("7) Quit. \n");
		
		scanf("%d",&choice);
		
		if(choice < 1 || choice > 7)
			printf("Invalid response\n");

	}while(choice < 1 && choice > 7);
	return choice;
}

int readDays(FILE * fin)
{
	int days;
	fscanf(fin,"%d",&days);
	printf("Days are: %d.\n",days);
	return days;
}

void cleanUp(int * array)
{
	free(array);
	array = NULL;
}

void sort(int * array, int total)
{
	int smallest, search, sorted;
	
	for(sorted = 0; sorted < total; sorted++)
	{
		smallest = sorted;
		for(search = sorted + 1; sorted < total; sorted++)
		{
			if(array[smallest] > array[search])
				smallest = search;
		}
		
		int temp = array[smallest];
		array[smallest] = array[sorted];
		array[sorted] = temp;
	}

}

int *fillArray(int total, FILE * fin)
{

	int *array = (int *)calloc(total,sizeof(int));
	
	int i;
	for(i = 0; i < total; i++)
	{
		fscanf(fin, "%d", &array[i]);
	}
	return array;
}

void displayMaxTemp(int * array, int total)
{
	int max = array[0];
	int x;
	for(x = 1; x < total; x++)
	{
		if(max < array[x])
			max = array[x];
	}

	printf("The max temp for this month is: %d\n",max);

}

void displayMinTemp(int * array, int total)
{
	int min = array[0];
	int x;
	for(x = 1; x < total; x++)
	{
		if(min > array[x])
			min = array[x];
	}

	printf("The min temp for this month is: %d\n",min);
}

void displayAvgTemp(int *array, int total)
{
	int beforeDiv = 0;
	int x;
	for(x = 0; x < total; x++)
	{
		beforeDiv += array[x];
	}
	
	double avg = (double) beforeDiv / total;

	printf("The average temp for this month is: %.1f\n", avg);
}

void displayModeTemp(int *array, int total)
{
	int counter = 0;
	int modeCount = 0;
	
	int numCheck = 0;
	int modeNum = 0;

	sort(array,total);

	int i;
	for(i = 0; i < total; i++)
	{
		numCheck = array[i];
		counter = 1;

		int j;
		for(j = i + 1; j < total; j++)
		{
			if(numCheck == array[j])
				counter++;
		}

		if(counter > modeCount)
		{
			modeNum = numCheck;
			modeCount = counter;
		}
		
		else if(counter == modeCount)
		{
			if(modeNum > numCheck)
				modeNum = numCheck;

		}	
	}

	printf("The mode(most frequent number) for this month was: %d\n",modeNum);
}

void displayMedianTemp(int *array, int total)
{
	int med = 0;

	sort(array,total);


	if(total % 2 == 1)
	{
		med = array[total / 2];
	}

	else
	{
		med = array[total / 2] + array[total / 2 + 1];
		
		med = med / 2;
	}

	printf("The median temp for this month is: %d\n", med);
}











