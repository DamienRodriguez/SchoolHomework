#include "utils.h"
#include "fileUtils.h"


int countRecords(FILE * fin, int linesPer)
{
	char temp[100];

	int count = 0;
	fgets(temp,100,fin);
	while(!feof(fin))
	{
		count++;
		fgets(temp,100,fin);
	}

	if(count == 0 || count %  linesPer != 0)
	{
		printf("ERROR IN COUNT RECORDS: File wasn't created properly");
		return 0;
	}

	int records = count / linesPer;
	
	return records;
}


FILE * openInputFile_Prompt()
{
	FILE * fin = NULL;
	char fileName[MAX];
	do
	{
		printf("Please enter the name of the input file ");
		fgets(fileName, MAX, stdin);
		strip(fileName);

		fin = fopen(fileName, "r");

	}while(fin == NULL);

	return fin;
}


