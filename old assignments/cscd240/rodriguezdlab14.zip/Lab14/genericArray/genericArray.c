#include "genericArray.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

GenericArray * fillArray(FILE * fin, int length, void *(*buildType)(FILE * input))
{
	GenericArray *array = (GenericArray *)calloc(length,sizeof(GenericArray));
	int x;
	for(x = 0; x < length; x++)
	{
		array[x].data = buildType(fin);
	}
	return array;
}

void printArray(GenericArray *array, int length, void (*printType)(void*))
{
	int x;
	for(x = 0; x < length; x++)
	{
		printType(array[x].data);
	}
}


void cleanArray(GenericArray *array, int length, void (*cleanType)(void *))
{
	int x;
	for(x = 0; x < length; x++)
	{
		cleanType(array[x].data);
		array[x].data = NULL;
	}
	free(array);
	array = NULL;

}

void sortArray(GenericArray *array, int length, int (*compare)(const void *v1, const void *v2))
{
	void *temp;

	int search, sorted, min = 0;
	for(sorted = 0; sorted < length; sorted++)
	{
		min = sorted;
		for(search = sorted + 1; search < length; search++)
		{
			if(compare(array[search].data,array[min].data) < 0)
				min = search;
		}
		
		temp = array[min].data;
		array[min].data = array[sorted].data;
		array[sorted].data = temp;
	}
}
