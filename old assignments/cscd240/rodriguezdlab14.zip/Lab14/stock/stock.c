#include "stock.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../utils/utils.h"

void *buildStock(FILE *fin)
{
	Stock *stock = (Stock *)calloc(1,sizeof(Stock));
	char temp[100];

	fgets(temp,100,fin);
	strip(temp);
	stock->symbol = (char *)calloc(strlen(temp)+1,sizeof(char));
	strcpy(stock->symbol,temp); //symbol

	fgets(temp,100,fin);
	strip(temp);
	stock->name = (char *)calloc(strlen(temp) + 1,sizeof(char));
	strcpy(stock->name,temp); //company Name
	
	fgets(temp,100,fin);
	sscanf(temp, ".6lf",&stock->price); //current price

	return stock;
	
}

void printStock(void *stock_p)
{
	Stock *temp = (Stock *)stock_p;

	printf("%s - %s - %.6lf\n", temp->name,temp->symbol,temp->price);
}

void cleanStock(void *stock_p)
{
	Stock *temp = (Stock *)stock_p;
	free(temp->symbol);
	temp->symbol = NULL;
	
	free(temp->name);
	temp->name = NULL;
	
	temp->price = 0;

	free(temp);
}

int compareSymbols(const void *one, const void *two)
{
	Stock *temp1 = (Stock *)one;
	Stock *temp2 = (Stock *)two;
	

	return strcmp(temp1->symbol,temp2->symbol);
}


int compareNames(const void *one, const void *two)
{
	Stock *temp1 = (Stock *)one;
	Stock *temp2 = (Stock *)two;
	

	return strcmp(temp1->name,temp2->name);
}

int comparePrices(const void *one, const void *two)
{
	Stock *temp1 = (Stock *)one;
	Stock *temp2 = (Stock *)two;
	

	return (int)((temp1->price * 100) - (temp2->price * 100));
}

















