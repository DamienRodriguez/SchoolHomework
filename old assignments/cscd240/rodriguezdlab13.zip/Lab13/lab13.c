#include "lab13.h"
#include "./utils/utils.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


Address * fillArray(int * total, FILE * fin)
{
	int count = 0;
	char temp[100];

	fgets(temp,100,fin);
	while(!feof(fin))
	{
		count++;
		fgets(temp,100,fin);
	}

	if(count == 0 || count % 4 != 0)
	{
		printf("FILE ERROR: Records in file do not match format\n\n");
		return NULL;
	}

	*total = count / 4;

	rewind(fin);

	Address *array = (Address *)calloc(*total,sizeof(Address));
	int x;
	for(x = 0; x < *total; x++)
	{
		fgets(temp,100,fin);
		strip(temp);
		array[x].street = (char *)calloc(strlen(temp)+1,sizeof(char));
		strcpy(array[x].street,temp);

		fgets(temp,100,fin);
		strip(temp);
		array[x].city = (char *)calloc(strlen(temp)+1,sizeof(char));
		strcpy(array[x].city,temp);

		fgets(temp,100,fin);
		strip(temp);
		array[x].state = (char *)calloc(strlen(temp)+1,sizeof(char));
		strcpy(array[x].state,temp);

		fgets(temp,100,fin);
		array[x].zip = atoi(temp);
	}

	return array;

}
void printArray(Address * array, int total)
{
	int x;
	for(x = 0; x < total; x++)
	{
		printf("%s \n",array[x].street);
		printf("%s %s %d", array[x].city, array[x].state, array[x].zip);
		printf("\n");
	}
}
void cleanUp(Address * array, int total)
{
	int x;
	for(x = 0; x < total; x++)
	{
		free(array[x].street);
		array[x].street = NULL;

		free(array[x].city);
		array[x].city = NULL;

		free(array[x].state);
		array[x].state = NULL;
	}
	free(array);
}

int compareStreet(const void * one, const void * two)
{
	Address *a1 = (Address *)one;
	Address *a2 = (Address *)two;

	return strcmp(a1->street,a2->street);
}
int compareCity(const void * one, const void * two)
{
	Address *a1 = (Address *)one;
	Address *a2 = (Address *)two;

	return strcmp(a1->city,a2->city);
}
int compareStateCityZip(const void * one, const void * two)
{
	Address *a1 = (Address *)one;
	Address *a2 = (Address *)two;

	int result = strcmp(a1->state,a2->state);
	if(result != 0)
		return result;

	result = strcmp(a1->city,a2->city);
	if(result != 0)
		return result;

	return a1->zip - a2->zip;
}
int compareZip(const void * one, const void * two)
{
	Address *a1 = (Address *)one;
	Address *a2 = (Address *)two;

	return a1->zip - a2->zip; 
}


int menu()
{
	int choice = 0;
	do
	{
		printf("Please choose from the following menu: \n");
		printf("\n");
		printf("1) Print the array sorted by street \n");
		printf("2) Print the array sorted by city \n");
		printf("3) Print the array sorted by state then city then zip \n");
		printf("4) Print the array sorted by zip \n");
		printf("5) Quit \n");
		printf("-----> ");
		scanf("%d",&choice);
	}while(choice < 1 || choice > 5);
	return choice;
}

