#include "lab12.h"
#include "./utils/utils.h"

int menu()
{
	int num;
	do
	{
		printf("Please choose from the following\n");
   		printf("1) Sort by Symbol\n");
   		printf("2) Sort by Company Name\n");
   		printf("3) Sort by Price\n");
   		printf("4) Quit\n");
   		printf("Choice --> ");
   		scanf("%d", &num);
	}while(num < 1 && num > 4);
 
   return num;
}// end menu


int fillArray(struct Stock array[], FILE *fin)
{
	int count = 0;
	
	char temp[100];
	
	while(!feof(fin))
	{
		fgets(temp,100,fin);
		count++;
	}//counts records
	

	rewind(fin);//sets back to top of file
	
	int records = count / 3;

	int x;
	for(x = 0; x < records; x++)
	{
		fgets(temp,100,fin);
		strip(temp);
		strcpy(array[x].symbol,temp);

		fgets(temp,100,fin);
		strip(temp);
		strcpy(array[x].companyName,temp);

		fgets(temp,100,fin);
		strip(temp);
		sscanf(temp,"%lf",&array[x].currentPrice);
		
	}//fill in here

	return records;
}

void printArray(struct Stock array[], int total)
{
	int x;
	for(x = 0; x < total; x++)
	{
		printf("%s - %s - %.6lf\n",array[x].companyName,array[x].symbol,array[x].currentPrice);
	}
}


int compareSymbols(const void *one, const void *two)
{
	struct Stock *temp1 = one;
	struct Stock *temp2 = two;
	

	return strcmp(temp1->symbol,temp2->symbol);
}

int compareNames(const void *one, const void *two)
{
	struct Stock *temp1 = one;
	struct Stock *temp2 = two;
	

	return strcmp(temp1->companyName,temp2->companyName);
}

int comparePrices(const void *one, const void *two)
{
	struct Stock *temp1 = one;
	struct Stock *temp2 = two;
	

	return (int)((temp1->currentPrice * 100) - (temp2->currentPrice * 100));
}





