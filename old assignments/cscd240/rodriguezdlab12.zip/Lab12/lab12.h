#ifndef LAB12_H
#define LAB12_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Declare your structure here
struct Stock
{
	char symbol[10];
	char companyName[100];
	double currentPrice;
};


int menu();
int fillArray(struct Stock array[], FILE * fin);
void printArray(struct Stock array[], int total);




int compareSymbols(const void *,const void *);
int compareNames(const void *,const void *);
int comparePrices(const void *,const void *);



#endif
