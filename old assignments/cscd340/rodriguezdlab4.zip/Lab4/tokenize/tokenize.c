#include "tokenize.h"

void clean(int argc, char **argv)
{
	int i;
	for(i = 0; i < argc; i++) {

		
		free(argv[i]);
		argv[i] = NULL;
	}
	free(argv);
}// end clean

void printargs(int argc, char **argv)
{
	int x;
	for(x = 0; x < argc; x++)
		printf("%s\n", argv[x]);

}// end printargs

int makeargs(char *s, char *** argv)
{
	char temp[MAX];
	strcpy(temp,s);


	char *token,*saveptr;
	int count = 0;

	token = strtok_r(temp," ",&saveptr);
	while(token != NULL) {
		count++;
		token = strtok_r(NULL," ",&saveptr);
	}

	if(!count) return -1;
	//at this point we know how many arguments there are



	*(argv)=(char **)calloc(count + 1, sizeof(char*));
	int i = 0;

	token = strtok_r(s," ",&saveptr);
	(*argv)[i] = (char *)calloc(strlen(token) + 1,sizeof(char));
	strcpy((*argv)[i],token);
	//first argument has been copied over to our args. i is initially 0
	//this statement is neccessarry because of the nature of strtok_r
	//Could have made it smaller using an if below, but still almost
	//identical code.

	for(i = 1; i < count; i++) {
		token = strtok_r(NULL, " ",&saveptr);
		(*argv)[i] = (char *)calloc(strlen(token) + 1,sizeof(char));
		strcpy((*argv)[i],token);
	
	}

   return count;

}// end makeArgs
