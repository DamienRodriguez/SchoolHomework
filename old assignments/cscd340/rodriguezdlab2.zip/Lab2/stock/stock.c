#include "stock.h"
#include "../utils/fileUtils.h"

/**
 * Build stock builds a Stock object by reading 3 lines from the file.  First line is the symbol,
 * second line is the company name, third line is the price.<br>
 * <br>
 * You must first build the Stock structure dynamically<br>
 * Then read in the symbol and allocate the memory for it, copy from temp into the new allocated memory<br>
 * Then read in the name and allocate the memory for it, copy from temp into the new allocated memory<br>
 * Then read in the price and assign it to the price struct data member
 *
 * @param fin Representing the FILE *
 * @return void * Representing a Stock object filled with data
 */
void * buildStock(FILE * fin) {

    Stock *this = (Stock *)calloc(1,sizeof(Stock));

    char input[MAX];

    fgets(input,MAX,fin);
    strip(input);
    this->symbol = (char *)calloc(strlen(input)+1,sizeof(char));
    strcpy(this->symbol,input);

    fgets(input,MAX,fin);
    strip(input);
    this->name = (char *)calloc(strlen(input)+1, sizeof(char));
    strcpy(this->name,input);

    fgets(input,MAX,fin);
    strip(input);
    this->price = atof(input);

    return this;



}


/**
 * Build stock prompt builds a Stock object by prompting for input.  First is the symbol,
 * second is the company name, third is the price.<br>
 * <br>
 * You must first build the Stock structure dynamically<br>
 * Then read in the symbol and allocate the memory for it, copy from temp into the new allocated memory<br>
 * Then read in the name and allocate the memory for it, copy from temp into the new allocated memory<br>
 * Then read in the price and assign it to the price struct data member
 *
 * @param fin Representing the FILE *
 * @return void * Representing a Stock object filled with data
 */
void * buildStock_Prompt(FILE * fin) {

    Stock *this = (Stock *)calloc(1,sizeof(Stock));
    char input[MAX];

    printf("Please enter your stock name: ");
    fgets(input,MAX,fin);
    strip(input);
    this->name = (char *)calloc(strlen(input)+1, sizeof(char));
    strcpy(this->name,input);

    printf("Please enter your stock symbol: ");
    fgets(input,MAX,fin);
    strip(input);
    this->symbol = (char *)calloc(strlen(input)+1, sizeof(char));
    strcpy(this->symbol,input);

    printf("Please enter your stock price: ");
    fgets(input,MAX,fin);
    strip(input);
    this->price = atof(input);

    return this;
}


/**
 * The printStock method completes the following:<br>
 * 1) Receives a void pointer which it casts to a Stock *<br>
 * 2) Prints to the screen the the name - the symbol - the price
 */
void printStock(void * ptr) {

    Stock *this = (Stock *)ptr;

    printf("%s - %s - %.2lf\n", this->name, this->symbol, this->price);
}


/**
 * The cleanStock method completes the following:<br>
 * 1) Receives a void pointer which it casts to a Stock *<br>
 * 2) Frees the symbol<br>
 * 3) Frees the name<br>
 * 4) Sets the name and symbol to NULL
 * 5) Frees the Stock * for the structure
 *
 * @warning All pointers need to be set to NULL after they are freed
 */
void cleanStock(void * ptr) {

    Stock *this = (Stock *)ptr;

    free(this->symbol);
    this->symbol = NULL;
    free(this->name);
    this->name = NULL;
    this->price = 0;

    free(this);


}


/**
 * The compareSymbols compares the two stock symbols using strcmp<br>
 * 1) Cast s1 into a Stock *<br>
 * 2) Cast s2 into a Stock *<br>
 * 3) return strcmp of s1 symbol and s2 symbol
 *
 * @param s1 Representing the array value to compare
 * @param s2 Representing the array value to compare
 * @return int Based on the strcmp results
 */
int compareSymbols(const void * s1, const void * s2) {
    Stock *this = (Stock *)s1;
    Stock *that = (Stock *)s2;

    return strcmp(this->symbol,that->symbol);
}