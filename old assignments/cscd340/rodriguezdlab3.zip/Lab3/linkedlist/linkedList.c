#include "linkedList.h"

LinkedList * linkedList()
{
	LinkedList *this = (LinkedList *)calloc(1,sizeof(LinkedList));

	this->head = (Node *)calloc(1,sizeof(Node));

	this->size = 0;

    	return this;
}// end linkedList


void clearList(LinkedList * theList, void (*removeData)(void *))
{
	Node *cur = theList->head->next;
	Node *temp = NULL;
	
	while(cur != NULL) {
		temp = cur;
		cur = cur->next;
		
		removeData(temp->data);
		free(temp);
		temp = NULL;
	}
	
	free(theList->head);
	theList->head = NULL;
    
}// end clearList

void printList(const LinkedList * theList, void (*convertData)(void *))
{
	Node *cur = theList->head->next;
	while(cur != NULL) {
		convertData(cur->data);
		cur = cur->next;
	}
}// end printList

void addLast(LinkedList * theList, Node * nn)
{
	if(theList == NULL || nn == NULL)
		exit(-99);


	Node *cur = theList->head->next;
	while(cur->next != NULL)
		cur = cur->next;

	cur->next = nn;
	nn->prev = cur;
	theList->size++;

}// end addLast

void addFirst(LinkedList * theList, Node * nn)
{
	if(theList == NULL || nn == NULL)
		exit(-99);


	nn->next = theList->head->next;
	nn->next->prev = nn;
	theList->head->next = nn;
	theList->size++;
}// end addFirst

void removeFirst(LinkedList * theList, void (*removeData)(void *))
{ 
	if(theList == NULL)
		exit(-99);

	Node *cur = theList->head->next;
	cur->next->prev = theList->head;
	theList->head->next = cur->next;
	
	removeData(cur->data);
	free(cur);
	theList->size--;
}// end removeFirst

void removeLast(LinkedList * theList, void (*removeData)(void *))
{
	if(theList == NULL)
		exit(-99);

	Node *cur = theList->head->next;
	Node *temp = theList->head;

	while(cur->next != NULL) {
	
		temp = cur;
		cur = cur->next;
	}

	temp->next = NULL;
	cur->prev = NULL;
	removeData(cur->data);
	free(cur);
	theList->size--;
	
}// end removeLast


void removeItem(LinkedList * theList, void * (*buildType)(FILE * stream), void (*removeData)(void *), int (*compare)(const void *, const void *))
{
	if(theList == NULL)
		exit(-99);
	
	Node *cur = theList->head->next;
	Node *prev = theList->head;

	void *data = buildType(stdin);

	while(compare(cur->data, data) != 0) {
		prev = cur;
		cur = cur->next;
	
	}

	prev->next = cur->next;
	prev->next->prev = prev;
	cur->next = NULL;
	removeData(cur->data);
	free(cur);
	cur = NULL;
	free(data);
	data = NULL;
}// end removeItem

