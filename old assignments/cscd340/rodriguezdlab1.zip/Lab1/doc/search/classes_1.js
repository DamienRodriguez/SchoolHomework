var searchData=
[
  ['word',['word',['../structword.html',1,'']]]
];
