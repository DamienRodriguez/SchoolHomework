var indexSectionsWithContent =
{
  0: "abcdfgmoprsw",
  1: "gw",
  2: "fgw",
  3: "abcfoprs",
  4: "d",
  5: "g",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

