#include "word.h"
#include "../utils/fileUtils.h"


void cleanTypeWord(void * ptr) {
    free(ptr);
    ptr = NULL;
}
void * buildTypeWord(FILE * fin) {
    if(fin == NULL)
        exit(-99);

    char input[100]; //buffer to strcpy for return
    fgets(input,100,fin); //getting word from our file
    strip(input); //clears our input buffer

    char *word = (char *)calloc(strlen(input)+1, sizeof(char)); //getting memory we need for our given word
    strcpy(word,input); //our new pointer has the value it needs


    return word;
}

void printTypeWord(void * passedIn) {
    char *word = (char *)passedIn;
    printf("%s \n",word);

}

void * buildTypeWord_Prompt() {
    char input[100]; //buffer


    printf("Please enter the word you wish ");
    fgets(input,100,stdin);

    strip(input);

    char *word = (char *)calloc(strlen(input) + 1, sizeof(char));
    strcpy(word,input);

    return word;
}

int compareWords(const void * p1, const void * p2) {
    char *word1 = (char *)p1;
    char *word2 = (char *)p2;

    return strcmp(word1,word2);
}
