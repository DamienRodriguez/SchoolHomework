#include "genericArray.h"
#include "../utils/basicUtils.h"

GenericArray * fillArray(FILE * in, int length, void * (*buildType)(FILE * input)) {

    GenericArray *array = (GenericArray *)calloc(length,sizeof(GenericArray));

    int i;
    for(i = 0; i < length; i++)
        array[i].data = buildType(in);

    return array;
}

void printArray(GenericArray * array, int length, void (*printType)(void *)) {

    printf("================= PRINTING ARRAY =================\n");

    int i;
    for(i = 0; i < length; i++)
        printType(array[i].data);

    printf("===================================================\n");


}

void cleanArray(GenericArray * array, int length, void (*cleanType)(void *)) {
    int i;
    for(i = 0; i < length; i++)
        cleanType(array[i].data);

    free(array);
    array = NULL;
}

void sortArray(GenericArray * array, int length, int (*compar)(const void * v1, const void * v2)) {

    int start, search, min;
    GenericArray temp;

    for(start = 0; start < length - 1; start++){
        min = start;
        for(search = start + 1; search < length; search++)
            if(compar(array[search].data, array[min].data) < 0)
                min = search;



        temp = array[min];
        array[min] = array[start];
        array[start] = temp;
    }

}

GenericArray * addItem(GenericArray * array, int *length, void * (*buildType_prompt)()) {

    //Length is giving human count of array elements length: 6, MaxIndex: 5

    GenericArray *newArray = (GenericArray *)calloc(*length + 1, sizeof(GenericArray));

    int i;
    for(i = 0; i < *length; i++)
        newArray[i] = array[i];

    newArray[*length].data = buildType_prompt();

    free(array);

    *length = *length + 1; //appending human count

    return newArray;

}

GenericArray * removeItemByValue(GenericArray * array, int *length, void * (*buildType_prompt)(), void (*cleanType)(void * ptr), int (*compar)(const void * v1, const void * v2)) {

    if(*length == 0)
        exit(-99);

    void *word = (char *)buildType_prompt();

    int check = 0; //1 if found, 0 if not found
    int i, index;

    for(i = 0; i < *length; i++) {

        if(compar(word, array[i].data) == 0) {
            index = i;
            check = 1;
            break;
        }
    }

    free(word);

    if(check == 0) {
        printf("Item Not Found! No Changes\n");
        return array;
    }

    cleanType(array[index].data);

    GenericArray *newArray = (GenericArray *)calloc(*length - 1, sizeof(GenericArray));

    int j = 0;
    for(i = 0; i < *length; i++) {
        if(i != index) {
            newArray[j] = array[i];
            j++;
        }
    }

    free(array);
    *length = *length - 1;

    return newArray;
}

GenericArray * removeItemByIndex(GenericArray * array, int *length, void (*cleanType)(void * ptr)) {
    if(*length == 0)
        exit(-99);

    GenericArray *newArray = (GenericArray *)calloc(*length - 1, sizeof(GenericArray));

    int indexToRemove = readIndex(*length);

    cleanType(array[indexToRemove].data);

    int i, j = 0;

    for(i = 0; i < *length; i++) {
        if(i != indexToRemove) {
            newArray[j] = array[i];
            j++;
        }
    }

    free(array);
    *length = *length - 1;

    return newArray;
}

GenericArray * removeItemByIndexPassedIn(GenericArray * array, int *length, void (*cleanType)(void * ptr), int index) {
    if(*length == 0)
        exit(-99);

    GenericArray *newArray = (GenericArray *)calloc(*length - 1, sizeof(GenericArray));


    cleanType(array[index].data);

    int i, j = 0;

    for(i = 0; i < *length; i++) {
        if(i != index) {
            newArray[j] = array[i];
            j++;
        }
    }

    free(array);
    *length = *length - 1;

    return newArray;
}
