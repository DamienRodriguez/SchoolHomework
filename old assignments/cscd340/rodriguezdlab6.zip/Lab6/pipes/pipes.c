#include "pipes.h"
#include "../tokenize/makeArgs.h"

int containsPipe(char *s) {
	char temp[100];
	strcpy(temp,s);


	char *token, *saveptr; //created to start checking for our given
	int pipes = 0;
	
	token = strtok_r(temp,"|",&saveptr); //we either get a token, or NULL

	if(token == NULL) return pipes;
	
	while(token != NULL) {
		pipes++;
		token = strtok_r(NULL,"|",&saveptr);
	}
	return pipes;
}// end containsPipe


char ** parsePrePipe(char *s, int * preCount)
{
	char **args = NULL;

	char *token, *savepoint;
	token = strtok_r(s,"|",&savepoint); //this will make s the value of ls -al in our given example 

	*preCount = makeargs(token,&args);
	token = strtok_r(NULL,"|",&savepoint); //this will make s the value of " wc -w" in our given example in prep for postPipe
	strcpy(s,token);

	/*
	printf("Pre pipe: ");
	int i;
	for(i = 0; i < *preCount; i++)
		printf("%s ",args[i]);
	printf("\n");
	*/

	return args;
}// end parsePrePipe


char ** parsePostPipe(char *s, int * postCount)
{
	char *temp;
	strncpy(temp,s+1,sizeof(s)); //gets rid of leading space from our prep within pre pipe
	
	char **args = NULL;
	*postCount = makeargs(temp,&args);
	
	/*
	printf("Post pipe: ");
	int i;
	for(i = 0; i < *postCount; i++)
		printf("%s ",args[i]);

	printf("\n");
	*/

	return args;
}// end parsePostPipe


void pipeIt(char ** prePipe, char ** postPipe)
{

	pid_t pid;
	int fd[2], result, status;

	result = pipe(fd);

	if(result < 0) {
		printf("Pipe Failure\n");
		exit(-1);
	}// end if


	pid = fork();

	if(pid == 0) {
		pid = fork();

		close(fd[0]);
		dup2(fd[1],1);
		close(fd[1]);
		execvp(prePipe[0],prePipe);
	
	} else {
		
		waitpid(pid, &status, 0);
		
		close(fd[1]);
		dup2(fd[0],0);
		close(fd[1]);
		execvp(postPipe[0],postPipe);
	
	
	}
	
}
