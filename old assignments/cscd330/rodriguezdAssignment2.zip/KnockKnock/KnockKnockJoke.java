public class KnockKnockJoke {

   /*
   * Damien Rodriguez
   * CSCD 330: Networks
   * The code below is the source code for the Knock Knock Joke data class
   * This class creates Knock Knock Joke Objects used in the Knock Knock Joke List
   * This is essenntial to getting the server to run.
   */

	private String start;
	private String response;
	private String responseWho;
	private String punchLine;
	
	
	public KnockKnockJoke(final String response, final String punchLine) {
		setStart("KNOCK KNOCK"); //default response all of the time
		setResponse(response);
		setResponseWho(response + " WHO?");
		setPunchLine(punchLine);
	}


	public String getStart() {
		return start;
	}


	public void setStart(String start) {
		this.start = start;
	}
	
	public String getResponse() {
		return response;
	}


	public void setResponse(String response) {
		this.response = response;
	}

	public String getPunchLine() {
		return punchLine;
	}


	public void setPunchLine(String punchLine) {
		this.punchLine = punchLine;
	}


	public String getResponseWho() {
		return responseWho;
	}


	public void setResponseWho(String responseWho) {
		this.responseWho = responseWho;
	}
	
	
	@Override
	public String toString() {
		return this.start + " " + "WHO IS THERE" + " " + this.response + " " + this.responseWho + " " + this.punchLine;
	}
}
