import java.io.*;
import java.net.*;

public class KnockKnockServer {
	
  /*
   * Damien Rodriguez
   * CSCD 330: Networks
   * The code below is the source code for the Knock Knock Joke Server.
   * It first sends a response to the client, then the client and the
   * server go back and forth with responses until the complete joke has been
   * said. Proper error checking for client responses has been implemented.
   * 
   */
   
	
	
	//There is extra stuff in here. Rather gold-plated, but not to shabby if i do say so myself.
	//Take a myander at all the source files
	public static void main(String args[]) throws Exception {
		
		String recievedFromClient = "";
		ServerSocket serverSocket  = new ServerSocket(4200);
		KnockKnockJoke myJoke = null;
		
		while(true) {
			Socket clientSocket = serverSocket.accept();
			myJoke = new KnockKnockJokeList().pull();
			System.out.println("This statement, and the joke following are for debugging purposes only.");
			System.out.println("The joke displayed is the whole joke, including respones from the wouldbe vicitim.");
			System.out.println(myJoke.toString());
			
			
			
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(clientSocket.getOutputStream());
			
			outToClient.writeBytes(myJoke.getStart() + '\n'); //knock knock
			
			recievedFromClient = inFromClient.readLine(); //recieved 'who is there?'
			recievedFromClient = recievedFromClient.toUpperCase();
			
			//I should be able to move this to a method within this class...
			while(!recievedFromClient.equals("WHO IS THERE?")) {
				if(!recievedFromClient.equals("WHO IS THERE?")) {
					outToClient.writeBytes("NO NO NO... YOU ARE SUPPOSED TO SAY" + "'" + "WHO IS THERE?" + "'" + '\n');
					recievedFromClient = inFromClient.readLine(); 
					recievedFromClient = recievedFromClient.toUpperCase();
				}	
			}
			
			
			
			outToClient.writeBytes(myJoke.getResponse() + '\n'); //response
			
			recievedFromClient = inFromClient.readLine(); //response who?
			recievedFromClient = recievedFromClient.toUpperCase();
			
			while(!recievedFromClient.equals(myJoke.getResponseWho())) {
				if(!recievedFromClient.equals(myJoke.getResponseWho())) {
					outToClient.writeBytes("NO NO NO... YOU ARE SUPPOSED TO SAY" + "'" + myJoke.getResponseWho() + "'" + '\n');
					recievedFromClient = inFromClient.readLine(); 
					recievedFromClient = recievedFromClient.toUpperCase();
				}	
			}
			
			outToClient.writeBytes(myJoke.getPunchLine() + '\n'); //punchline
			recievedFromClient = inFromClient.readLine(); //groan?
			

			//this is the problem line
			//String recievedFromClient = inFromClient.readLine();
			
			//System.out.println(recievedFromClient);
			
			/*if(recievedFromClient.equals("42")) {
				outToClient.writeBytes(myJoke.toString());
			} else {
				outToClient.writeBytes("WE DIDNT SAY HELLO \n");
			}
			*/
			
			clientSocket.close();
		}
	}
}
