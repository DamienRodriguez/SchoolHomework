import java.io.*;
import java.net.*;



public class KnockKnockClient {

/*
   * Damien Rodriguez
   * CSCD 330: Networks
   * The code below is the source code for the Knock Knock Joke Client.
   * It first recieves a response from the client to initiate the joke
   * It uses do while loops for error checking if the user doesn't input the 
   * response necessary for the server to work correctly.
   */


	
	public static void main(String[] args) throws Exception {
		
		String sendingToServer = "";
		String recievedFromServer = "";
		
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		
		Socket clientSocket = new Socket("localhost",4200);
		
		

		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		
		recievedFromServer = inFromServer.readLine(); //knock knock
		System.out.println(recievedFromServer); 
		
		//now to figure out how to compartmentalize the next two loops
		do {
			
			sendingToServer = inFromUser.readLine() + '\n'; //who is there?
			outToServer.writeBytes(sendingToServer);
			
			recievedFromServer = inFromServer.readLine(); //knock knock
			System.out.println(recievedFromServer); 
			
		} while(recievedFromServer.contains("NO NO NO..."));
		
		
		//because I've copied code, dunno how i will go about doing this...
		do {
			
			sendingToServer = inFromUser.readLine() + '\n'; //response who?
			outToServer.writeBytes(sendingToServer);
			
			recievedFromServer = inFromServer.readLine(); // punchline
			System.out.println(recievedFromServer); 
			
		} while(recievedFromServer.contains("NO NO NO..."));
		
		sendingToServer = inFromUser.readLine() + '\n'; //Groan
		outToServer.writeBytes(sendingToServer);
		
		clientSocket.close();
	}

}
