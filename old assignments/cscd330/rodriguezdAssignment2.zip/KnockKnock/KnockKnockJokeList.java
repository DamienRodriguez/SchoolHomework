import java.io.File;
import java.util.Hashtable;
import java.util.Random;
import java.util.Scanner;

public class KnockKnockJokeList {

	
  /*
   * Damien Rodriguez
   * CSCD 330: Networks
   * The code below is the source code for the Knock Knock Joke list
   * It uses a hashtable for quick look-up and pulling of random jokes within the list
   * This is essential to the server running.
   */



	private Hashtable<Integer, KnockKnockJoke> jokeList = new Hashtable<Integer, KnockKnockJoke>();
	private int numOfJokes;
	
	private Random RNGesus = new Random();
	
	
	public KnockKnockJokeList() throws Exception {
		fillJokeList();
				
		//System.out.println(numOfJokes); debug command. will be commented out later
	}
	
	private void fillJokeList() throws Exception {
		
		Scanner scanner = new Scanner(new File("input.txt"));
		int numOfLines = 0;
		
		while(scanner.hasNextLine()) {
			//Get the joke from the file
			String unparsedJoke = scanner.nextLine();
			
			//Increment the number of lines by 1
			numOfLines++;
			
			//Pass unparsed joke into parser
			KnockKnockJoke temp = parseJoke(unparsedJoke);
			
			//insert parsed joke into jokeList
			jokeList.put(numOfLines, temp);
		}
		
		//assign number of lines to the number of jokes
		setNumOfJokes(numOfLines);
	}
	
	public int getNumOfJokes() {
		return numOfJokes;
	}

	public void setNumOfJokes(int numOfJokes) {
		this.numOfJokes = numOfJokes;
	}

	private KnockKnockJoke parseJoke(final String unparsedJoke) {
		String[] separatedJoke = unparsedJoke.split(";");
		return new KnockKnockJoke(separatedJoke[0].toUpperCase(), separatedJoke[1].toUpperCase());
	}
	
	public KnockKnockJoke pull() {
		return jokeList.get((Integer)RNGesus.nextInt(numOfJokes) + 1);
	}
	
	
	//this method is for debug purposes only and will be commented out after testing is complete
	public KnockKnockJoke pullSpecificJoke(final int key) {
		return jokeList.get(key);
	}
	
	
}
