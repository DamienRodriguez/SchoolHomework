package cscd211Classes;
import cscd211Enums.*;

public class Player implements Comparable<Player>
{

   private String name;
   private int number;
   private Position position;
   
   
   public Player(final String name, final int number, final Position position)
   {
      if(name == null || name.isEmpty() || number < 0 || position == null)
         throw new IllegalArgumentException("Issues with EVC Player");
      
      this.name = name;
      this.number = number;
      this.position = position;
   }
   
   public String getName() {return this.name;}
   public int getNumber() {return this.number;}
   public Position getPosition() {return this.position;}
   
   @Override
   public String toString()
   {
      return this.name + "-" + this.position + "-" + this.number;
   }
   
   @Override
   public int compareTo(final Player another)
   {
      if (another == null)
         throw new IllegalArgumentException("bad params in compareTo Player");
      
      return this.position.compareTo(another.position);
   }
   
   
   







}