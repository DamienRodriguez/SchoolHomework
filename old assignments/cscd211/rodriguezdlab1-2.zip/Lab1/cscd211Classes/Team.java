package cscd211Classes;

import java.io.*;
import cscd211Comparators.*;
import java.util.Arrays;

public class Team implements Comparable<Team>
{
   private String code, country;
   private Player[] squad;
   
   public Team(final String code, final String country, final Player[] squad)
   {
      if(code == null || country == null || squad == null || code.isEmpty() || country.isEmpty() || squad.length < 1)
         throw new IllegalArgumentException("issue with Team EVC");
      
      this.squad = new Player[squad.length];
      
      this.code = code;
      this.country = country;
      
      for(int x = 0; x < squad.length; x++)
      {
         this.squad[x] = squad[x];
      }
   }
   
   
   @Override
   public String toString()
   {
      String str = "Country: " + this.country + " " + this.code + "\n";
      
      for(int x = 0; x < this.squad.length; x++)
      {
         str = str + this.squad[x].toString() + "\n";
      }
      
      return str;
   }
   
   @Override
   public int compareTo(Team another)
   {
      if(another == null)
         throw new IllegalArgumentException("bad params in compareTo");
         
      return this.code.compareTo(another.code);
   }

   public String getCountry() {return this.country;}
   
   public Player[] getPlayers()
   {
      Player[] temp = new Player[this.squad.length];
      
      for(int x = 0; x < temp.length; x++)
      {
         temp[x] = this.squad[x];
      }
      
      return temp;
   }
   
   public String getCode() {return this.code;}
   
    public void playersNaturalOrder()
    {
       Arrays.sort(this.squad);
    }
   
    public void playersTotalOrder()
    {
      Arrays.sort(this.squad, new PlayerPositionComparator());
    }
}