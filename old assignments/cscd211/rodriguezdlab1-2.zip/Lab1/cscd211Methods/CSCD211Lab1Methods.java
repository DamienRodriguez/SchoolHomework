package cscd211Methods;

import java.util.*;
import java.io.*;
import cscd211Classes.*;
import cscd211Enums.*;
import cscd211Utils.*;

public class CSCD211Lab1Methods
{
   private static Position determinePosition(final String str)
   {
      if(str == null || str.isEmpty())
         throw new IllegalArgumentException("bad params in determinPosition");
      
      
      return Position.valueOf(str.toUpperCase());
   }
   
   public static Team[] fillTeamsArray(final Scanner kb, int linesPer) throws java.io.FileNotFoundException
   {
      if(kb == null || linesPer <= 0)
         throw new IllegalArgumentException("bad params fillTeamsArray");
      
      File inFile = FileUtils.openInputFile(kb);
      
      Scanner fileIn = new Scanner(inFile);
      
      int totalTeams = FileUtils.countRecords(fileIn,linesPer);
      
      Team[] teams = new Team[totalTeams];
      
      fileIn.close();
      
      fileIn = new Scanner(inFile);
      
      
      for(int x = 0; x < teams.length; x++)
      {
         String line = fileIn.nextLine();                            //reads in next line to string
         String res[] = line.split(",");                             //Splits string at commas
         String fileName = "inputFiles/" + res[0].trim() + ".txt";   //Creates file name based on country code
         
         File fTemp = FileUtils.openInputFile(fileName);                       //opens file based on file name
         
         Player[] players = readPlayers(fTemp,linesPer);             //new array created using readPlayers private method
         
         teams[x] = new Team(res[0].trim(), res[1].trim(), players);  //Teams array filled
      }
      
      fileIn.close();
      
      return teams;
   }
   
   public static int menu(final Scanner kb)
   {
      int choice = 0;
      
      do
      {
         System.out.println("Please choose from the following menu");
         System.out.println("1) Print all teams to the screen");
         System.out.println("2) Print all teams to the User Specified File");
         System.out.println("3) Sort the Teams by Natural Order");
         System.out.println("4) Sort the Teams by Country Name");
         System.out.println("5) Sort each Teams' Players by Number");
         System.out.println("6) Sort each Team's Players by Position");
         System.out.println("7) Print an entire team and only that team to a user specified file");
         System.out.println("8) Print the players for an entire team and only that team to the screen");
         System.out.println("9) Quit");
         System.out.println("Please enter your choice -----> ");
         choice = kb.nextInt();
         kb.nextLine();
      }while(choice < 1 || choice > 9);
      return choice;
   }
   
   public static void printArray(final PrintStream output, final Comparable[] array)
   {
      for(Comparable s: array)
         output.println(s);  
   }
   
   private static Player[] readPlayers(final File inFile, final int linesPer) throws java.io.FileNotFoundException      
   {
      if(inFile == null || linesPer < 1)
         throw new IllegalArgumentException("bad params in readPlayers");
         
      Scanner fileIn = new Scanner(inFile);
      int totalPlayers = FileUtils.countRecords(fileIn,linesPer);
      Player[] array = new Player[totalPlayers];
      
      fileIn.close();
      
      fileIn = new Scanner(inFile);
      
      
      for(int x = 0; x < array.length; x++)
      {
         String line;
                  
         do
         {
            line = fileIn.nextLine();
         }while(line.isEmpty());
         
         String[] temp1 = line.split("##");     //created array with 2 elements
         
         line = temp1[0].trim();
         
         
         
         String[] temp2 = line.split("  ");
         temp2[0] = temp2[0].replace("(", "");
         temp2[0] = temp2[0].replace(")", "");
         
         Position position = determinePosition(temp2[1].trim().toUpperCase());   //array out of bounds error
         int num = Integer.parseInt(temp2[0].trim());
         
         array[x] = new Player(temp2[2].trim(), num, position);
      }
      
      fileIn.close();
      
      return array;
   }
}