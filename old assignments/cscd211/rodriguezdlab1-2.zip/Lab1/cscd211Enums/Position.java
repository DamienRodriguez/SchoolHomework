package cscd211Enums;

public enum Position
{
   DF("defensive midfielder"),FW("forward"),GK("goal keeper"),MF("midfielder");
   
   private String name;
   
   private Position(final String name)
   {
      if(name == null || name.isEmpty())
         throw new IllegalArgumentException("bad params in enum constructor");
      
      this.name = name;
   }
   
   @Override
   public String toString()
   {
      String returnTemp;
      
      String temp[] = this.name.split(" ");
      
      if(temp.length == 2)
      {
         temp[0] = temp[0].substring(0,1) + temp[0].substring(1);
         temp[1] = temp[1].substring(0,1) + temp[1].substring(1);
         
         returnTemp = temp[0] + " " + temp[1];
      }
      
      else
      {
         temp[0] = temp[0].substring(0,1) + temp[0].substring(1);
         returnTemp = temp[0];
      }
      
      return returnTemp;
   }
   
   
   
   
   
}