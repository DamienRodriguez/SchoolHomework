package cscd211Comparators;

import java.util.Comparator;
import cscd211Classes.*;

public class PlayerPositionComparator implements Comparator<Player>
{
   @Override
   public int compare(final Player p1, final Player p2)
   {
      return p1.getPosition().compareTo(p2.getPosition());
   }
}