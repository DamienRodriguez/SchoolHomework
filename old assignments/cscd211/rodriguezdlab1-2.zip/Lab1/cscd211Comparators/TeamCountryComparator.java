package cscd211Comparators;

import java.util.Comparator;
import cscd211Classes.*;

public class TeamCountryComparator implements Comparator<Team>
{
   @Override
   public int compare(Team t1, Team t2)
   {
      return t1.getCountry().compareTo(t2.getCountry());
   }  
}