package cscd211Inheritance;

public abstract class Employee implements Comparable<Employee>
{
	private double BASE, salary;
	private String name;
	

	public Employee(final String name, final double basePayrate, final double additionalPayrate)
	{
		if(name == null || name.isEmpty())
			throw new IllegalArgumentException("Bad params in employee constructor");

		this.BASE = basePayrate;
		this.name = name;
		this.salary = this.BASE + additionalPayrate;
	}

	public double getSalary()
	{
		return this.salary;
	}

	public double getBaseSalary()
	{
		return this.BASE;
	}

	public String getName()
	{
		return this.name;
	}

	public String getType()
	{
		return this.getClass().getSimpleName();
	}


	@Override
	public String toString()
	{
		return getName();
	}

	@Override
	public int compareTo(final Employee other)
	{
		int res = this.getType().compareTo(other.getType());
		if(res != 0)
			return res;
		return ((int)this.getSalary() * 100) - ((int)other.getSalary() * 100);
	}

	public abstract void report();






}
