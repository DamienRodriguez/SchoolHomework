package cscd211Inheritance;

public class Accountant extends Employee
{
	private double parkingStipend;

	public Accountant(final String name, final double basePayrate, final double additionalPayrate, final double parkingStipend)
	{
      super(name,basePayrate,additionalPayrate);
      
		if(parkingStipend < 0)
			throw new IllegalArgumentException("bad params in Accountant constructor");


		this.parkingStipend = parkingStipend;
	}

	public double getParkingStipend()
	{
		return this.parkingStipend;
	}

	@Override
	public void report()
	{
      String str = "I am an accountant. I make " + super.getSalary() + " plus a parking allowance of " + this.parkingStipend;
		System.out.println(str);
	}
	
	@Override
	public String toString()
	{
		return "Accountant: " + super.toString();
	}

}
