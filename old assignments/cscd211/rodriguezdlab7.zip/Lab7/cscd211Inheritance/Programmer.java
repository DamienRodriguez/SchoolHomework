package cscd211Inheritance;

public class Programmer extends Employee
{
	private boolean busPass;

	public Programmer(final String name, final double basePayrate, final double additionalPayrate, final boolean busPass)
	{
		super(name, basePayrate,additionalPayrate);
		this.busPass = busPass;
	}

	public boolean getBusPass()
	{
		return this.busPass;
	}

	@Override
	public void report()
	{
		String str = "I am a Programmer. I get " + super.getSalary() + " and I ";
		if(this.busPass)
			str += "get a bus pass.";
		else
			str += "do not get a bus pass.";

		System.out.println(str);
	}

	@Override
	public String toString()
	{
		return "Programmer: " + super.toString();
	}
}
