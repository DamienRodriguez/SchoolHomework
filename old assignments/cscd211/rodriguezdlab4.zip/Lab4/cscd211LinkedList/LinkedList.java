package cscd211LinkedList;

import java.util.NoSuchElementException;

public class LinkedList 
{
	private class Node
	{
		public Comparable data;
		public Node next;
		
		//DVC
		public Node()
		{
			this(null,null);
		}
		
		public Node(final Comparable data)
		{
			this(data,null);
		}
		
		public Node(final Comparable data, final Node next)
		{
			this.data = data;
			this.next = next;
		}
	}//end of Node class
	
	private Node head;
	private int size;
	
	//DVC
	public LinkedList()
	{
		this.head = null;
		this.size = 0;
	}
	
	public void clear()
	{
		this.head = null;
		this.size = 0;
	}
	
	public int size()
	{
		return size;
	}
	
	public void addFirst(final Comparable data)
	{
		Node newNode = new Node(data);
		if(this.size == 0)
		{
			this.head = newNode;
			this.size ++;
		}
		
		else
		{
			newNode.next = this.head;	//Connects to the first node
			this.head = newNode;		//slips into slot 0 to be first
			this.size ++;
		}
	}//End of addFirst
	
	@Override
	public String toString()
	{
		if(this.size == 0)
			return "Empty List";
		else
		{
			String str = "";
			Node cur = this.head;
			while(cur != null)
			{
				str += cur.data + " ";
				cur = cur.next;
			}//end while
			
         return str;
		
      }//end else
	}//end of toString class
	
	public void addLast(final Comparable data)
	{
		if(this.head == null)
			this.addFirst(data);
		
		else
		{
			Node newNode = new Node(data);
			Node cur = this.head;
			while(cur.next != null)
				cur = cur.next;		//walking through the list
			
			cur.next = newNode;		//connects our new node to the end of the list;
			this.size ++;
		
      }//end else
      
	}//end of addLast
	
	public void add(final int index, final Comparable data)
	{
		if(data == null)
			throw new IllegalArgumentException("bad data addIndex");
         
		if(index < 0 || index > this.size)
			throw new IndexOutOfBoundsException("bad index addIndex");
		
		if(index == 0)
			this.addFirst(data);
		
      else if(index == size)
			this.addLast(data);
		
      else
		{
			Node newNode = new Node(data);
			Node cur = this.head, prev = null;
			for(int x = 0; x < index; x++)
			{
				prev = cur;
				cur = cur.next;
			}
			
			newNode.next = cur;
			prev.next = newNode;
			this.size ++;
		}//end else
	}//end of add
	
	public Comparable removeFirst()
	{
		Node cur = this.head;
		this.head = cur.next;
		this.size --;
		
		Comparable deletedVal = cur.data;
		cur.data = null;
		cur.next = null;
		return deletedVal;
	}//end of removeFirst
	
	public Comparable removeLast()
	{
		if(this.head == null)
			throw new NoSuchElementException("Your list is empty");
		
		Node cur = this.head, prev = null;
		for(; cur.next != null; cur = cur.next)
		{
			prev = cur;
		}
		//cur is at end of list;
		
		if(prev == null)
		{
			this.head = cur.next;
			Comparable deletedVal = cur.data;
			this.size --;
			
			cur.data = null;
			cur.next = null;
			
			return deletedVal;
		}//end of if
		
		else
		{
			prev.next = cur.next;
			Comparable deletedVal = cur.data;
			cur.data = null;
			cur.next = null;
			this.size --;
			
			return deletedVal;
         
		}//end else
	}//end of removeLast
	
	public boolean contains(final Comparable item)
	{
		Node cur = this.head;
		boolean found = false;
		
		while(cur != null)
		{
			if(cur.data.compareTo(item) == 0) //walks through the list, checks data of each list and compares to give item
				found = true;
			cur = cur.next;
		}
		return found;
	}//end of contains
	
	public int indexOf(final Comparable item)
   {
      if(item == null)
         throw new IllegalArgumentException("bad indexOf params");
      
      int index = 0;
      Node cur = this.head;
      
      while(cur != null)
      {
         if(cur.data.compareTo(item) == 0)
            return index;
         
         cur = cur.next;
         index++;
      }
      
      return -1;
   }
	
	public Comparable remove(final int index)
	{
		if(index < 0 || index > this.size)
			throw new IndexOutOfBoundsException("bad index val @ remove");
		
		if(index == 0)
		{
			Node cur = this.head;
			Comparable deletedVal = cur.data;
			this.removeFirst();
			return deletedVal;
			
		}
		
      else if(index == this.size)
		{
			Node cur = this.head;
			while(cur != null)
				cur = cur.next;
			
			Comparable deletedVal = cur.data;
			this.removeLast();
			return deletedVal;
		}
      
		else
		{
			Node cur = this.head, prev = null;
			
			for(int x = 0; x < index; x ++)
			{
				prev = cur;
				cur = cur.next;
			}
			//cur is now at the index wanted
			
			prev.next = cur.next;
			
			Comparable deletedVal = cur.data;
			
			cur.data = null;
			cur.next = null;
			
			return deletedVal;
		}
	}//end of delete by index
   
   public boolean removeFirstOccurrence(final Comparable item)
   {
      if(item == null)
         throw new IllegalArgumentException("bad params removeFirstOccurence");
      
      Node cur = this.head;
      int count = 0;
      boolean found = false;
      
      while(cur != null)
      {
         if(cur.data.compareTo(item) == 0)
         {
            found = true;
            break;
         }
         count ++;
      }
      
      if(found)
      {
         this.remove(count);
      }
      
      return found;
   }//end of removeFirstOccurance
   
   public boolean removeLastOccurrence(final Comparable item)
   {
      Node cur = this.head;
      int index = 0, count = 0;
      boolean found = false;
      
      while(cur != null)
      {
         if(cur.data.compareTo(item) == 0)
         {
            index = count;
            found = true;
         }
         cur = cur.next;
         count ++;
      }
      
      if(found)
         this.remove(index); 
      
      return found;
      
   }//end of removeLastOccurrence
   
}//end of Class
