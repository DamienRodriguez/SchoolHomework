package cscd211Methods;

import java.util.*;

public class Lab3Methods extends Object
{
   public static void addNum(final ArrayList<Double> myList, final Scanner kb)
   {
      if(myList == null || kb == null)
         throw new IllegalArgumentException("bad params in addNum");
      
      double res;
      
      System.out.println("Please enter a number you'd like to add to the list: ");
      res = kb.nextDouble();
      kb.nextLine();
      
      myList.add(new Double(res));
   }
   
   public static double computeMean(final ArrayList<Double> myList)
   {
      if(myList == null)
         throw new IllegalArgumentException("bad params in computeMean");
      
      double mean = 0.0;
      Double temp;
      
      for(int x = 0; x < myList.size(); x++)
      {
         temp = Double.valueOf(myList.get(x));
         mean += temp.doubleValue(); 
      }
         
      return mean / myList.size();
   }
   
   public static double computeMedian(final ArrayList<Double> myList)
   {
      if(myList == null)
         throw new IllegalArgumentException("bad params in computeMedian");
      
      Double temp;
      double result = 0.0;
      
      Collections.sort(myList);
      
      if(myList.size() % 2 == 1)
      {
         temp = Double.valueOf(myList.get(myList.size() / 2));
         return temp.doubleValue();
      }
      
      else
      {
         temp = Double.valueOf(myList.get(myList.size() / 2) - 1);
         result += temp.doubleValue();
         
         temp = Double.valueOf(myList.get(myList.size() / 2));
         result += temp.doubleValue();
         
         return result / 2;
         
      }
   }
   
   public static double computeMidpoint(final ArrayList<Double> myList)
   {
      if(myList == null)
         throw new IllegalArgumentException("bad params in computeMidpoint");
      
      double min, max;
      
      Collections.sort(myList);
      
      Double temp = Double.valueOf(myList.get(0));
      min = temp.doubleValue();
      
      temp = Double.valueOf(myList.get(myList.size() - 1));
      max = temp.doubleValue();
         
      return (min + max) / 2;
   }
   
   public static double computeStandardDeviation(final ArrayList<Double> myList)
   {
      if(myList == null)
         throw new IllegalArgumentException("bad params in computeStandardDeviation");
      
      double total = 0.0;
      double mean = computeMean(myList);
      double temp;
      
      ArrayList<Double> myNewList = new ArrayList<Double>(myList.size());
      
      for(int x = 0; x < myList.size(); x++)
      {
         temp = Double.valueOf(myList.get(x)).doubleValue() - mean;
         myNewList.add(x, Double.valueOf(temp));
      }
      
      for(int x = 0; x < myNewList.size(); x++)
      {
         temp = myNewList.get(x).doubleValue();
         
         total += (temp * temp);
      }
      
      total = total / (myList.size() - 1);
      total = Math.sqrt(total);
      
      return total;
   }
   
   public static void deleteValue(final ArrayList<Double> myList, final Scanner kb)
   {
      if(myList == null || kb == null || myList.size() < 1)
         throw new IllegalArgumentException("bad params in deleteValue");
      
      double res = 0;
      boolean found = false;
      int x;
      Double temp;
      
      do
      {
         System.out.println("Please enter the value you want deleted from the list (1-100 inclusive): ");
         res = kb.nextDouble();
         kb.nextLine();
      }while(res < 1 || res > 100);
      
      for(x = 0; x < myList.size(); x++)
      {
         temp = Double.valueOf(myList.get(x));
         
         if(temp.doubleValue() == res)
         {
            found = true;
            break;
         }
      }
      
      if(found)
      {
         temp = Double.valueOf(myList.get(x));
         System.out.println("Item to be deleted: " + temp.doubleValue());
         myList.remove(x);
      }
      
      else
      {
         System.out.println("Number not found in your list.");
      }
   }
   
   public static void deleteValueByIndex(final ArrayList<Double> myList, final Scanner kb)
   {
      if(myList == null || kb == null)
         throw new IllegalArgumentException("bad params in deleteValueByIndex");
      
      int res;
      
      System.out.println("Please enter the index of the num you want to delete from the list: ");
      res = kb.nextInt();
      
      myList.remove(res);
      
   }
   
   public static void fillArrayList(final int size, final ArrayList<Double> myList)
   {
      if(myList == null || size < 1)
         throw new IllegalArgumentException("bad params in fillArrayList");
      
      double rand;
      
      for(int x = 0; x < size; x++)
      {
         rand = (Math.random() * 100) + 1;
         rand = Math.round(rand);
         myList.add(x, new Double(rand));
      }
   }
   
   public static int menu(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad params in menu");
      
      int choice = 0;
      do
      {
         System.out.println("1) Add a value to the ArrayList");
         System.out.println("2) Delete a value from the ArrayList (by value)");
         System.out.println("3) Delete a value from the ArrayList (by index/location)");
         System.out.println("4) Display the ArrayList");
         System.out.println("5) Compute the mean of the ArrayList");
         System.out.println("6) Compute the median of the ArrayList");
         System.out.println("7) Compute the midpoint of the ArrayList");
         System.out.println("8) Compute the standard deviation of the ArrayList");
         System.out.println("9) Quit");
         System.out.println("Please enter your choice -----> ");
         choice = kb.nextInt();
         kb.nextLine();
      
      
      }while(choice < 0 || choice > 9);
      return choice;
   }
   
   public static void printArrayList(final ArrayList<Double> myList)
   {
      if(myList == null)
         throw new IllegalArgumentException("bad params in printArrayList");
         
      System.out.println(myList);
   }
   
   public static void printResults(final String type, final double value)
   {
      if(type == null || type.isEmpty())
         throw new IllegalArgumentException("bad params in printResults");
      
      System.out.println("The " + type + " of your list is: " + value);
   }
   
   public static int readNum(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad params in readNum");
      
      int res = 0;
      
      do
      {
         System.out.println("Please enter a positive number that is greater than or equal to 1");
         res = kb.nextInt();
         kb.nextLine();
         
      }while(res < 0);
      
      return res;
   }
   
   
}

