package cscd211Classes;

import cscd211Enums.*;

public class Vehicle implements Comparable<Vehicle>
{
   private Integer cylinders;
   private double liters;
   private VehicleManufacturers manufacturer;
   private String model;
   
   public Vehicle(final VehicleManufacturers manufacturer, final String model, final double liters, final Integer cylinders)
   {
      if(manufacturer == null || model == null || model.isEmpty() || liters <= 0 || cylinders < 1)
         throw new IllegalArgumentException("bad params in Vehicle constructor \n");
      
      this.manufacturer = manufacturer;
      this.model = model;
      this.liters = liters;
      this.cylinders = cylinders;
      
   }
   
   public Vehicle(final VehicleManufacturers manufacturer, final String model, final Integer cylinders, final double liters)
   {
      this(manufacturer,model,liters,cylinders);
   }
   
   @Override
   public int compareTo(final Vehicle anotherVehicle)
   {
      if(anotherVehicle == null)
         throw new IllegalArgumentException("bad params in compareTo n Vehicle Class \n");
      
      int res = this.manufacturer.compareTo(anotherVehicle.manufacturer);
      
      if(res != 0)
         return res;
      
      res = this.model.compareTo(anotherVehicle.model);
      
      if(res != 0)
         return res;
      
      res = this.cylinders - anotherVehicle.cylinders;
      
      if(res != 0)
         return res;
      
      return (int)(this.liters * 10) - (int)(anotherVehicle.liters * 10);
   }
   
   public VehicleManufacturers getManufacturer()
   {
      return this.manufacturer;
   }
   
   public String getModel()
   {
      return this.model;
   }
   
   @Override
   public String toString()
   {
      String str = "Your " + this.manufacturer.toString() + " " + this.model + " is a " + this.cylinders.intValue() + " banger with a " + this.liters + " engine.";
      
      return str;   
   }
}