package cscd211Comparators;

import java.util.Comparator;
import cscd211Classes.Vehicle;

public class ModelComparator implements Comparator<Vehicle>
{
   public int compare(final Vehicle v1, final Vehicle v2)
   {
      if(v1 == null || v2 == null)
         throw new IllegalArgumentException("bad params in ModCom");
      
      return v1.getModel().compareTo(v2.getModel());
   }
}