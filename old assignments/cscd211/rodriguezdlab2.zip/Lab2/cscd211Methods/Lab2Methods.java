package cscd211Methods;

import java.util.Scanner;
import cscd211Classes.Vehicle;
import cscd211Enums.*;


public class Lab2Methods
{
   public static VehicleManufacturers convertStringToVehicleManufacturers(final String manufacturer)
   {
      if(manufacturer == null || manufacturer.isEmpty())
         throw new IllegalArgumentException("bad params in convertString in methods class");
         
      return VehicleManufacturers.valueOf(manufacturer.toUpperCase());
      
      
   }
   
   public static int menu(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("bad params in menu");
      
      int choice = 0;
      do
      {
         System.out.println("1) Print the array to the screen");
         System.out.println("2) Sort the array based on natural order");
         System.out.println("3) Sort the array by manufacturer");
         System.out.println("4) Sort the array by model");
         System.out.println("5) Print array to user specified file");
         System.out.println("6) Quit");
         System.out.println("Please enter your choice -----> ");
         choice = kb.nextInt();
         kb.nextLine();
         
      }while(choice < 1 || choice > 6);
      
      return choice;
     
   }
   
   public static Vehicle[] fillArray(final Scanner fileIn, final int total)
   {
      if(fileIn == null || total < 1)
         throw new IllegalArgumentException("bad params in fillArray");
      
      Vehicle[] array = new Vehicle[total];
      
      VehicleManufacturers manufacturer;
      String model;
      double liters;
      Integer cylinders;
      
      
      for(int x = 0; x < array.length; x++)
      {
         manufacturer = convertStringToVehicleManufacturers(fileIn.nextLine().trim());
         model = fileIn.nextLine().trim();
         cylinders = Integer.parseInt(fileIn.nextLine().trim());
         liters = Double.valueOf(fileIn.nextLine()).doubleValue();
         array[x] = new Vehicle(manufacturer,model,cylinders,liters);
      }
      
      return array;
   }
}