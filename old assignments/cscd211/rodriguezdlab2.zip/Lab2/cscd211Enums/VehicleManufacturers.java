package cscd211Enums;

import java.util.*;
import java.io.*;

public enum VehicleManufacturers
{
   CHRYSLER,FORD,HONDA,MERCEDES,NISSAN,TOYOTA,VOLKSWAGON;
   
   @Override
   public String toString()
   {
      String str = this.name();
      str = str.substring(0,1) + str.substring(1).toLowerCase();
      return str;
   }
}