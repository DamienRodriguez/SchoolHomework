package cscd211Package.vehicle;

import java.util.Scanner;
import java.util.Date;

import java.text.SimpleDateFormat;
import java.io.PrintStream;

import cscd211Package.type.Package;
import cscd211Package.type.*;

import java.util.Arrays;

public class Truck extends Object
{
   private String driver;
   private int load, maxPackages;
   private Package[] thePackages;
   
   private double pounds, ounces;
   
   public Truck(final String driver, final int maxPackages)
   {
      if(driver == null)
         throw new NullPointerException("bad params in truck constructor.");
      if(driver.isEmpty() || maxPackages < 1)
         throw new IllegalArgumentException("bad params in truck constructor.");
      
      this.driver = driver;
      this.maxPackages = maxPackages;
      
      thePackages = new Package[maxPackages];
   
   }//end of EVC
   
   public int getMaxPackages()
   {
      return this.maxPackages;
   }
   
   public String getDriver()
   {
      return this.driver;
   }
   
   public int getLoad()
   {
      return this.load;
   }
   
   
   
   public void load(final Scanner fin, final PrintStream fout)
   {
      if(fin == null || fout == null)
         throw new NullPointerException("bad params in load");
      
      String cur, temp6, outToFile;
      int temp1, temp2, temp3, temp4, temp5, counter = 0;
      
      
      while(fin.hasNext())
      {
         cur = fin.nextLine();
         temp1 = Integer.parseInt(cur);

         
         
         if(temp1 % 10 == 0)    //letter
         {
            temp2 = Integer.parseInt(fin.nextLine());
            temp3 = Integer.parseInt(fin.nextLine());
            temp4 = Integer.parseInt(fin.nextLine());
            
            Letter letter = new Letter(temp1,temp2,temp3, temp4);
            
            if(letter.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package Loaded: Package #" + (counter + 1) + ": \n" + letter.toString();
               loadPackage(letter,counter);
               
               this.ounces += temp2;
               
               printToLog(fout,outToFile);
               counter ++;
            }
            
            else if(letter.measureAndScale() && counter > this.maxPackages)
            {
               outToFile = "Package not loaded: " + letter.toString() + "\n Package not loaded because the truck is full.";
               printToLog(fout,outToFile);
            }
            
            else if(!letter.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package not loaded: " + letter.toString() + "\n Package not loaded because it was too big in either size or weight.";
               printToLog(fout,outToFile);
            } 
         
         }//End of letter if
         
         
         
         
         else if(temp1 % 10 == 1) //box
         {
            temp2 = Integer.parseInt(fin.nextLine());
            temp3 = Integer.parseInt(fin.nextLine());
            temp4 = Integer.parseInt(fin.nextLine());
            temp5 = Integer.parseInt(fin.nextLine());
            
            Box box = new Box(temp1, temp2, temp3, temp4, temp5);
            
            if(box.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package Loaded: Package #" + (counter + 1) + ": \n" + box.toString();
               loadPackage(box,counter);
               
               this.pounds += temp2;
               
               printToLog(fout,outToFile);
               counter ++;
            }
            
            else if(box.measureAndScale() && counter > this.maxPackages)
            {
               outToFile = "Package not loaded: " + box.toString() + "\n Package not loaded because the truck is full.";
               printToLog(fout,outToFile);
            }
            
            else if(!box.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package not loaded: " + box.toString() + "\n Package not loaded because it was too big in either size or weight.";
               printToLog(fout,outToFile);
            }
            
         
         }//End of Box if
         
        
        
        
        
        
         
         else if(temp1 % 10 == 2) //metal crate
         {
            temp2 = Integer.parseInt(fin.nextLine());
            temp3 = Integer.parseInt(fin.nextLine());
            temp4 = Integer.parseInt(fin.nextLine());
            temp5 = Integer.parseInt(fin.nextLine());
            temp6 = fin.nextLine();                   //how is this null
            
            MetalCrate metalCrate = new MetalCrate(temp1,temp2,temp3,temp4,temp5, temp6);
            
            if(metalCrate.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package Loaded: Package #" + (counter + 1) + ": \n" + metalCrate.toString();
               loadPackage(metalCrate,counter);
               this.pounds += temp2;
               printToLog(fout,outToFile);
               counter ++;
            }
            
            else if(metalCrate.measureAndScale() && counter > this.maxPackages)
            {
               outToFile = "Package not loaded: " + metalCrate.toString() + "\n Package not loaded because the truck is full.";
               printToLog(fout,outToFile);
            }
            
            else if(!metalCrate.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package not loaded: " + metalCrate.toString() + "\n Package not loaded because it was too big in either size or weight.";
               printToLog(fout,outToFile);
            }
           
         }//End of Metal Crate if
         
          
         
         
         else if(temp1 % 10 == 3) //wood crate
         {
            temp2 = Integer.parseInt(fin.nextLine());
            temp3 = Integer.parseInt(fin.nextLine());
            temp4 = Integer.parseInt(fin.nextLine());
            temp5 = Integer.parseInt(fin.nextLine());
            temp6 = fin.nextLine();
            
            WoodCrate woodCrate = new WoodCrate(temp1,temp2,temp3,temp4,temp5, temp6);
            
            if(woodCrate.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package Loaded: Package #" + (cur + 1) + ": \n" + woodCrate.toString();
               loadPackage(woodCrate,counter);
               this.pounds += temp2;
               printToLog(fout,outToFile);
               counter ++;
            }
            
            else if(woodCrate.measureAndScale() && counter > this.maxPackages)
            {
               outToFile = "Package not loaded: " + woodCrate.toString() + "\n Package not loaded because the truck is full.";
               printToLog(fout,outToFile);
            }
            
            else if(!woodCrate.measureAndScale() && counter <= this.maxPackages)
            {
               outToFile = "Package not loaded: " + woodCrate.toString() + "\n Package not loaded because it was too big in either size or weight.";
               printToLog(fout,outToFile);
            }
         
         }//End of Wood Crate if
         
         else
         {
            temp2 = Integer.parseInt(fin.nextLine());
            temp3 = Integer.parseInt(fin.nextLine());
            temp4 = Integer.parseInt(fin.nextLine());
            temp5 = Integer.parseInt(fin.nextLine());
            
            outToFile = "Package was not loaded becasue of an unknown tracking number. Tracking Num: " + temp1 + " Weight - " + temp2 + " Length - " + temp3 + " Width - " + temp4 + " Height - " + temp5;
            printToLog(fout,outToFile);
         }  
      }
   }
   
   
   public void drive(final PrintStream fout)
   {
      if(fout == null)
         throw new NullPointerException("bad params in drive");
      
      Arrays.sort(this.thePackages);
      SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
      Date date = new Date();
      fout.println("Departure Date: " + formatter.format(date));
   }
   
   
   public void unload(final PrintStream fout)
   {
      if(fout == null)
         throw new NullPointerException("bad params in unload");
      
      int count = 1;
      
      for(int x = 0; x < maxPackages; x ++)
      {
         fout.println(thePackages[x].toString() + " has been unloaded.");
         count ++;
      }
      
      fout.println("The total weight of the packages was: " + calcWeight());
      fout.println("The total amount of packages delievered was: " + count);
      
   
   }
   
   protected void loadPackage(final Package toAdd, final int index)
   {
      if(index < maxPackages)
         this.thePackages[index] = toAdd;   
   }
   
   protected void printToLog(final PrintStream fout, final String str)
   {
      fout.println(str);
   }
   
   public double calcWeight()
   {
      double total;
      
      total = this.pounds + (this.ounces * 0.0625);
      
      return total;
   }
}