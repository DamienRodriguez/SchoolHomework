package cscd211Package.type;

public abstract class Crate extends Package
{
   protected String contents;
   private int height;
   
   protected Crate(final int trackNum, final int weight, final int length, final int width, final int height, final String contents)
   {
      
      super(trackNum, weight, length, width);
      if(contents == null)
         throw new NullPointerException("bad params in crate constructor.");
      if(contents.isEmpty() || height < 1)
         throw new IllegalArgumentException("bad params in crate constructor.");
         
      this.height = height;
      this.contents = contents;
   
   }//end of EVC
   
   public int getHeight()
   {
      return this.height;
   }
   
   public String getContents()
   {
      return this.contents;
   }
   
   @Override
   public String toString()
   {
      return super.toString();
   }
}