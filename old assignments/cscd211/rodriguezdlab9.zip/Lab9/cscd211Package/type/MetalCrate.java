package cscd211Package.type;


public class MetalCrate extends Crate
{
   protected static int MAX_HEIGHT = 36; 
   protected static int MAX_LENGTH = 36; 
   protected static int MAX_WEIGHT = 100;
   protected static int MAX_WIDTH = 60;
   
   private String contents;
   
   public MetalCrate(final int trackNum, final int weight, final int length, final int width, final int height, final String contents)
   {
      super(trackNum, weight, length, width, height, contents);
   }
   
   public String getType()
   {
      return "metal crate";
   }
   
   @Override
   public String toString()
   {
      return super.toString() + this.weight + "lb " + getType() + ", contents: " + this.contents + ".";
   
   }
   
   public boolean measureAndScale()
   {
      if(this.getHeight() > MAX_HEIGHT || this.weight > MAX_WEIGHT || this.length > MAX_LENGTH || this.width > MAX_WIDTH)
         return false;
      
      return true;
   }
}