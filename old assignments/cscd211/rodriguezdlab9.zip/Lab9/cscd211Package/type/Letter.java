package cscd211Package.type;

public class Letter extends Package
{
   protected static int MAX_LENGTH = 18;
   protected static int MAX_WEIGHT = 24;  //ounces
   protected static int MAX_WIDTH = 18;
    
   public Letter(final int trackNum, final int weight, final int length, final int width)
   {
      super(trackNum, weight, length, width);
   }
   
   public String getType()
   {
      return "letter";
   }
   
   @Override
   public String toString()
   {
      return super.toString() + this.weight + "oz " + getType() + ".";
   }
   
   public boolean measureAndScale()
   {
      if(this.weight > MAX_WEIGHT || this.length > MAX_LENGTH || this.width > MAX_WIDTH)
         return false;
      
      return true;
   }
}