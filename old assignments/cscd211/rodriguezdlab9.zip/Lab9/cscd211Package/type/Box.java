package cscd211Package.type;

public class Box extends Package
{
   private int height; //in inches
   
   protected static int MAX_HEIGHT = 36; 
   protected static int MAX_LENGTH = 36; 
   protected static int MAX_WEIGHT = 100; 
   protected static int MAX_WIDTH = 36;
   
   public Box(final int trackNum, final int weight, final int length, final int width, final int height)
   {
      super(trackNum, weight, length, width);
      if(height < 1)
         throw new IllegalArgumentException("green text here");
      
      this.height = height;   
   
   }//End of EVC
   
   @Override
   public String getType()
   {
      return "box";
   }
   
   public int getHeight()
   {
      return this.height;
   }
   
   @Override
   public String toString()
   {
      return super.toString() + this.weight + "lb " + getType() + ".";
   }
   
   public boolean measureAndScale()
   {
      if(this.height > MAX_HEIGHT || this.weight > MAX_WEIGHT || this.length > MAX_LENGTH || this.width > MAX_WIDTH)
         return false;
      
      return true;
   }  
}