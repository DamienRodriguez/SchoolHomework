package cscd211Package.type;

public abstract class Package extends Object implements Comparable<Package>
{
   protected int length, trackNum, weight, width;
   private boolean tooBig;
   
   protected Package(final int trackNum, final int weight, final int length, final int width)
   {
      if(trackNum < 1 || weight < 1)
         throw new IllegalArgumentException("bad params in package constructor.");
         
      this.trackNum = trackNum;
      this.weight = weight;
      this.length = length;
      this.width = width;
   
   }//End of EVC
   
   
   protected void setTooBig(final boolean tooBig)
   {
      this.tooBig = tooBig;
   }
   
   public abstract String getType();
   
   public abstract boolean measureAndScale();
   
   public int getWeight()
   {
      return this.weight;
   }
   
   public int getTrackNum()
   {
      return this.trackNum;
   }
   
   protected boolean getTooBig()
   {
      return this.tooBig;
   }
   
   @Override
   public String toString()
   {
      String str = "TrackingNum: " + this.trackNum + " \t Length: " + this.length + ", Width: " + this.width + " Package is a ";
      return str;
   }
   
   @Override
   public int compareTo(final Package other)
   {
      int res = this.getType().compareTo(other.getType());
      
      if(res != 0)
         return res;
      
      return this.getWeight() - other.getWeight();
   
   }//End of Compare To
   
   public int getWidth()
   {
      return this.width;
   }
   
   public int getLength()
   {
      return this.length;
   }
   
   
   
}//End of Package class