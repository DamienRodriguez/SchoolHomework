package cscd211LinkedList;

import java.util.NoSuchElementException;


public class LinkedList
{
   private class Node
   {
      public Comparable data;
      public Node next;
      
      public Node()
      {
         this.data = null;
         this.next = null;
      }
      
      public Node(final Comparable data)
      {
         this.data = data;
         this.next = null;
      }
      
      public Node(final Comparable data, final Node next)
      {
         this.data = data;
         this.next = next;
      }
   }
   
   private Node head;
   private int size;
   
   public LinkedList(final Comparable[] array)
   {
      if(array == null)
         throw new IllegalArgumentException("bad LinkedList things");
      
      this.head = new Node();
      this.size = 0;
      Node cur = this.head;
      
      for(int x = 0; x < array.length; x++)
      {
         cur.next = new Node(array[x]);
         cur = cur.next;
         this.size++;
      }
   }

   
   public int size()
   {
      return this.size;
   }
   
   public void clear()
   {
      this.head = new Node();
      this.size = 0;
   }
   
   public void addFirst(final Comparable item)
   {
      if(item == null)
         throw new NullPointerException("Bad params in addFirst");
      
      Node newNode = new Node(item);
      this.head = newNode;
      this.size ++;
   }
   
   public Comparable removeLast()
   {
      if(this.size == 0)
         throw new NoSuchElementException("list is empty in removeLast");
      
      Comparable last;
      Node cur = this.head.next, prev = this.head;
      
      for(; cur != null; cur = cur.next)
         prev = cur;
      
      last = cur.data;
      
      prev.next = cur.next;
      cur.data = null;
      cur.next = null;
      this.size --;
      
      return last;
   }
   
   public Comparable remove(final int index)
   {
      if(index < 0 || index >= this.size)
         throw new IndexOutOfBoundsException("Bad params in remove");

      Node cur = this.head.next, prev = this.head;
      
      for(int x = 0; x < index; x++)
      {
         prev = cur;
         cur = cur.next;
      }
      
      prev.next = cur.next;
      Comparable val = cur.data;
      cur.data = null;
      cur.next = null;
      this.size --;
      
      return val;
   }
   
   @Override
   public String toString()
   {
      if(this.size == 0)
         return "Empty List";
      
      Node cur = this.head.next;
      String str = "[" + cur.data;
      cur = cur.next;
      
      for(; cur != null; cur = cur.next)
         str += ", " + cur.data;
      
      str += "]";
      return str;

   }
   
   public boolean add(final Comparable item)
   {
      if(item == null)
         throw new NullPointerException("bad params add");
      
      Node newNode = new Node(item);
      Node cur = this.head.next;
      
      while(cur != null)
         cur = cur.next;
         
      cur.next = newNode;
      
      return true;
   }
   
   public boolean addAll(final int index, final Comparable[] array)
   {
      if(array == null)
         throw new NullPointerException("bad array in addAll");
      if(index < 0 || index > this.size)
         throw new IndexOutOfBoundsException("bad index in addAll");
      
      Node cur = this.head.next;
      int x = 0;
      for(; x < index; x ++)
      {
         cur = cur.next;
      }
      
      for(; cur != null; cur = cur.next)
      {
         Node newNode = new Node(array[x]);
         this.head.next = newNode;
         this.size ++;
         x ++;
      }
      
      return true;
   }
   
   public Comparable get(final int index)
   {
      if(index < 0 || index > this.size)
         throw new IndexOutOfBoundsException("bad index in get");
      
      Node cur = this.head.next;
      
      for(int x = 0; x < index; x++)
         cur = cur.next;
      
      return cur.data;
   }
   
   public Comparable getLast()
   {
      if(size == 0)
         throw new NoSuchElementException("list is empty in getLast()");
      
      Comparable becauseICan = get(this.size);
      
      return becauseICan;
   }
   
   public Comparable remove()
   {
      if(size == 0)
         throw new NoSuchElementException("list empty at remove");
      
      Comparable d = this.head.next.data;
      this.head.next = this.head.next.next;
      this.size --;
      
      return d;
   }
   
   public Comparable[] toArray()
   {
      Comparable[] array = new Comparable[this.size];
      
      Node cur = this.head.next;
      
      for(int x = 0; x < this.size; x ++)
      {
         array[x] = cur.data;
         cur = cur.next;
      }
      
      return array;   
   }
}