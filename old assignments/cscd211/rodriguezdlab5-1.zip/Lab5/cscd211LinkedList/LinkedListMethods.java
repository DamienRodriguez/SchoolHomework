package cscd211LinkedList;

import java.util.Scanner;
import cscd211Misc.*;


public class LinkedListMethods
{
   public static BoxCar createBoxCar(final Scanner kb)
   {
      if(kb == null)
         throw new NullPointerException("bad params createBoxCar");
      
      BoxCar temp;
      String contents;
      do
      {
         System.out.println("What are the contents of you box car? ");
         contents = kb.nextLine();
      }while(contents.isEmpty() || contents == null);
      
      temp = new BoxCar(contents);
      
      return temp;
   }
   
   public static BoxCar[] fillArray(final Scanner kb, final int total)
   {
      if(kb == null)
         throw new NullPointerException("bad scanner fillArray");
      
      if(total < 1)
         throw new IllegalArgumentException("bad total val fillArray");
      

      BoxCar[] myArray = new BoxCar[total];
      
      
      for(int x = 0; x < total; x++)
      {
         
         System.out.println("please enter the contents of your box car");
         String temp = kb.nextLine();
         
         myArray[x] = new BoxCar(temp);
      }      
      
      return myArray;
   }
   
   public static int menu(final Scanner kb)
   {
      if(kb == null)
         throw new NullPointerException("bad params in menu");
         
      int choice = 0;
      
      do
      {
         System.out.println("1) Print the List"); 
         System.out.println("2) Create a BoxCar and append the specified element to the end of this list."); 
         System.out.println("3) addAll(index, array) ");
         System.out.println("4) Read an index and get the data at that index ");
         System.out.println("5) getLast ");
         System.out.println("6) remove ");
         System.out.println("7) removeIndex ");
         System.out.println("8) removeLast ");
         System.out.println("9) toArray ");
         System.out.println("10) clear the list ");
         System.out.println("11) Print the size of the list");
         System.out.println("Please enter your choice ----->");
         
         choice = Integer.parseInt(kb.nextLine()); 
      }while(choice < 1 || choice > 11);
      
      return choice;
   }   
   public static int readIndex(final Scanner kb)
   {
      if(kb == null)
         throw new NullPointerException("bad parans readIndex");
      
      int index = 0;
      do
      {
         System.out.println("Please enter an index value greater than -1: ");
         
         index = kb.nextInt(); 
      }while(index < 0);
      
      kb.nextLine();
      
      return index;
   }
}