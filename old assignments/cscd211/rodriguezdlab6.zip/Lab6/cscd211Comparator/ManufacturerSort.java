package cscd211Comparator;

import cscd211Inheritance.*;
import java.util.Comparator;

public class ManufacturerSort implements Comparator<Engine>
{
	@Override
	public int compare(final Engine e1, final Engine e2)
	{
		return e1.getManufacturer().compareTo(e2.getManufacturer());
	}
}
