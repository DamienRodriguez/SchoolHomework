package cscd211Inheritance;

public class CarEngine extends Engine
{
	public CarEngine(final int horsePower, final String manufacturer)
	{
		super(horsePower,manufacturer);
	}

	public CarEngine(final String manufacturer, final int horsePower)
	{
		super(horsePower,manufacturer);
	}

	@Override
	public String toString()
	{
		return super.toString();
	}

	@Override
	public int calcOutput()
	{
		return super.calcOutput() / 12;
	}
}
