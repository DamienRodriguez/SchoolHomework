package cscd211Inheritance;

public class TruckEngine extends Engine
{
	private boolean diesel;

	public TruckEngine(final String manufacturer, final int horsePower, final boolean diesel)
	{
		super(horsePower,manufacturer);
		this.diesel = diesel;
	}
	
	@Override
	public String toString()
	{
		String str = "Truck Engine - " + super.toString();
		if(this.diesel)
			str += " and takes diesel.";
		else
			str+= " and does not take diesel.";

		return str;
	}

	@Override
	public int calcOutput()
	{
		int res = super.calcOutput();
		if(this.diesel)
			res = res / 18;
		else
			res = res / 8;

		return res;
	}

}
