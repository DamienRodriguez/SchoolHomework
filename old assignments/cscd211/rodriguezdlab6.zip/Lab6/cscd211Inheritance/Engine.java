package cscd211Inheritance;

import java.util.Scanner;

public class Engine implements Comparable<Engine>
{
	protected int horsePower;
	private String manufacturer;

	public Engine(final int horsePower, final String manufacturer)
	{
		if(manufacturer == null || manufacturer.isEmpty() || horsePower <= 0)
			throw new IllegalArgumentException("bad params in engine constructor");
		this.horsePower = horsePower;
		this.manufacturer = manufacturer;
	}

	public Engine(final String manufacturer, final int horsePower)
	{
		this(horsePower,manufacturer);
	}

	@Override
	public String toString()
	{
		return "Manufacturer: " + this.manufacturer + " HP: " + this.horsePower;
	}

	public int calcOutput()
	{
		return this.horsePower * 5;
	}

	public String getManufacturer()
	{
		return this.manufacturer;
	}

	@Override
	public int compareTo(final Engine other)
	{
		if(other == null)
			throw new IllegalArgumentException("bad params in compareTo");

		int res = this.calcOutput() - other.calcOutput();
		if(res != 0)
			return res;
		res = this.manufacturer.compareTo(other.manufacturer);
		return res;
	}

}
