package cscd211Inheritance.Players;

public abstract class Player extends Object implements Comparable<Player>, Cloneable
{
	protected String firstName, lastName, position, ssn;
	protected int salary;





	protected Player(final String firstName, final String lastName, final String ssn, final int salary, final String position)
	{
		if(firstName == null || lastName == null || ssn == null || position == null || firstName.isEmpty() || lastName.isEmpty() || ssn.isEmpty() || position.isEmpty())
			throw new IllegalArgumentException("bad params in player constructor");

		this.firstName = firstName;
		this.lastName = lastName;
		this.ssn = ssn;
		this.salary = salary;
		this.position = position;
	}


	public Player clone() throws CloneNotSupportedException
	{
		return (Player)super.clone();
	}

	public int getSalary()
	{
		return this.salary;
	}

	public String getPosition()
	{
		return this.position;
	}

	public String getName()
	{
		return getFirstName() + " " + getLastName();
	}

	public String getSSN()
	{
		return this.ssn;
	}

	public String getLastName()
	{
		return this.lastName;
	}

	public String getFirstName()
	{
		return this.firstName;
	}

	@Override
	public String toString()
	{
		return getName() + " " + getSSN() + " " + getSalary() + " " + getPosition();
	}

	@Override
	public int compareTo(final Player other)
	{
		int res = getLastName().compareTo(other.getLastName());

		if(res != 0)
			return res;
		return getFirstName().compareTo(other.getFirstName());
	}
}
