package cscd211Inheritance.Team;

import cscd211Inheritance.Players.*;
import cscd211Interfaces.Taxable;

import java.util.ArrayList;

public class Team implements Taxable, Comparable<Team>
{
   private static int BASE_PAYROLL = 200000;
   
   protected String city, teamName;
   protected int payroll;
   protected ArrayList<Comparable> players;
   
   public Team(final String city, final String teamName, final Player[] players) throws CloneNotSupportedException
   {
      if(teamName == null || city == null || players == null || city.isEmpty() || teamName.isEmpty())
         throw new IllegalArgumentException("bad params in Team constructor");
      
      this.city = city;
      this.teamName = teamName;
      this.players = new ArrayList<Comparable>();
      
      for(int x = 0; x < players.length; x ++)
      {
         this.players.add(players[x]);
      }
   }//end of constructor
   
   public String getTeamName() {return this.teamName;}
   
   public ArrayList<Comparable> getPlayers() {return this.players;}
   
   public String getCity() {return this.city;}
   
   public int getPayroll() {return this.payroll;}
   
   @Override
   public String toString()
   {
      String str = this.city + "-" + this.teamName + "\n Payroll: " + this.payroll + "\n Taxes: " + calculateTaxes() + "\n";
      
      for(int x = 0; x < this.players.size(); x ++)
      {
         str += players.get(x).toString() + "\n";
      }
      
      return str;
   }
   
   @Override
   public double calculateTaxes()
   {
      double total = 0.0;
      
      for(int x = 0; x < this.players.size(); x ++)
      {
         int sum = ((Player)(this.players.get(x))).getSalary();
         if(sum > 250000)
            total += (sum * BASE_TAX_RATE);
         else
            total += (sum * (BASE_TAX_RATE / 2));
      }
      
      return total;
   }
   
   @Override
   public int compareTo(final Team other)
   {
      if(other == null)
         throw new IllegalArgumentException("Bad params in compareTo in Team class.");
      
      int res = getCity().compareTo(other.getCity());
      if(res != 0)
         return res;
      return getTeamName().compareTo(other.getTeamName());
   }
   
   protected int sumPayroll()
   {
      int total = 0;
      for(int x = 0; x < this.players.size(); x ++)
      {
         int sum = ((Player)(this.players.get(x))).getSalary();
         total += sum;
      }
      return total;
   }
   
}