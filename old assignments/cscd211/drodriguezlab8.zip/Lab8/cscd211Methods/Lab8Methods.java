package cscd211Methods;

import java.util.Scanner;
import java.util.ArrayList;
import cscd211Inheritance.Team.*;
import cscd211Inheritance.Players.*;


public class Lab8Methods
{
	public static void fill(final Scanner fileIn, final ArrayList<Team> myTeam) throws CloneNotSupportedException
	{
		if(fileIn == null || myTeam == null)
			throw new IllegalArgumentException("Bad params in fill");
		
      String str = fileIn.nextLine();
      
      while(str != null)
      {
         String str1 = str;
         String str2 = fileIn.nextLine();
         int numOf = Integer.parseInt(fileIn.nextLine());
         Player[] players = new Player[numOf];
         
         for(int y = 0; y < numOf; y ++)
         {
            String temp1 = fileIn.nextLine();
            String[] thing = temp1.split(" ");
            
            String temp2 = fileIn.nextLine();
            int temp3 = Integer.parseInt(fileIn.nextLine());
            String temp4 = fileIn.nextLine();
            String temp5 = fileIn.nextLine();
            
            if(temp5.contains("."))
            {
               BaseballPlayer temp6 = new BaseballPlayer(thing[0], thing[1], temp2, temp3, temp4, Double.parseDouble(temp5));
               players[y] = temp6;  
            }
            
            else
            {
               FootballPlayer temp7 = new FootballPlayer(thing[0], thing[1], temp2, temp3, temp4, Integer.parseInt(temp5));
               players[y] = temp7;
            }
         }
         
         
         myTeam.add(new Team(str1, str2, players));
         
         if(fileIn.hasNext())
            str = fileIn.nextLine();
         else
            str = null;
      }
      
      
      

	}

	public static int menu(final Scanner kb)
	{
		if(kb == null)
			throw new IllegalArgumentException("Bad params in menu");
		int choice = 0;
		do
		{
			System.out.println("Please choose from the following menu");
			System.out.println("1) Print all teams");
			System.out.println("2) Sort all players on each team by last name then first");
			System.out.println("3) Sort all teams by city and team name");
			System.out.println("4) Sort all teams by payroll");
			System.out.println("5) Exit program");
			System.out.println("Enter your choice -----> ");
			choice = Integer.parseInt(kb.nextLine());
		}while(choice < 1 || choice > 5);
		return choice;
	}
}
