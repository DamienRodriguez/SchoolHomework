package cscd211Interfaces;

public interface Taxable
{
	static final double BASE_TAX_RATE = 0.068;

	public double calculateTaxes();
}
