Presentation -> https://www.youtube.com/watch?v=bLcGtaW0L0E&feature=youtu.be
Presentation materials -> https://docs.google.com/presentation/d/1rgVYT1BtCDA4A-EUv8x9QaWz_M28zHf79A2T7yqDvW0/edit#slide=id.g8974bf4f55_0_87
