When compiling source files, you will need to add the jarFile that is 
inside of the driversNeeded file as an external library to the project.

