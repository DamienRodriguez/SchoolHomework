/*
Names:

Colton Estlund
Todd Lahman
Damien Rodriguez

Team 9 - Lab 6
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CSCD437RegExMethods
{
	public static void easySSNPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("([\\s-]?[0-9][\\s-]?){9}", str);
        fout.println(result ? "valid" : "not valid");
	}// end easySSN
   
   
   public static void mediumEasySSNPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("[0-9]{3}[\\s-]?[0-9]{2}[\\s-]?[0-9]{4}", str);
        fout.println(result ? "valid" : "not valid");
	}// end mediumEasySSN
   
   
   public static void newSSNPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^((?!666|000|9)[0-9]{3}[\\s-]?(?!00)[0-9]{2}[\\s-]?(?!0000)[0-9]{4}|9[0-9]{2}[\\s-]?9\\d[\\s-]?[0-9]{4})$", str);
        fout.println(result ? "valid" : "not valid");
	}// end newSSN


   public static void phonePatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^(\\+1)?\\s?\\(?[0-9]{3}\\)?[-]?[0-9]{3}[-]?[0-9]{4}$", str);
        fout.println(result ? "valid" : "not valid");
	}// end phoneNumber


	public static void emailPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^[A-Za-z0-9]+.?[A-Za-z0-9]+[^.]@[A-Za-z0-9]*\\.[A-Za-z]+$", str);
        fout.println(result ? "valid" : "not valid");
	}// end email
   
   
	public static void namePatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^[A-Za-z]*, [A-Za-z]*(, [A-Z]*)?$", str);
        fout.println(result ? "valid" : "not valid");
	}// end name
	
   
   public static void datePatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^((0?[013456789]|1[012])[\\/-]([012]?[0-9]|3[01])[\\/-][0-9]{4}|0?2[\\/-][012][0-8][\\/-][0-9]{4}|0?2[\\/-]29[\\/-](?:(?:[1-9]\\d)(?:0[48]|[2468][048]|[13579][26])|(?:(?:[2468][048]|[13579][26])00)))$", str);
        fout.println(result ? "valid" : "not valid");
	}// end date
	
   
   public static void addressPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^\\d* [NSEW] [A-Za-z0-9]* (Avenue|Ave|Blvd|Boulevard|Road|Rd|Street|St)$", str);
        fout.println(result ? "valid" : "not valid");
	}// end address
	
   
   public static void cityStateZipPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^[A-Za-z]*,?\\s[A-Z]{2}\\s\\d{5}(-\\d{4})?$", str);
        fout.println(result ? "valid" : "not valid");
	}//end cityStateZip
	
   
   public static void militaryTimePatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^[0-2]([0-4]|(?<=1)[0-9])[0-5][0-9][0-5][0-9]$", str);
        fout.println(result ? "valid" : "not valid");
	}// end militaryTime
	
   
   public static void moneyPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^\\$\\d{1,3}(,\\d{3})*.\\d{2}$", str);
        fout.println(result ? "valid" : "not valid");
	}// end money
	
   
   public static void urlPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^(http://|https://|HTTP://|HTTPS://)?(www.|WWW.)?[A-Za-z0-9]+\\.[A-Za-z0-9-]+(/[A-Za-z0-9]+)*$", str);
        fout.println(result ? "valid" : "not valid");
	}// end URL
	
   
   public static void passwordPatternTester(final String str, final PrintStream fout)
	{
	    //(?![a-z][a-z][a-z][a-z])([A-Za-z0-9.!?\\-]){10,}
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^(?![a-z][a-z][a-z][a-z])(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[.!,?-])[A-Za-z\\d.!,?]{10,}$", str);
        fout.println(result ? "valid" : "not valid");
	}// end password
	
   
   public static void evenErPatternTester(final String str, final PrintStream fout)
	{
        if(str == null || str.isEmpty())
            throw new IllegalArgumentException("Bad str Parameter to the method");
        fout.println(str);
        boolean result = Pattern.matches("^([A-Za-z][A-Za-z])+er$", str);
        fout.println(result ? "valid" : "not valid");
	}// end oddIon

}// end class

/*
TESTS:
1. Easy SSN:

    Tests Ran:
    1. 123456789 - valid
    2. 123 45 6789 - valid
    3. 123-45-6789 - valid
    5. 56 7 88 888 8 - valid
    4. 123     45  6789 - not valid
    6. 44- 3 -21-   9876 - not valid
    7. 88888    888 - not valid

2. Medium SSN

    Tests Ran:
    123456789 - valid
    123-45-6789 - valid
    123 45 6789 - valid
    123-45 6789 - valid
    12345-6789 - valid
    12-345-6789 - not valid
    123--45-6789 - not valid
    123.45.6789 - not valid

3. New SSN

    Tests Ran:
    123-45-6789 - valid
    723-45-6789 - valid
    823-45-6789 - valid
    923-95-6789 - valid
    666-45-6789 - not valid
    000-45-6789 - not valid
    123-00-6789 - not valid
    123-45-0000 - not valid
    123-456-7890 - not valid
    12-345-6789 - not valid

4. US Phone Number

    Tests Ran:
    5092942281 - valid
    (509)2942281 - valid
    509-294-2281 - valid
    509-2942281 - valid
    (509)294-2281 - valid
    +1 5092942281 - valid
    +15092942281 - valid
    (509)-294-2281 - valid
    509 294 2281 - not valid
    294-2281 - not valid

5. E-mail Address

    Tests Ran:
    stusteiner@ewu.edu - valid
    stu.steiner@ewu.edu - valid
    stu.steiner.@ewu.edu - not valid
    stu.steiner@ewu - not valid
    stu..steiner@ewu.edu - not valid

6. Name on Class Roster

    Tests Ran:
    Estlund, Colton, R - valid
    Lahman, Todd - valid
    Damien, Rodriguez, MI - valid
    Last Name, First Name, MI - not valid
    Estlund, Colton, - not valid

7. Date

    Tests Ran:
    02/29/2000 - valid
    12/25/1967 - valid
    3-14-2039 - valid
    2-29-2100 - not valid
    2-29-2001 - not valid

8. House Address

    Tests Ran:
    3424 E 36th Ave - valid
    3424 E 36th Avenue - valid
    36879 E Southwest Blvd - valid
    36879 E Southwest Boulevard - valid
    1090 W Betz Rd - valid
    1090 W Betz Road - valid
    48902 E Jesperson Street - valid
    48902 E Jesperson St - valid
    245 Hack Stet - not valid

9. City State Zip

    Tests Ran:
    Spokane, WA 99223 - valid
    Spokane WA 99223 - valid
    Spokane WA 99223-4205 - valid
    Spokane Wa 99223 - not valid
    Spokane 99223 - not valid
    WA 99223 - not valid

10. Military Time

    Tests Ran:
    150934 - valid
    245959 - valid
    255959 - not valid
    246050 - not valid
    125960 - not valid

11. Money

    Tests Ran:
    $123,456,789.23 - valid
    $1.23 - valid
    $12,345.00 - valid
    $12.000 - not valid
    12.00 - not valid

12. URL

    Tests Ran:
    https://google.com - valid
    http://google.com - valid
    http://www.google.com - valid
    ewu.edu/csee - valid
    http://www.ewu.edu/csee - valid
    ewu..edu - not valid
    ewu.edu//csee - not valid
    http:/www.google.com - not valid

13. Password

    Tests Ran:
    pasSwor!123 - valid
    Stu!sAwes45 - valid
    passwor!123 - not valid
    pasSwor!ds - not valid
    password - not valid

14. Even number ending in "er"

    Tests Ran:
    controller - valid
    summer - valid
    ever - valid
    another - not valid
    surrender - not valid
 */
