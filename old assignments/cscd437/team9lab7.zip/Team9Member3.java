/*
Name: Damien Rodriguez
*/

package lab7;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Team9Member3 {
    private static final String NAME_VALIDATION = "^(?=.{2,50}$)(([A-Za-z]|\\s?|-?)*\\s?(M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3}))?)$";
    private static final String NAZI_HUNTING = "((h|H)(i|I)(t|T)(l|L)(e|E)(r|R))";
    private static final String PASSWORD_VALIDATION = "^(?=(?:.*[A-Z]){1,})(?=(?:.*[a-z]){1,})(?=(?:.*\\d){2,})(?=(?:.*[#%^&()\\-_=+{};:,<.>]){1,})([A-Za-z0-9#%^&()\\-_=+{};:,<.>]{5,})$";
    private static final String NUMBER_CHECK = "(01|12|23|34|45|56|67|78|89|00|11|22|33|44|55|66|77|88|99)";
    private static final String FILE_VALIDATION = "^([A-Za-z0-9])*.txt$";

    private static String input_file;
    private static String first_name;
    private static String last_name;
    private String password = null;
    private static byte[] salt = new byte[32];
    
    public Team9Member3() {}
    
    private boolean regexValidation(final String user_input, final String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(user_input);

        if(!matcher.find()) {
            //System.out.println("Error logging should occur here.");
            return false;
        }
        return true;
    }

    private boolean regexValidation(final String user_input, final String validRegex, final String invalidRegex) {
        Pattern invalidPattern = Pattern.compile(invalidRegex);
        Pattern validPattern = Pattern.compile(validRegex);
        Matcher matcher = invalidPattern.matcher(user_input);

        if(matcher.find()) {
            return false;
        }
        matcher = validPattern.matcher(user_input);
        if(!matcher.find()) {
            return false;
        }
        return true;
    }

    private boolean existenceValidation(final String user_input) {
        File checker = new File("./"+user_input);
        return checker.exists();
    }

    public void nameValidation() throws IOException {
        String first_name = prompt("First name(s)");
        String last_name = prompt("Last name(s)");
        
        if(!regexValidation(first_name, Team9Member3.NAME_VALIDATION, Team9Member3.NAZI_HUNTING)) {
            Team9Member2.logError("First name(s) entered was invalid.");
            //return false;
        }
        if(!regexValidation(last_name, Team9Member3.NAME_VALIDATION, Team9Member3.NAZI_HUNTING)) {
            Team9Member2.logError("Last name(s) entered was invalid.");
            //return false;
        }
        
        this.setFirst_name( first_name );
        this.setLast_name( last_name );
        
        //return true;
    }

    public void fileValidation() throws IOException {
        String file_name = prompt("input file");
        if(!regexValidation(file_name, lab7.Team9Member3.FILE_VALIDATION)) {
            Team9Member2.logError(file_name + " is considered as invalid input.");
            return;
        }
        if(!existenceValidation(file_name)) {
            Team9Member2.logError(file_name + " does not exist in present directory.");
            return;
        }
        setInput_file(file_name);
        //return true;
    }

    public boolean passwordMatch(final String first_input, final String second_input) {
        return first_input.equals(second_input);
    }

    public void passwordValidation() throws IOException, NoSuchAlgorithmException {
        String initial = prompt("password");
        if(!regexValidation(initial, Team9Member3.PASSWORD_VALIDATION, Team9Member3.NUMBER_CHECK)) {
            Team9Member2.logError("Password was invalid.");
            //return false;
        }
        else {
            String confirmation = prompt("password again");
            if(!passwordMatch(initial, confirmation)) {
                Team9Member2.logError("Passwords did not match.");
                //return false;
            }
            else {
                this.password = initial;
                this.storeEncryption();
            }
        }

        //return true;
    }

    public static String getInput_file() {
        return input_file;
    }

    public void setInput_file(String input_file) {
        Team9Member3.input_file = input_file;
    }

    public void setFirst_name(final String first_name) {
        Team9Member3.first_name = first_name;
    }

    public void setLast_name(final String last_name) {
        Team9Member3.last_name = last_name;
    }

    public static String getFirst_name() {
        return Team9Member3.first_name;
    }

    public static String getLast_name() {
        return Team9Member3.last_name;
    }

    public static byte[] getSalt() { return Team9Member3.salt; };
    
    public byte[] getHashedPassword() throws NoSuchAlgorithmException {
        return this.hashPassword( this.password );
    }
    
    public byte[] hashPassword( String password ) throws NoSuchAlgorithmException {
        final Random r = new SecureRandom();
        r.nextBytes(this.salt);

        MessageDigest md = MessageDigest.getInstance("SHA-512");
        md.update(this.salt);

        return md.digest(password.getBytes(StandardCharsets.UTF_8));
    }

    public void storeEncryption() throws IOException, NoSuchAlgorithmException {
        Charset charset = Charset.forName("UTF-8");
        String password = new String( this.getHashedPassword(), charset );
        File db = new File("db.txt");
        if(!db.exists())
            db.createNewFile();

        FileWriter fw = new FileWriter( "db.txt", false );
        BufferedWriter bw = new BufferedWriter( fw );
        
        bw.write(Team9Member1.getUsername() + ":");
        bw.write(this.salt.toString()  + ":");
        bw.write(password);
        bw.close();
    }

    private String prompt(final String info_request) {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter your " + info_request + ": ");
        return in.nextLine();
    }   
}