package lab7;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.regex.Pattern;

/*
 * Student: Todd Lahman
 * Class: CSCD 437
 * Quarter: EWU Summer 2021
 * Assignment: Lab 7 - Defend Your Code
 * 
 * Methods: 4 -> email(), 8 -> outputFile(), 9 -> relogin(), and error logging -> logError().
 */
public class Team9Member2 {
    private String email = null;
    
    public Team9Member2() {}

    public boolean email() throws IOException {
        boolean matched = false;
        System.out.println( "\nEnter an email address:" );
        Scanner input = new Scanner(System.in);
        String allowed = "^[a-zA-Z0-9_+&*]+(?:[\\.-][a-zA-Z0-9_+&*]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        String temp_email = "";
        
        if ( input.hasNext() ) {
            temp_email = input.nextLine();
        }
        
        if ( temp_email != null && !temp_email.isEmpty() ) {
            /*
             * An invocation of this method of the form str.matches(regex) yields exactly the same result as the expression
             * Pattern.matches( regex, str )
             */
            matched = temp_email.matches( allowed );
            
            if  ( matched == false ) {
                logError( "The email address entered contained characters that are not allowed." );
            }
            else {
                this.email = temp_email;
            }
        } else {
            logError( "The email address entered was an empty string or null." );
        }
        
        return matched;
    }

    private int safeAdd(int x, int y) throws IOException {
        if (x > 0 && (y < Integer.MIN_VALUE + x || y > Integer.MAX_VALUE + x)) {
            Team9Member2.logError("Overflow caused by adding.");
        }
        else {
            return x + y;
        }
        return 0;
    }

    private int safeMultiply(int x, int y) throws IOException {
        if (x > 0 && ((y > Integer.MAX_VALUE/x || y < Integer.MIN_VALUE/x)
                || (x < -1) && ((y > Integer.MIN_VALUE/x || y < Integer.MAX_VALUE/x) || (x == -1 && y == Integer.MAX_VALUE)))) {
            Team9Member2.logError("Overflow caused by multiplying.");
        }
        else {
            return x * y;
        }
        return 0;
    }
    
    public void outputFile() throws IOException, ArithmeticException {
        Scanner input = null;
        boolean hasEmail = this.email != null && !this.email.isEmpty();
        boolean hasLastName = Team9Member3.getLast_name() != null && !Team9Member3.getLast_name().isEmpty();
        boolean hasFirstName = Team9Member3.getFirst_name() != null && !Team9Member3.getFirst_name().isEmpty();
        int sum = this.safeAdd( Team9Member1.getInt1(), Team9Member1.getInt2() );
        int product = this.safeMultiply( Team9Member1.getInt1(), Team9Member1.getInt2() );
        
        if ( !hasEmail ) {
            logError( "The email value has not been set yet since Menu option 4 has not been chosen yet." );
        }
        
        String outputFile = Team9Member1.getVerifiedOutputFilename();
        File output = new File( outputFile );
        
        if ( !output.exists() ) {
            output.createNewFile();
        } /*else {
            logError( "The " + outputFile + " file is missing and could not be created." );
        }*/

       if ( output.canWrite() ) {
           FileWriter fw = new FileWriter( outputFile, true );
           BufferedWriter bw = new BufferedWriter( fw );
           
           bw.write( hasLastName ? Team9Member3.getLast_name() + ", " : "" );
           bw.write( hasFirstName ? Team9Member3.getFirst_name(): "" );
           bw.newLine();
           bw.write( sum + "\n");
           //bw.newLine();
           bw.write( product + "\n" );
           //bw.newLine();
           bw.write( hasEmail ? this.email + "\n" : "" );
           //bw.newLine();
           
           String inputFile = Team9Member3.getInput_file();
           File inputFileObject = null;
           if (inputFile != null) {
               inputFileObject = new File(inputFile);
               if (inputFileObject.exists() && inputFileObject.canRead()) {
                   input = new Scanner(inputFileObject);

                   while (input.hasNextLine()) {
                       bw.write(input.nextLine());
                       bw.newLine();
                   }

                   bw.close();
               }
           }
           else {
               Team9Member2.logError("The input file is not existant! Please select option 6 and try again.");
           }
       } else {
           logError( "Unable to write to " + outputFile + "." );
       }
    }
    
    private String getUsername() throws IOException {
        String input = this.readUserData("Please input your username:");
        if (Pattern.matches("^[A-Za-z][A-Za-z0-9_]{2,24}$", input)) {
            return input;
        } else {
            Team9Member2.logError("Invalid username read: " + input);
            return "";
        }
    }
    
    private byte[] getHashedPassword() throws IOException, NoSuchAlgorithmException {
        String password = this.readUserData("Please input your password: ");
        if (Pattern.matches("(01|12|23|34|45|56|67|78|89|00|11|22|33|44|55|66|77|88|99)", password))
            return null;
        else {
            if (Pattern.matches("^(?=(?:.*[A-Z]){1,})(?=(?:.*[a-z]){1,})(?=(?:.*\\d){2,})(?=(?:.*[#%^&()\\-_=+{};:,<.>]){1,})([A-Za-z0-9#%^&()\\-_=+{};:,<.>]{5,})$", password)) {
                byte[] salt = Team9Member3.getSalt();
                MessageDigest md = MessageDigest.getInstance("SHA-512");
                md.update(salt);
                return md.digest(password.getBytes(StandardCharsets.UTF_8));
            }

        }
        return null;
    }

    private String readUserData(String prompt) throws IOException {
        Scanner kb = new Scanner(System.in);
        System.out.println(prompt);
        if (kb.hasNextLine()) {
            return kb.nextLine();
        }
        else {
            Team9Member2.logError("Error, nextLine not available.");
        }
        return null;
    }
    
    public void relogin() throws IOException, NoSuchAlgorithmException {
        Charset charset = Charset.forName("UTF-8");
        String username = this.getUsername();
        String password = new String( this.getHashedPassword(), charset );
        String[] dbFileData = null;
        boolean usernamesMatch = false;
        boolean passwordsMatch = false;
        File dbFile = new File( "db.txt" );
        
        if ( dbFile.exists() ) {
            Scanner input = new Scanner( dbFile );
            
            if ( input.hasNextLine() ) {
                dbFileData = input.nextLine().split( ":" );
                usernamesMatch = username.contentEquals( dbFileData[0] );
                passwordsMatch = password.contentEquals( dbFileData[2] );
            }
        } else {
            logError( "The " + dbFile + " file does not exist." );
        }
        
        if (!passwordsMatch || !usernamesMatch) {
            Team9Member2.logError("Password or Username is incorrect!");
        }
    }
    
    public static void logError( String msg ) throws IOException {
        String file = "errors.txt";
        File f = new File( file );
        
        if ( !f.exists() ) {
            f.createNewFile();
        } /*else {
            System.out.print( "The " + file + " file is missing and could not be created." );
        }*/

       if ( f.canWrite() ) {
           FileWriter fw = new FileWriter( file, true );
           BufferedWriter bw = new BufferedWriter( fw );
           
           bw.write( msg );
           bw.newLine();
           bw.close();
       } else {
           System.out.print( "Unable to write to " + file + "." );
       }
    }
}