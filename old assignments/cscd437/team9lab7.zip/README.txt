Names:

Colton Estlund
Todd Lahman
Damien Rodriguez

Shortcomings:

As far as short comings, we feel pretty confident about the program. Any requirements we could think of testing were tested, and did function correctly. We feel any issues are small.

Compilation Instructions:
- Place all .java and .txt (except README.txt) files in the SAME directory.
- compile, and run CSCD437Lab7.java as you would any other java file, and you will then be presented with the menu.