/*
Name: Colton Estlund
Issues: None that I was able to discover.
*/

package lab7;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Team9Member1 {
    private static String username = null;
    private static int int1 = 0;
    private static int int2 = 0;
    private static String verifiedOutputFilename;

    public Team9Member1() {
        int1 = 0;
        int2 = 0;
    }
    
    public static String getUsername() {
        return username;
    }

    public static int getInt1() {
        return int1;
    }

    public static int getInt2() {
        return int2;
    }

    public static String getVerifiedOutputFilename() {
        return verifiedOutputFilename;
    }

    private String readUserData(String prompt) throws IOException {
        Scanner kb = new Scanner(System.in);
        System.out.println(prompt);
        if (kb.hasNextLine()) {
            return kb.nextLine();
        }
        else {
            Team9Member2.logError("Error, nextLine not available.");
        }
        return null;
    }

    //2) Prompt for and read in a username.
    public void username() throws IOException {
        String input = this.readUserData("Please enter a username (25 or less letters, numbers, or underscore. Please begin with a letter):");
        if (Pattern.matches("^[A-Za-z][A-Za-z0-9_]{2,24}$", input)) {
            username = input;
            FileWriter fw = new FileWriter( "db.txt", false );
            BufferedWriter bw = new BufferedWriter( fw );
            bw.write(input);
            bw.flush();
        } else {
            Team9Member2.logError("Invalid username read: " + input);
        }
    }

    //5) Prompt for and read two int values from the user
    public void twoInt() throws IOException {
        //^(-?0*([0-9]{1,9}|1[0-9]{9})|-2[1][0-4][0-7][0-4][0-8][0-3][0-6][0-4][0-8]|2[1][0-4][0-7][0-4][0-8][0-3][0-6][0-4][0-7])$
        String input = this.readUserData("Please enter an integer (between -2147483648 and +2147483647): ");
        if (Pattern.matches("^(-?\\+?0*([0-9]{1,9}|1[0-9]{9})|-2[1][0-4][0-7][0-4][0-8][0-3][0-6][0-4][0-8]|2[1][0-4][0-7][0-4][0-8][0-3][0-6][0-4][0-7])$", input)) {
            int1 = Integer.parseInt(input);
        } else {
            int1 = 0;
            Team9Member2.logError(input + "is not a valid integer");
        }
        input = this.readUserData("Please enter another integer (between -2147483648 and +2147483647): ");
        if (Pattern.matches("^(-?\\+?0*([0-9]{1,9}|1[0-9]{9})|-2[1][0-4][0-7][0-4][0-8][0-3][0-6][0-4][0-8]|2[1][0-4][0-7][0-4][0-8][0-3][0-6][0-4][0-7])$", input)) {
            int2 = Integer.parseInt(input);
        } else {
            int2 = 0;
            Team9Member2.logError(input + " is not a valid integer");
        }
    }

    //7) Prompt for and read the name of an output file from the user
    public void outputName() throws IOException {
        String input = this.readUserData("Please input a filename (no directories)");
        if (Pattern.matches("^.*\\\\.*$", input)) { //invalid input, directory not allowed
            Team9Member2.logError("Invalid input. A directory is not valid, we must ensure the file is in the same location as the running program.");
        }
        else if (Pattern.matches("^[A-Za-z0-9]*.txt$", input)) { //valid input.
            verifiedOutputFilename = input;
        }
        else { //file name contains invalid characters.
            Team9Member2.logError("Invalid input. Filename contains invalid characters, or is not a text file.");
        }
    }
}
