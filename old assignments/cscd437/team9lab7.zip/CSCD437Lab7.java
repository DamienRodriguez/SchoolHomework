package lab7;

import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.util.*;


public class CSCD437Lab7 
{
	public static void main(String [] args) throws IOException, NoSuchAlgorithmException
   {
      Scanner kb = new Scanner(System.in);
      int choice =  10;
      
      Team9Member1 t1 = new Team9Member1();
      Team9Member2 t2 = new Team9Member2();
      Team9Member3 t3 = new Team9Member3();

      do
      {
         choice = menu(kb);
         
         switch(choice)
         {
            case 1:  System.out.println("1) First name and last name");
                     t3.nameValidation();
                     break;
                     
            case 2:  System.out.println("2) Username");
                     t1.username();
                     break;
                     
            case 3:  System.out.println("3) Password");
                     t3.passwordValidation();
                     break;
         
            case 4:  System.out.println("4) Email");
                     t2.email();
                     break;
                     
            case 5:  System.out.println("5) Two integers");
                     t1.twoInt();
                     break;
                     
            case 6:  System.out.println("6) Input file name");
                     t3.fileValidation();
                     break;
                     
            case 7:  System.out.println("7) Output file name");
                     t1.outputName();
                     break;
                     
            case 8:  System.out.println("8) Output file");
                     t2.outputFile();
                     break;
                     
            case 9:  System.out.println("9) Relogin");
                     t2.relogin();
                     break;
                     
            default: System.out.println("10) Quit");
         
         } // emd switch
       
      }while(choice != 10);   
   
   
   }// end main
   
   public static int menu(final Scanner kb)
   {
      if(kb == null)
         throw new IllegalArgumentException("Bad Scanner menu");
       
      int choice; 
         
      do
      {
         System.out.println(" 1) Enter first name and last name");
         System.out.println(" 2) Enter username");
         System.out.println(" 3) Enter password");
         System.out.println(" 4) Enter email");
         System.out.println(" 5) Read two integers");
         System.out.println(" 6) Enter the input file name");
         System.out.println(" 7) Enter the output file name");
         System.out.println(" 8) Write to the output file");
         System.out.println(" 9) Please relogin");
         System.out.println("10) Quit");
         System.out.print("Choice --> ");
      
         choice = kb.nextInt();      
      
      }while(choice < 1 || choice > 10);
      
      return choice;
   
   }// end menu
   
}// end class