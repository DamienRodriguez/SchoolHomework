package lab5;

import java.io.*;
import java.security.*;
import java.util.*;
import javax.crypto.*;

public class CSCD437Crypto {
    private KeyPairGenerator keyPairGen;
    private KeyPair pair;
    private PrivateKey privateKey;
    private PublicKey publicKey;
    private Signature sign;

    public CSCD437Crypto(String signatureAlgo, String keyPairAlgo, int size) {
        this.generateKeys(signatureAlgo, keyPairAlgo, size);
    }

    public void decrypt(String filename, String transformation) {
        try {
            File file = new File(filename);
            FileInputStream fIn = new FileInputStream(file);
            byte[] byteArr;
            byteArr = fIn.readAllBytes();
            Cipher c = Cipher.getInstance(transformation);
        c.init(Cipher.DECRYPT_MODE, this.privateKey);
        c.update(byteArr);
        System.out.println(new String(c.doFinal()));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }
    }

    public void encrypt(PublicKey publicKey, String transformation, File messageFile, String encryptedFilename) {
        try {
            Cipher c = Cipher.getInstance(transformation);
            c.init(Cipher.ENCRYPT_MODE, publicKey);
            Scanner scan = new Scanner(messageFile);
            String message = "";
            while (scan.hasNext()) {
                message += "\n";
                message += scan.nextLine();
            }
            byte[] msg = message.getBytes();
            c.update(msg);
            byte[] fin = c.doFinal();
            FileOutputStream output = new FileOutputStream(encryptedFilename);
            output.write(fin);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (BadPaddingException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void encrypt(PublicKey publicKey, String transformation, String message, String encryptedFilename) {
        try {
            Cipher c = Cipher.getInstance(transformation);
            c.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] msg = message.getBytes();
            c.update(msg);
            byte[] fin = c.doFinal();
            FileOutputStream output = new FileOutputStream(encryptedFilename);
            output.write(fin);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (BadPaddingException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void generateKeys(String signatureAlgo, String keyPairAlgo, int keySize) {
        try {
            this.sign = Signature.getInstance(signatureAlgo);
            this.keyPairGen = KeyPairGenerator.getInstance(keyPairAlgo);
            this.keyPairGen.initialize(keySize);
            this.pair = this.keyPairGen.generateKeyPair();
            this.privateKey = pair.getPrivate();
            this.publicKey = pair.getPublic();
        } catch (NoSuchAlgorithmException e) {
            System.out.printf("Invalid signature algorithm!");
        }
    }

    public static PublicKey getPublicKey(String filename) {
        try {
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream objFile = new ObjectInputStream(file);
            return (PublicKey) objFile.readObject();
        } catch (FileNotFoundException e) {
            System.out.printf("Could not open file.");
            System.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    }

    public void publishPublicKey(String filename) {
        try {
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream objFile = new ObjectOutputStream(file);
            objFile.writeObject(this.publicKey);
        } catch (FileNotFoundException e) {
            System.out.printf("Could not open file.");
            System.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
