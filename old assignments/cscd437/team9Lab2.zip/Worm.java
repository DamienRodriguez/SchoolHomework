import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Worm {
    public static void main(String ... args) throws IOException {
        String thisName = args[0];
        int nextNum = Integer.parseInt(args[1]);
        int max = Integer.parseInt(args[2]);
        quine(new String[] {thisName, "Worm" + nextNum + ".java"});
        if (nextNum <= max) {
            String compile = "javac " + "Worm" + nextNum + ".java";
            System.out.println(executeCommand(compile));
            String run = "java Worm" + nextNum + " Worm" + nextNum + ".java" + " " + String.valueOf(++nextNum) + " " + String.valueOf(max);
            System.out.println(executeCommand(run));
        }
    }

    public static String executeCommand(String command) throws IOException {
        Scanner scanner = new Scanner(Runtime.getRuntime().exec(command).getInputStream()).useDelimiter("\\A");
        if (scanner.hasNext())
            return scanner.next();
        return "";
    }

    public static void quine(String[] args) {
        if (args.length != 2) {
            System.out.println("Invalid arguments.");
            throw new RuntimeException();
        }
        File thisFile = null;
        Scanner fileScan = null;
        PrintWriter dupeWrite = null;
        try {
            thisFile = new File(args[0]);
            fileScan = new Scanner(thisFile);
            dupeWrite = new PrintWriter(args[1]);
        }
        catch (FileNotFoundException e) {
            System.out.println("File " + thisFile + " not found!");
        }
        System.out.println();
        while (fileScan.hasNext()) {
            String line = fileScan.nextLine();
            System.out.println(line);
            if (line.equals("public class " + args[0].substring(0, args[0].length() - 5) + " {")) {
                dupeWrite.println("public class " + args[1].substring(0, args[1].length() - 5) + " {");
            }
            else {
                dupeWrite.println(line);
            }
        }
        dupeWrite.close();
    }
}
