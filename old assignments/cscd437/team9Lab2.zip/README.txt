Team 9

Members:
Colton Estlund
Todd Lahman
Damien Rodriguez


How to run the worm:

1. Unzip to folder of choice.
2. Open a terminal in that folder
3. Run the command: javac Worm.javac
4. Run the command: java Worm "Worm.java" 1 3 (If you wish to run the worm more than 3 times, you can change 3 to any number of choice.)

See the Main Output.txt to see that the output files are identical. The only change is the class name, so that it will compile.

There are no shortcomings in this version that we know of.